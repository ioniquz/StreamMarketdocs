// web3-injector.js - Simple Web3 injector
(function() {
    if (window.self !== window.top) return;
    
    // Listen for Web3 messages
    window.addEventListener('message', function(event) {
        if (!event.data || event.data.type !== 'TWITCH_BETS_WEB3_REQUEST') return;
        
        const { requestId, method, params } = event.data;
        
        handleWeb3Request(requestId, method, params);
    });
    
    async function handleWeb3Request(requestId, method, params) {
        try {
            if (typeof window.ethereum === 'undefined') {
                throw new Error('MetaMask not installed');
            }
            
            let result;
            
            switch (method) {
                case 'checkMetaMaskInstalled':
                    result = typeof window.ethereum !== 'undefined';
                    break;
                    
                case 'requestAccounts':
                    result = await window.ethereum.request({ method: 'eth_requestAccounts' });
                    break;
                    
                case 'getAccounts':
                    result = await window.ethereum.request({ method: 'eth_accounts' });
                    break;
                    
                case 'getChainId':
                    result = await window.ethereum.request({ method: 'eth_chainId' });
                    break;
                    
                case 'getBalance':
                    const address = params && params[0] ? params[0] : window.ethereum.selectedAddress;
                    if (!address) throw new Error('No address provided');
                    
                    result = await window.ethereum.request({
                        method: 'eth_getBalance',
                        params: [address, 'latest']
                    });
                    break;
                    
                case 'sendTransaction':
                    // Прямая отправка транзакции
                    const [txParams] = params || [{}];
                    result = await window.ethereum.request({
                        method: 'eth_sendTransaction',
                        params: [txParams]
                    });
                    break;
                    
                case 'call':
                    // Вызов view-метода
                    const [callParams, block] = params || [{}, 'latest'];
                    result = await window.ethereum.request({
                        method: 'eth_call',
                        params: [callParams, block]
                    });
                    break;
                    
                case 'getTransactionReceipt':
                    const [txHash] = params || [];
                    result = await window.ethereum.request({
                        method: 'eth_getTransactionReceipt',
                        params: [txHash]
                    });
                    break;
                    
                case 'switchToPolygon':
                    try {
                        // Switch to Polygon
                        await window.ethereum.request({
                            method: 'wallet_switchEthereumChain',
                            params: [{ chainId: '0x89' }] // Polygon
                        });
                        result = { success: true };
                    } catch (error) {
                        if (error.code === 4902) {
                            // Add Polygon if not present
                            await window.ethereum.request({
                                method: 'wallet_addEthereumChain',
                                params: [{
                                    chainId: '0x89',
                                    chainName: 'Polygon',
                                    nativeCurrency: { 
                                        name: 'POL', 
                                        symbol: 'POL', 
                                        decimals: 18 
                                    },
                                    rpcUrls: ['https://polygon-rpc.com'],
                                    blockExplorerUrls: ['https://polygonscan.com']
                                }]
                            });
                            result = { success: true };
                        } else {
                            throw error;
                        }
                    }
                    break;
                    
                default:
                    throw new Error(`Unknown Web3 method: ${method}`);
            }
            
            window.postMessage({
                type: 'TWITCH_BETS_WEB3_RESPONSE',
                requestId,
                success: true,
                result
            }, '*');
            
        } catch (error) {
            window.postMessage({
                type: 'TWITCH_BETS_WEB3_RESPONSE',
                requestId,
                success: false,
                error: error.message
            }, '*');
        }
    }
    
    // Listen for MetaMask events and forward them
    if (window.ethereum) {
        window.ethereum.on('accountsChanged', function(accounts) {
            window.postMessage({
                type: 'TWITCH_BETS_METAMASK_EVENT',
                event: 'accountsChanged',
                data: accounts
            }, '*');
        });
        
        window.ethereum.on('chainChanged', function(chainId) {
            window.postMessage({
                type: 'TWITCH_BETS_METAMASK_EVENT',
                event: 'chainChanged',
                data: chainId
            }, '*');
        });
        
        window.ethereum.on('disconnect', function(error) {
            window.postMessage({
                type: 'TWITCH_BETS_METAMASK_EVENT',
                event: 'disconnect',
                data: error
            }, '*');
        });
    }
    
})();