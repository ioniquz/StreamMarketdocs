// Console logging disabled

function escapeHtml(s) {
  if (s == null) return '';
  const t = String(s);
  return t
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

class TwitchBetsExtension {
  constructor() {
    this.predictionIndicator = null;
    this.bettingUI = null;
    this.userBalance = { pol: 0, usdt: 0 };
    this.walletAddress = null;
    this.isConnected = false;
    this.chainId = null;
    this.requestCounter = 0;
    this.pendingRequests = new Map();
    this.pollInterval = null;
    this.processedPredictions = new Set();
    this.predictionWatchers = new Map();
    this.customAmountActive = false;
    this.predictionObserver = null;
    this.currentPredictionElement = null;
    this.polButtons = new Map();
    
    // Новые свойства для отслеживания ставок
    this.userBets = [];
    this.activePredictions = new Map();
    this.currentPredictionId = null;
    this.contractInteractions = new Map();
    
    // Для хранения информации о канале
    this.currentChannel = this.extractChannelName();
    
    // Для отслеживания состояния UI
    this.currentTab = 'main'; // 'main', 'active', 'browse' или 'history'
    
    // Отладочная информация
    this.debugMode = false;
    
    // Флаг для предотвращения мигания UI
    this.uiUpdateInProgress = false;
    
    // Флаг для ускоренной проверки чата
    this.chatCheckCounter = 0;
    this.maxChatChecks = 15;
    
    // Флаг для предотвращения множественных вызовов injectPolBets
    this._injectPolBetsDebounce = null;
    this._lastInjectTime = 0;
    
    // Конфигурация контракта - POLYGON
    // Используем CONFIG из config.js если доступен, иначе значения по умолчанию
    const globalConfig = typeof window !== 'undefined' && window.CONFIG ? window.CONFIG : {};
    
    this.config = {
      POLYGON_CHAIN_ID: globalConfig.POLYGON_CHAIN_ID || '0x89', // Polygon
      POLYGON_RPC_URL: globalConfig.POLYGON_RPC_URL || 'https://polygon-rpc.com',
      POLYGON_SCAN_URL: globalConfig.POLYGON_SCAN_URL || 'https://polygonscan.com',
      MIN_BET_AMOUNT: globalConfig.MIN_BET_AMOUNT || 20,
      PREDICTION_CONTRACT_ADDRESS: globalConfig.PREDICTION_CONTRACT_ADDRESS || '0xe02FF561CF2B53A1C967982931f94B6a59b0753c',
      POL_TOKEN_ADDRESS: globalConfig.POL_TOKEN_ADDRESS || null,
      
      // Используем ABI v2 (если задан), иначе старый
      CONTRACT_ABI: globalConfig.PREDICTION_CONTRACT_ABI_V2 || globalConfig.PREDICTION_CONTRACT_ABI || [],
      
      // Enum values для ReportResult (новый контракт: только 2 значения)
      REPORT_RESULTS: globalConfig.REPORT_RESULTS || {
        FINISHED_0: 0,
        FINISHED_1: 1
      }
    };
    
    // Кеш для контракта ethers.js
    this.contract = null;
    this.provider = null;
    this.signer = null;
    
    // Автоматическая отправка отчетов
    this.reportingInterval = null;
    this.lastReportTimes = new Map(); // contractId -> timestamp
    this.lastSentStatus = new Map(); // contractId -> last sent statusValue (0-3)

    // Разблокировка Claim через 3 минуты после FINISHED отчета (локально, для UI)
    this.finishWaitMs = 3 * 60 * 1000;
    this.claimUnlockTimers = new Map(); // contractId -> timeoutId
    
    // Моментальная отправка FINISHED при появлении Winner
    this.winnerObserver = null;
    this._winnerDebounceTimer = null;
    
    // Флаг для предотвращения параллельных отправок репортов
    this._reportingInProgress = false;
    
    // Множество предиктов, для которых уже отправлен Winner report (чтобы не спамить)
    this._winnerReportedPredictions = new Set();
    // Время последней отправки репорта для каждого contractId (для предотвращения спама)
    this._lastReportAttemptTime = new Map();
    // Глобальный кулдаун: после отправки одного отчёта о победителе не отправлять снова N секунд (только 1 подтверждение)
    this._lastWinnerReportSentAt = 0;
    this._winnerReportCooldownMs = 120000; // 2 минуты — одна транзакция на одно появление Winner
    
    // Список активных контрактов предиктов
    this.activeContractPredictions = new Map(); // contractId -> {channel, question, options, etc}
    
    // Кэш для статусов предиктов (чтобы избежать rate limiting)
    this.statusCache = new Map(); // contractId -> {status, timestamp}
    this.statusCacheTTL = 30000; // 30 секунд кэш
    
    // Кэш для коэффициентов (чтобы избежать частых запросов)
    this.oddsCache = new Map(); // predictionId -> {odds0, odds1, timestamp}
    
    // Кэш для информации о предиктах (getPredictionInfo)
    this.predictionInfoCache = new Map(); // contractId -> {info, timestamp}
    this.predictionInfoCacheTTL = 15000; // 15 секунд
    
    // Флаг для предотвращения множественных обновлений UI
    this._uiUpdateDebounceTimer = null;
    this._uiUpdateInProgress = false;
    this.oddsCacheTTL = 10000; // 10 секунд кэш для коэффициентов
    
    // Кэш для открытых предиктов по каналам
    this.openPredictionCache = new Map(); // channel -> {predictionId, timestamp}
    this.openPredictionCacheTTL = 15000; // 15 секунд кэш
    
    // Кэш для курса POL/USDT (кэшируем на 10 минут, чтобы не делать слишком много запросов)
    this.polUsdtRateCache = null; // {rate, timestamp}
    
    // Очередь для RPC запросов (чтобы избежать rate limiting)
    this.rpcQueue = [];
    this.rpcProcessing = false;
    this.rpcDelay = 500; // 500ms задержка между запросами (увеличено для избежания rate limit)
    this.rateLimitRetryDelay = 15000; // 15 секунд задержка при rate limit
    this.maxRetries = 3; // Максимальное количество повторных попыток
    
    
    // Дедупликация логов (чтобы избежать спама)
    this.logCache = new Map(); // message -> timestamp
    this.logCacheTTL = 2000; // 2 секунды
    
    // Интервалы для обновления процентов
    this.percentageUpdateIntervals = new Map(); // polDiv -> intervalId
    
    // Многоязычная поддержка: ключевые слова для 6 языков
    this.i18n = {
      predict: {
        en: ['predict'],
        es: ['predecir', 'predicción'],
        fr: ['prédire', 'prédiction'],
        de: ['vorhersagen', 'vorhersage'],
        ru: ['предсказать', 'предсказание', 'прогноз'],
        ko: ['예측', '예상']
      },
      points: {
        en: ['points', 'pts', 'pt'],
        es: ['puntos', 'pts', 'pt'],
        fr: ['points', 'pts', 'pt'],
        de: ['punkte', 'pts', 'pt'],
        ru: ['баллов', 'очков', 'баллы', 'очки', 'pts', 'pt'],
        ko: ['포인트', 'pts', 'pt'],
        ja: ['ポイント', 'pts', 'pt'],
        it: ['punti', 'pts', 'pt']
      },
      winner: {
        en: ['winner', 'won', 'wins'],
        es: ['ganador', 'ganadora', 'ganó', 'gana', 'ganador/a'],
        fr: ['gagnant', 'gagné', 'gagne'],
        de: ['gewinner', 'gewonnen', 'gewinnt'],
        ru: ['победитель', 'победил', 'выиграл', 'выиграла', 'исход'],
        ko: ['승자', '승리', '이김'],
        ja: ['勝者', '勝利', '勝ち'],
        it: ['vincitore', 'vincitrice', 'vinto', 'vince']
      },
      prediction: {
        en: ['prediction', 'predict'],
        es: ['predicción', 'predecir'],
        fr: ['prédiction', 'prédire'],
        de: ['vorhersage', 'vorhersagen'],
        ru: ['предикт', 'прогноз', 'предсказание'],
        ko: ['예측', '예상'],
        ja: ['予想', '予測'],
        it: ['pronostico', 'pronosticare']
      },
      result: {
        en: ['result', 'results', 'outcome'],
        es: ['resultado', 'resultados'],
        fr: ['résultat', 'résultats'],
        de: ['ergebnis', 'ergebnisse'],
        ru: ['результат', 'результаты', 'итоги'],
        ko: ['결과', '결과들'],
        ja: ['結果', '成果'],
        it: ['risultato', 'risultati']
      },
      option: {
        en: ['option 1', 'option 2'],
        es: ['opción 1', 'opción 2'],
        fr: ['option 1', 'option 2'],
        de: ['option 1', 'option 2'],
        ru: ['вариант 1', 'вариант 2', 'опция 1', 'опция 2'],
        ko: ['옵션 1', '옵션 2'],
        ja: ['オプション 1', 'オプション 2'],
        it: ['opzione 1', 'opzione 2']
      },
      ended: {
        en: ['ended', 'completed', 'closed'],
        es: ['terminado', 'completado', 'cerrado'],
        fr: ['terminé', 'complété', 'fermé'],
        de: ['beendet', 'abgeschlossen', 'geschlossen'],
        ru: ['завершено', 'закончено', 'закрыто', 'завершен'],
        ko: ['종료', '완료', '닫힘'],
        ja: ['終了', '完了', '閉鎖'],
        it: ['terminato', 'completato', 'chiuso']
      },
      endedPhrase: {
        en: ['prediction ended', 'ended this minute', 'ended'],
        es: ['predicción terminada', 'terminado este minuto', 'la predicción terminó', 'terminado'],
        fr: ['prédiction terminée', 'terminé cette minute', 'prédiction terminée il y a', 'terminé'],
        de: ['vorhersage beendet', 'beendet diese minute', 'vorhersage wurde beendet', 'beendet'],
        ru: ['предикт завершен', 'завершено в эту минуту', 'прогноз завершился', 'завершено'],
        ko: ['예측 종료', '이 분에 종료', '예측이 종료됐습니다', '종료'],
        ja: ['予想終了', 'この分に終了', '予想は終了しました', '終了'],
        it: ['pronostico terminato', 'terminato questo minuto', 'pronostico terminato questo minuto', 'terminato']
      },
      seeResults: {
        en: ['see results', 'results'],
        es: ['ver resultados', 'resultados'],
        fr: ['voir résultats', 'résultats'],
        de: ['ergebnisse ansehen', 'ergebnisse'],
        ru: ['посмотреть результаты', 'результаты', 'итоги'],
        ko: ['결과 보기', '결과'],
        ja: ['結果を見る', '結果'],
        it: ['vedi risultati', 'risultati']
      }
    };
    
    // Функция для проверки, содержит ли текст любое из ключевых слов
    this.hasKeyword = (text, category) => {
      if (!text || typeof text !== 'string') return false;
      const lowerText = text.toLowerCase();
      for (const lang in this.i18n[category]) {
        for (const keyword of this.i18n[category][lang]) {
          if (lowerText.includes(keyword.toLowerCase())) {
            return true;
          }
        }
      }
      return false;
    };
    
    // Функция для проверки, содержит ли текст все ключевые слова из категории
    this.hasAllKeywords = (text, category) => {
      if (!text || typeof text !== 'string') return false;
      const lowerText = text.toLowerCase();
      const allKeywords = [];
      for (const lang in this.i18n[category]) {
        allKeywords.push(...this.i18n[category][lang]);
      }
      return allKeywords.some(keyword => lowerText.includes(keyword.toLowerCase()));
    };
    
    this.init();
  }
  
  // Функция для логирования с дедупликацией
  log(message, level = 'log') {
    const msg = (typeof message === 'string') ? message : String(message);
    
    // Не спамим консоль отладкой парсинга опций (теперь не критично для определения победителя)
    if (msg.includes('[extractPredictionOptions]')) {
      return;
    }

    const now = Date.now();
    const cacheKey = msg.substring(0, 100); // Берем первые 100 символов для ключа
    
    const lastLogTime = this.logCache.get(cacheKey);
    if (lastLogTime && (now - lastLogTime) < this.logCacheTTL) {
      // Недавно логировали это сообщение, пропускаем
      return;
    }
    
    // Логируем и сохраняем время
    this.logCache.set(cacheKey, now);
    
    // Очищаем старые записи из кэша (раз в 10 секунд)
    if (Math.random() < 0.1) { // 10% вероятность очистки
      for (const [key, time] of this.logCache.entries()) {
        if (now - time > this.logCacheTTL * 5) {
          this.logCache.delete(key);
        }
      }
    }
    
    // Console logging disabled
  }

  async init() {
    
    // НЕМЕДЛЕННО пытаемся найти и вставить кнопку
    this.attemptImmediateInsert();
    
    await this.injectWeb3();
    await this.loadContractAbiFromAbiTxt();
    this.setupEventListeners();
    await this.checkExistingConnection();
    await this.loadUserBets();
    this.setupChatMonitoring();
    this.startAdvancedPredictionWatcher();
    this.setupPredictionCloseWatcher();
    this.startWinnerImmediateReporting();
    
    // Запускаем автоматическую отправку отчетов
    this.startAutomaticReporting();
    
    // Запускаем периодическую проверку результатов
    setInterval(() => {
      this.checkPredictionResults();
    }, 3000);
    
    // ПРОВЕРЯЕМ БАЛАНС КАЖДЫЕ 5 СЕКУНД
    setInterval(() => {
      this.updateWalletBalance();
    }, 5000);
    
    // Проверяем статусы контрактов каждые 30 секунд
    setInterval(() => {
      this.checkContractStatuses();
    }, 30000);
    
    // Обновляем только таймеры каждую секунду (без полного пересоздания UI)
    setInterval(() => {
      if (this.bettingUI && document.body.contains(this.bettingUI)) {
        // Обновляем только таймеры, чтобы избежать мигания
        if (this.currentTab === 'active') {
          this.updateUITimers();
        }
      }
    }, 1000);
    
    // Автоматическое обновление для Browse Predictions каждые 15 секунд (увеличено)
    setInterval(() => {
      if (this.bettingUI && document.body.contains(this.bettingUI) && this.currentTab === 'browse') {
        this.safeUpdateUI();
      }
    }, 15000);
    
    // Динамическое обновление процентов в элементах POL каждые 3 секунды
    setInterval(() => {
      this.updateAllPolPercentages();
    }, 3000);
    
    // Периодическая проверка и вставка кнопки индикатора (на случай, если чат загрузился позже)
    setInterval(() => {
      const existingIndicator = document.getElementById('twitch-bets-indicator');
      if (!existingIndicator && this.isStreamPage()) {
        this.tryInsertIndicator();
      }
    }, 2000);
    
    // Очистка старых кэшей каждые 5 минут
    setInterval(() => {
      const now = Date.now();
      
      // Очистка кэша коэффициентов
      for (const [key, value] of this.oddsCache.entries()) {
        if (now - value.timestamp > this.oddsCacheTTL * 2) {
          this.oddsCache.delete(key);
        }
      }
      
      // Очистка кэша открытых предиктов
      for (const [key, value] of this.openPredictionCache.entries()) {
        if (now - value.timestamp > this.openPredictionCacheTTL * 2) {
          this.openPredictionCache.delete(key);
        }
      }
    }, 300000); // Каждые 5 минут
    
  }

  // Загружаем ABI из файла `contracts/ABI.txt` (который ты обновляешь после каждого redeploy).
  // Это помогает избежать рассинхрона ABI в config.js.
  async loadContractAbiFromAbiTxt() {
    try {
      if (!chrome?.runtime?.getURL) return;
      const url = chrome.runtime.getURL('contracts/ABI.txt');
      const resp = await fetch(url);
      if (!resp.ok) return;
      const text = await resp.text();
      const abi = JSON.parse(text);
      if (Array.isArray(abi) && abi.length > 0) {
        this.config.CONTRACT_ABI = abi;
        // если контракт уже создавался — пересоздадим с новым ABI
        this.contract = null;
      }
    } catch (e) {
      // молча, чтобы не спамить консоль
    }
  }

  // Парсит время окончания предикта из текста ("this minute", "1 minute ago", "2 minutes ago", etc.)
  parsePredictionEndTime(dialogText) {
    if (!dialogText) return null;
    
    const text = dialogText.toLowerCase();
    
    // Ищем паттерны времени окончания для всех языков
    // Создаем паттерны для каждого языка
    const patterns = [];
    
    // Английский
    patterns.push(/prediction ended this minute/i, /prediction ended (\d+) minute(s)? ago/i, /ended this minute/i, /ended (\d+) minute(s)? ago/i);
    
    // Испанский
    patterns.push(/predicción terminada este minuto/i, /predicción terminada hace (\d+) minuto(s)?/i, /la predicción terminó hace (\d+) minuto(s)?/i, /terminado este minuto/i, /terminado hace (\d+) minuto(s)?/i);
    
    // Французский
    patterns.push(/prédiction terminée cette minute/i, /prédiction terminée il y a (\d+) minute(s)?/i, /terminé cette minute/i, /terminé il y a (\d+) minute(s)?/i);
    
    // Немецкий
    patterns.push(/vorhersage beendet diese minute/i, /vorhersage beendet vor (\d+) minute(n)?/i, /beendet diese minute/i, /beendet vor (\d+) minute(n)?/i);
    
    // Русский
    patterns.push(/предикт завершен в эту минуту/i, /предикт завершен (\d+) минут(у|ы)? назад/i, /прогноз завершился (\d+) минут(у|ы)? назад/i, /завершено в эту минуту/i, /завершено (\d+) минут(у|ы)? назад/i);
    
    // Корейский
    patterns.push(/예측 종료 이 분/i, /예측 종료 (\d+)분 전/i, /종료 이 분/i, /종료 (\d+)분 전/i, /예측이 종료됐습니다:? (\d+)분 전/i);
    
    
    // Итальянский
    patterns.push(/pronostico terminato questo minuto/i, /pronostico terminato (\d+) minuto fa/i, /pronostico terminato (\d+) minuti fa/i, /terminato questo minuto/i, /terminato (\d+) minuto fa/i, /terminato (\d+) minuti fa/i);
    
    // Универсальный паттерн для "this minute" / "эту минуту" / "esta minuto" и т.д.
    const thisMinutePatterns = [
      /this minute/i, /este minuto/i, /cette minute/i, /diese minute/i, /эту минуту/i, /이 분/i,
      /questo minuto/i, /この分/i, /1分以内/i
    ];
    
    // Универсальный паттерн для "X minutes ago" / "X минут назад" и т.д.
    const minutesAgoPatterns = [
      /(\d+) minute(s)? ago/i,
      /hace (\d+) minuto(s)?/i,
      /la predicción terminó hace (\d+) minuto(s)?/i,
      /il y a (\d+) minute(s)?/i,
      /prédiction terminée il y a (\d+) minute(s)?/i,
      /vor (\d+) minute(n)?/i,
      /vorhersage beendet vor (\d+) minute(n)?/i,
      /(\d+) минут(у|ы)? назад/i,
      /прогноз завершился (\d+) минут(у|ы)? назад/i,
      /(\d+)분 전/i,
      /(\d+)分前/i,
      /(\d+)分以内/i,
      /(\d+) minuto fa/i,
      /(\d+) minuti fa/i,
      /pronostico terminato (\d+) minuto fa/i,
      /pronostico terminato (\d+) minuti fa/i,
      /terminato (\d+) minuto fa/i,
      /terminato (\d+) minuti fa/i
    ];
    
    // Сначала проверяем универсальные паттерны "this minute" напрямую в тексте
    for (const thisMinutePattern of thisMinutePatterns) {
      if (thisMinutePattern.test(text)) {
        return Date.now();
      }
    }
    
    // Затем проверяем паттерны "X minutes ago" напрямую в тексте
    for (const minutesAgoPattern of minutesAgoPatterns) {
      const minutesMatch = text.match(minutesAgoPattern);
      if (minutesMatch && minutesMatch[1]) {
        const minutesAgo = parseInt(minutesMatch[1], 10);
        if (!isNaN(minutesAgo) && minutesAgo >= 0 && minutesAgo <= 60) {
          const endTime = Date.now() - (minutesAgo * 60 * 1000);
          return endTime;
        }
      }
    }
    
    // Затем проверяем специфичные паттерны для каждого языка
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) {
        // Если паттерн содержит число минут - извлекаем его
        const numberMatch = match[0].match(/(\d+)/);
        if (numberMatch) {
          const minutesAgo = parseInt(numberMatch[1], 10);
          if (!isNaN(minutesAgo) && minutesAgo >= 0 && minutesAgo <= 60) {
            const endTime = Date.now() - (minutesAgo * 60 * 1000);
            return endTime;
          }
        } else {
          // Если числа нет, значит это "this minute"
          return Date.now();
        }
      }
    }
    
    // Если не нашли - возвращаем null
    return null;
  }

  // Получает время последней ставки для предикта
  getBetTimeForPrediction(contractId, channel) {
    // Ищем ставку по contractId
    const bet = this.userBets.find(b => b.contractId === contractId);
    if (bet && bet.timestamp) {
      return bet.timestamp;
    }
    
    // Если не нашли по contractId, ищем по каналу (последняя ставка на этом канале)
    const channelBets = this.userBets
      .filter(b => b.channel === channel && b.timestamp)
      .sort((a, b) => b.timestamp - a.timestamp);
    
    if (channelBets.length > 0) {
      return channelBets[0].timestamp;
    }
    
    return null;
  }

  // Проверяет, что время окончания предикта идет СТРОГО после времени ставки
  isPredictionResultValid(contractId, channel, dialogText) {
    const betTime = this.getBetTimeForPrediction(contractId, channel);
    if (!betTime) {
      // Если нет ставки - пропускаем проверку (может быть тестовый режим)
      return true;
    }
    
    const endTime = this.parsePredictionEndTime(dialogText);
    if (!endTime) {
      // Если не смогли распарсить время - пропускаем проверку (может быть другой формат)
      return true;
    }
    
    // КРИТИЧЕСКАЯ ПРОВЕРКА: ставка должна быть СТРОГО раньше объявления результата
    // Если ставка сделана после или в момент объявления результата - это старые результаты
    const timeDiff = betTime - endTime; // Положительное если ставка после окончания
    
    if (timeDiff >= 0) {
      // Ставка сделана ПОСЛЕ или В МОМЕНТ окончания предикта - это старые результаты
      const minutesDiff = timeDiff / (60 * 1000);
      return false;
    } else {
      // Время окончания СТРОГО после ставки - валидно
      const minutesDiff = Math.abs(timeDiff) / (60 * 1000);
      return true;
    }
  }

  // МОМЕНТАЛЬНЫЙ ТРИГГЕР: как только в окне prediction появляется "Winner" — сразу отправляем FINISHED
  startWinnerImmediateReporting() {
    try {
      if (this.winnerObserver) {
        this.winnerObserver.disconnect();
        this.winnerObserver = null;
      }
      
      const trigger = () => {
        // Не запускаем новый таймер, если недавно уже отправили отчёт о победителе (только 1 транзакция)
        if (this._lastWinnerReportSentAt && (Date.now() - this._lastWinnerReportSentAt) < (this._winnerReportCooldownMs || 120000)) {
          return;
        }
        if (this._winnerDebounceTimer) return;
        // Одна задержка — одна попытка отправки
        this._winnerDebounceTimer = setTimeout(async () => {
          this._winnerDebounceTimer = null;
          
          // Быстрый фильтр: если на странице нет Winner — выходим
          const dialog = document.querySelector('[role="dialog"]');
          if (!dialog) return;
          const txt = (dialog.textContent || '').toLowerCase();
          if (!this.hasKeyword(txt, 'winner')) return;
          
          // Дополнительная проверка: не отправляем, если уже идёт процесс отправки или недавно отправили
          if (this._reportingInProgress) {
            return;
          }
          if (this._lastWinnerReportSentAt && (Date.now() - this._lastWinnerReportSentAt) < (this._winnerReportCooldownMs || 120000)) {
            return;
          }
          
          await this.sendReportsForActivePredictions({ reason: 'winner', forceFinished: true });
        }, 1500); // Одна задержка — одна транзакция
      };
      
      this.winnerObserver = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.type === 'childList') {
            for (const node of m.addedNodes) {
              if (!node || node.nodeType !== Node.ELEMENT_NODE) continue;
              const el = /** @type {Element} */ (node);
              const dialog = el.closest?.('[role="dialog"]');
              if (!dialog) continue;
              const txt = (dialog.textContent || '').toLowerCase();
              if (this.hasKeyword(txt, 'winner')) {
                trigger();
                return;
              }
            }
          } else if (m.type === 'characterData') {
            const parent = m.target?.parentElement;
            const dialog = parent?.closest?.('[role="dialog"]');
            if (!dialog) continue;
            const txt = (dialog.textContent || '').toLowerCase();
            if (this.hasKeyword(txt, 'winner')) {
              trigger();
              return;
            }
          }
        }
      });
      
      this.winnerObserver.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true
      });
      
      // На случай если окно уже открыто
      trigger();
    } catch (e) {
    }
  }

  // Извлекаем имя канала из URL
  extractChannelName() {
    try {
      const url = window.location.href;
      const match = url.match(/twitch\.tv\/([^/?]+)/);
      if (match && match[1]) {
        return match[1];
      }
    } catch (error) {
    }
    return 'unknown_channel';
  }

  async injectWeb3() {
    try {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('web3-injector.js');
      script.onload = () => {
        script.remove();
      };
      (document.head || document.documentElement).appendChild(script);
      
      
    } catch (error) {
    }
  }

  // НОВАЯ ФУНКЦИЯ: Старт автоматической отправки отчетов
  startAutomaticReporting() {
    if (this.reportingInterval) {
      clearInterval(this.reportingInterval);
    }
    
    // ВАЖНО: больше НЕ отправляем "каждую минуту" on-chain.
    // Проверяем страницу часто, но транзакцию отправляем ТОЛЬКО когда найден Winner (FINISHED_0/FINISHED_1).
    this.reportingInterval = setInterval(async () => {
      await this.sendReportsForActivePredictions({ forceFinished: true });
    }, 3000); // 3 секунды
    
    // Первая проверка через 2 секунды после старта
    setTimeout(() => {
      this.sendReportsForActivePredictions({ forceFinished: true });
    }, 2000);
    
  }

  // НОВАЯ ФУНКЦИЯ: Отправка отчетов для активных предиктов
  // opts.forceFinished: если true — отправляем FINISHED сразу при появлении Winner (без минутного кулдауна)
  async sendReportsForActivePredictions(opts = {}) {
    const { forceFinished = false } = opts || {};
    
    // Предотвращаем параллельные вызовы
    if (this._reportingInProgress) {
      return;
    }
    
    if (!this.isConnected || !this.walletAddress) {
      return;
    }
    
    const currentChannel = this.extractChannelName();
    const currentTime = Date.now();
    
    // Собираем все предикты для отправки отчетов:
    // 1. Предикты, на которые пользователь сделал ставку (activeContractPredictions)
    // 2. Все активные предикты на Twitch (activePredictions) - для отладки
    
    const predictionsToReport = new Map();
    
    // ВРЕМЕННО: Отправляем отчеты для всех предиктов (для отладки)
    // Добавляем предикты из activeContractPredictions (где есть ставка POL)
    for (const [contractId, prediction] of this.activeContractPredictions) {
      predictionsToReport.set(contractId, {
        ...prediction,
        hasBet: true
      });
    }
    
    // ВРЕМЕННО: Добавляем все активные предикты на Twitch (даже без ставки POL) - для отладки
    for (const [predictionId, prediction] of this.activePredictions) {
      if (prediction.channel === currentChannel && prediction.status === 'active') {
        // Генерируем contractId для этого предикта
        const startTime = prediction.startTime || Math.floor(Date.now() / 1000);
        const contractId = prediction.contractId || this.generateContractId(
          prediction.channel,
          prediction.question,
          prediction.options,
          startTime
        );
        
        // Если этого предикта еще нет в списке, добавляем
        if (!predictionsToReport.has(contractId)) {
          predictionsToReport.set(contractId, {
            channel: prediction.channel,
            question: prediction.question,
            options: prediction.options,
            hasBet: false
          });
        }
      }
    }
    
    if (predictionsToReport.size === 0) {
      return;
    }
    
    // Определяем статус предикта на странице Twitch один раз для всех предиктов
    const twitchStatus = await this.determinePredictionStatus();
    const statusNames = ['FINISHED_0', 'FINISHED_1', 'NOT_FINISHED', 'OUT_FROM_STREAM'];
    const statusName = twitchStatus !== null && twitchStatus !== undefined 
      ? (statusNames[twitchStatus] || `UNKNOWN(${twitchStatus})`)
      : 'UNDETERMINED';
    
    // Логируем только если есть что-то интересное
    if (predictionsToReport.size > 0) {
      this.log(`🔍 [Status Report] Checking ${predictionsToReport.size} prediction(s), status: ${statusName}`);
    }
    
    // Если Winner не найден — НИЧЕГО не отправляем on-chain
    const statusValueGlobal = typeof twitchStatus === 'number' ? twitchStatus : parseInt(twitchStatus);
    if (
      isNaN(statusValueGlobal) ||
      (statusValueGlobal !== this.config.REPORT_RESULTS.FINISHED_0 &&
       statusValueGlobal !== this.config.REPORT_RESULTS.FINISHED_1)
    ) {
      return;
    }

    // КРИТИЧНО: только одна транзакция на одно появление Winner — глобальный кулдаун
    if (this._lastWinnerReportSentAt && (currentTime - this._lastWinnerReportSentAt) < this._winnerReportCooldownMs) {
      return;
    }

    for (const [contractId, prediction] of predictionsToReport) {
      try {
        // Проверяем, на том ли мы канале
        if (prediction.channel !== currentChannel) {
          continue;
        }
        
        // Проверяем статус предикта в контракте
        // ВАЖНО: Для предиктов без ставок (hasBet: false) пропускаем проверку контракта
        // и отправляем статус напрямую (для отладки)
        let contractStatus = null;
        let shouldCheckContract = prediction.hasBet; // Проверяем контракт только для предиктов со ставками
        
        if (shouldCheckContract) {
        try {
          contractStatus = await this.getPredictionStatus(contractId);
        } catch (error) {
            // Если предикт не существует в контракте (еще никто не делал ставку) или rate limit
            if (error.message && (error.message.includes('missing revert data') || 
                                  error.message.includes('CALL_EXCEPTION') ||
                                  error.message.includes('rate limit'))) {
            continue;
          }
            // Для других ошибок тоже пропускаем, чтобы не спамить
            continue;
        }
        
          if (contractStatus !== 'active' && contractStatus !== 'open') {
          // Предикт уже разрешен или отменен, не отправляем отчеты
            // Удаляем из списка активных, если предикт завершен
            if (contractStatus === 'resolved' || contractStatus === 'cancelled') {
              this.activeContractPredictions.delete(contractId);
              this.lastReportTimes.delete(contractId);
            }
          continue;
        }
          } else {
          // Для предиктов без ставок просто логируем
        }
        
        // Не отправляем один и тот же статус повторно (локальная проверка)
        const lastStatus = this.lastSentStatus.get(contractId);
        if (lastStatus === statusValueGlobal) continue;

        // Для предиктов без ставок не отправляем в контракт (предикт не существует)
        if (!shouldCheckContract) continue;

        // Проверяем локально, отправляли ли уже Winner для этого предикта
        if (this._winnerReportedPredictions.has(contractId)) {
          continue;
        }

        // ДОПОЛНИТЕЛЬНАЯ ЗАЩИТА: Проверяем, не пытались ли мы отправить репорт для этого contractId недавно
        const lastAttemptTime = this._lastReportAttemptTime.get(contractId);
        if (lastAttemptTime && (currentTime - lastAttemptTime) < 5000) {
          // Если пытались отправить менее 5 секунд назад - пропускаем
          continue;
        }
        // Запоминаем время попытки отправки
        this._lastReportAttemptTime.set(contractId, currentTime);

        // КРИТИЧЕСКАЯ ПРОВЕРКА: Проверяем время окончания предикта относительно времени ставки
        const dialog = document.querySelector('[role="dialog"]');
        if (dialog && prediction.hasBet) {
          const dialogText = dialog.textContent || '';
          const isValid = this.isPredictionResultValid(contractId, prediction.channel, dialogText);
          if (!isValid) {
            continue;
          }
        }

        // Проверяем on-chain, отправлял ли пользователь уже репорт
        try {
          const predictionId = await this.getContractPredictionId(prediction.channel);
          if (predictionId && predictionId !== '0x0000000000000000000000000000000000000000000000000000000000000000') {
            const hasAlreadyReported = await this.checkHasReported(predictionId);
            if (hasAlreadyReported) {
              this.lastSentStatus.set(contractId, statusValueGlobal);
              this._winnerReportedPredictions.add(contractId); // Запоминаем локально
              this._lastReportAttemptTime.delete(contractId); // Очищаем время попытки
              continue;
            }
          }
        } catch (e) {
          // Если не удалось проверить — продолжаем
        }

        // Финальная проверка перед отправкой: убеждаемся, что не идет уже другая отправка
        if (this._reportingInProgress) {
          continue;
        }

        this._reportingInProgress = true;
        try {
          const txHash = await this.sendReport(prediction.channel, statusValueGlobal, contractId);
          if (txHash) {
            this._lastWinnerReportSentAt = Date.now(); // Глобальный кулдаун — только 1 транзакция на Winner
            this.lastReportTimes.set(contractId, currentTime);
            this.lastSentStatus.set(contractId, statusValueGlobal);
            this._winnerReportedPredictions.add(contractId); // Отмечаем как отправленный
            this._lastReportAttemptTime.delete(contractId); // Очищаем время попытки после успешной отправки
          } else {
            // Если отправка не удалась, оставляем время попытки для повторной попытки через 5 секунд
          }
        } catch (error) {
          // При ошибке оставляем время попытки для повторной попытки через 5 секунд
          this.log(`Error sending report: ${error.message}`);
        } finally {
          this._reportingInProgress = false;
        }
        
        // После отправки одного репорта — выходим, чтобы не спамить MetaMask
        return;
        
      } catch (error) {
      }
    }
  }

  // ИСПРАВЛЕННАЯ ФУНКЦИЯ: Определение статуса предикта
  async determinePredictionStatus() {
    try {
      // Убираем избыточное логирование - логируем только важные события
      
      // ШАГ 1: Ищем завершенные предикты по всей странице (приоритет)
      // Используем более широкие селекторы для поиска завершенных предиктов
      const finishedSelectors = [
        '[data-a-target*="prediction"]',
        '[class*="prediction"]',
        '[role="dialog"]',
        '[data-test-selector*="prediction"]',
        '[class*="result"]',
        '[class*="winner"]',
        '[class*="ended"]',
        'button[class*="result"]',
        'div[class*="prediction"]',
        'div[class*="outcome"]'
      ];
      
      let allElements = [];
      for (const selector of finishedSelectors) {
        try {
          const elements = document.querySelectorAll(selector);
          allElements.push(...Array.from(elements));
        } catch (e) {
          // Игнорируем ошибки селекторов
        }
      }
      
      // Убираем дубликаты и фильтруем только видимые элементы
      allElements = Array.from(new Set(allElements)).filter(el => {
        if (!el || !el.textContent) return false;
        const style = window.getComputedStyle(el);
        return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
      });
      
      // Убираем избыточное логирование
      
      // ШАГ 2: Сначала ищем завершенные предикты с явным указанием победителя
      for (const element of allElements) {
        const text = element.textContent.toLowerCase();
        const html = element.innerHTML.toLowerCase();
        
        // Пропускаем элементы без релевантного контента
        if (text.length < 10) continue;
        
        // Проверяем признаки завершенного предикта (многоязычно)
        const hasResultKeywords = this.hasKeyword(text, 'result') || 
                                 this.hasKeyword(text, 'winner') || 
                                 this.hasKeyword(text, 'ended');
        
        if (!hasResultKeywords) continue;
        
        // Проверяем завершен ли предикт и кто победил
        // Важно: в Twitch Option 1 = первый вариант = индекс 0 = FINISHED_0
        //         в Twitch Option 2 = второй вариант = индекс 1 = FINISHED_1
        
        // Проверяем явные указания на победителя Option 1 (многоязычно)
        const option1Keywords = ['option 1', 'opción 1', 'option 1', 'option 1', 'вариант 1', 'опция 1', '옵션 1'];
        const option2Keywords = ['option 2', 'opción 2', 'option 2', 'option 2', 'вариант 2', 'опция 2', '옵션 2'];
        const winnerKeywords = ['winner', 'ganador', 'gagnant', 'gewinner', 'победитель', '승자'];
        const wonKeywords = ['won', 'ganó', 'gagné', 'gewonnen', 'победил', 'выиграл', '승리'];
        const resultKeywords = ['result', 'resultado', 'résultat', 'ergebnis', 'результат', '결과'];
        
        const hasOption1 = option1Keywords.some(kw => text.includes(kw) || html.includes(kw));
        const hasOption2 = option2Keywords.some(kw => text.includes(kw) || html.includes(kw));
        const hasWinner = winnerKeywords.some(kw => text.includes(kw) || html.includes(kw));
        const hasWon = wonKeywords.some(kw => text.includes(kw) || html.includes(kw));
        const hasResult = resultKeywords.some(kw => text.includes(kw) || html.includes(kw));
        
        const option1Won = (hasOption1 && (hasWinner || hasWon) && !hasOption2) ||
                          (hasResult && hasOption1 && !hasOption2) ||
                          (html.includes('option') && html.includes('1') && (hasWon || hasWinner) && !html.includes('option 2'));
        
        // Проверяем явные указания на победителя Option 2 (многоязычно)
        const option2Won = (hasOption2 && (hasWinner || hasWon) && !hasOption1) ||
                          (hasResult && hasOption2 && !hasOption1) ||
                          (html.includes('option') && html.includes('2') && (hasWon || hasWinner) && !html.includes('option 1'));
        
        if (option1Won) {
          return this.config.REPORT_RESULTS.FINISHED_0;
        }
        
        if (option2Won) {
          return this.config.REPORT_RESULTS.FINISHED_1;
        }
        
        // Дополнительная проверка через getWinningOptionFromEndedPrediction
        const winningOption = this.getWinningOptionFromEndedPrediction(element);
        if (winningOption !== null && winningOption !== undefined) {
          const result = winningOption === 0 ? this.config.REPORT_RESULTS.FINISHED_0 : this.config.REPORT_RESULTS.FINISHED_1;
          return result;
        }
      }
      
      // ШАГ 3: Проверяем текущий активный предикт (если есть)
      if (this.currentPredictionElement && document.body.contains(this.currentPredictionElement)) {
        // Используем определение из элемента
        const winningOption = this.getWinningOptionFromEndedPrediction(this.currentPredictionElement);
        if (winningOption !== null && winningOption !== undefined) {
          const result = winningOption === 0 ? this.config.REPORT_RESULTS.FINISHED_0 : this.config.REPORT_RESULTS.FINISHED_1;
          return result;
        }
        
        // Если предикт активен (есть таймер, но нет победителя)
        const elementText = this.currentPredictionElement.textContent?.toLowerCase() || '';
        const hasActiveTimer = /\d+:\d+(?::\d+)?/.test(elementText);
        const hasEndedTimer = /(0:00|ended|завершено|закончено|closed|result)/i.test(elementText);
        
        if (hasActiveTimer && !hasEndedTimer) {
          return this.config.REPORT_RESULTS.NOT_FINISHED;
        }
      }
      
      // ШАГ 4: Проверяем активные предикты (с таймером, но не завершенные)
      for (const element of allElements) {
        const text = element.textContent.toLowerCase();
        
        // Проверяем активный таймер (но не завершенный)
        const hasActiveTimer = /\d+:\d+(?::\d+)?/.test(text);
        const hasEndedTimer = /(0:00|ended|завершено|закончено|closed|result)/i.test(text);
        const hasResultKeywords = this.hasKeyword(text, 'result') || this.hasKeyword(text, 'winner');
        
        // Если есть активный таймер и предикт не завершен
        if (hasActiveTimer && !hasEndedTimer && !hasResultKeywords) {
          return this.config.REPORT_RESULTS.NOT_FINISHED;
        }
      }
      
      // ШАГ 5: Если ничего не найдено, считаем что предикт не завершен
      return this.config.REPORT_RESULTS.NOT_FINISHED;
      
    } catch (error) {
      // Тихо возвращаем NOT_FINISHED при ошибке
      return this.config.REPORT_RESULTS.NOT_FINISHED;
    }
  }

  // НОВЫЙ МЕТОД (минимальная транзакция):
  // reportResult(channel, FINISHED_0|FINISHED_1)
  // contractId нужен только для локального UI (таймер Claim).
  async sendReport(channel, result, contractId = null) {
    try {
      if (!this.isConnected || !this.walletAddress) {
        return null;
      }
      
      // Проверяем сеть
      if (this.chainId !== this.config.POLYGON_CHAIN_ID) {
        return null;
      }
      
      if (!channel || typeof channel !== 'string') {
        return null;
      }
      
      // Валидация result
      const resultValue = typeof result === 'number' ? result : parseInt(result);
      if (isNaN(resultValue) || (resultValue !== 0 && resultValue !== 1)) {
        return null;
      }
      
      const statusNames = ['FINISHED_0', 'FINISHED_1'];
      
      try {
        // Получаем контракт
        const contract = await this.getContract();
        
        // Вызываем функцию reportResult
        // Новый контракт: reportResult(string channel, uint8 result)
        const tx = await contract.reportResult(channel, resultValue);
        

        // Для FINISHED_* — запускаем локальный таймер показа Claim (через 3 минуты)
        if (contractId) this._markClaimUnlockAfterFinishedReport(contractId, Date.now());
        
        // Не ждем подтверждения для отчетов (они отправляются автоматически)
        return tx.hash;
        
      } catch (error) {
        // Логируем ошибки для отладки
        
        // Проверяем тип ошибки
        // Error handling - no action needed
        
        // Возвращаем null при ошибке
        return null;
      }
      
    } catch (error) {
      return null;
    }
  }

  _formatCountdownMs(ms) {
    const totalSec = Math.max(0, Math.ceil(ms / 1000));
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  _getClaimUnlockAtForGroup(group) {
    // Берем из сохраненных ставок (переживает перезагрузку вкладки)
    const fromBets = (group?.bets || [])
      .map(b => b?.claimUnlockAt)
      .filter(v => typeof v === 'number' && isFinite(v));
    if (fromBets.length > 0) return Math.min(...fromBets);

    // Фоллбек на текущую сессию (если еще не успели сохранить)
    const cid = group?.contractId;
    if (cid) {
      const sentAt = this.lastReportTimes.get(cid);
      if (typeof sentAt === 'number' && isFinite(sentAt)) return sentAt + this.finishWaitMs;
    }
    return null;
  }

  _scheduleClaimUnlockUI(contractId, unlockAt) {
    if (!contractId || !unlockAt) return;
    const delay = unlockAt - Date.now();

    const existing = this.claimUnlockTimers.get(contractId);
    if (existing) {
      clearTimeout(existing);
      this.claimUnlockTimers.delete(contractId);
    }

    if (delay <= 0) {
      this.safeUpdateUI();
      return;
    }

    const tid = setTimeout(() => {
      this.claimUnlockTimers.delete(contractId);
      this.safeUpdateUI();
    }, delay + 50);
    this.claimUnlockTimers.set(contractId, tid);
  }

  async _markClaimUnlockAfterFinishedReport(contractId, sentAtMs) {
    try {
      if (!contractId) return;
      const sentAt = typeof sentAtMs === 'number' ? sentAtMs : Date.now();
      const unlockAt = sentAt + this.finishWaitMs;

      // Сохраняем на уровне ставок, чтобы UI мог показать "Claim" через 3 минуты
      let changed = false;
      this.userBets = (this.userBets || []).map((bet) => {
        if (bet?.contractId !== contractId) return bet;
        if (bet.status !== 'pending' && bet.status !== 'active') return bet;
        if (typeof bet.claimUnlockAt === 'number' && bet.claimUnlockAt >= unlockAt) return bet;
        changed = true;
        return {
          ...bet,
          finishReportSentAt: sentAt,
          claimUnlockAt: unlockAt
        };
      });

      // Также помечаем в activeContractPredictions (не обязательно, но удобно)
      const ap = this.activeContractPredictions.get(contractId);
      if (ap) {
        this.activeContractPredictions.set(contractId, { ...ap, finishReportSentAt: sentAt, claimUnlockAt: unlockAt });
      }

      if (changed) {
        await this.saveUserBets();
      }

      // Если UI открыт — перерисуем в момент разблокировки
      this._scheduleClaimUnlockUI(contractId, unlockAt);
      this.safeUpdateUI();
    } catch (e) {
    }
  }

  // ФУНКЦИЯ: Получение контракта через ethers.js
  async getContract() {
    try {
      // Проверяем доступность ethers.js
      if (typeof ethers === 'undefined') {
        throw new Error('ethers.js library not loaded');
      }
      
      // Если контракт уже создан и провайдер тот же, возвращаем его
      if (this.contract && this.provider && this.signer) {
        // Проверяем, что провайдер все еще валидный
        try {
          await this.provider.getNetwork();
          return this.contract;
        } catch (e) {
          // Провайдер невалидный, пересоздаем
          this.contract = null;
          this.provider = null;
          this.signer = null;
        }
      }
      
      // Проверяем доступность MetaMask через callWeb3
      const hasMetaMask = await this.callWeb3('checkMetaMaskInstalled');
      if (!hasMetaMask) {
        throw new Error('MetaMask not available. Please make sure MetaMask is installed and unlocked.');
      }
      
      // Получаем ethereum через callWeb3 (используем прямой доступ только как fallback)
      let ethereum = null;
      try {
        // Пробуем прямой доступ
        if (typeof window !== 'undefined' && window.ethereum) {
          ethereum = window.ethereum;
          
          // Если есть массив провайдеров, ищем MetaMask
          if (ethereum.providers && Array.isArray(ethereum.providers)) {
            ethereum = ethereum.providers.find(p => p.isMetaMask) || ethereum.providers[0];
          }
        }
      } catch (e) {
        // Игнорируем ошибки прямого доступа
      }
      
      // Если прямой доступ не сработал, создаем провайдер через JsonRpcProvider
      // и используем callWeb3 для транзакций
      if (!ethereum) {
        // Используем JsonRpcProvider для чтения, а для транзакций будем использовать callWeb3
        const rpcUrl = 'https://polygon-rpc.com';
        this.provider = new ethers.JsonRpcProvider(rpcUrl);
        
        // Создаем кастомный signer, который использует callWeb3 для отправки транзакций
        this.signer = {
          provider: this.provider,
          getAddress: async () => this.walletAddress,
          sendTransaction: async (tx) => {
            const txHash = await this.callWeb3('sendTransaction', [{
              from: this.walletAddress,
              to: tx.to,
              value: tx.value ? '0x' + tx.value.toString(16) : undefined,
              data: tx.data,
              gas: tx.gasLimit ? '0x' + tx.gasLimit.toString(16) : undefined,
              gasPrice: tx.gasPrice ? '0x' + tx.gasPrice.toString(16) : undefined
            }]);
            return { hash: txHash };
          },
          getTransactionReceipt: async (txHash) => {
            return await this.callWeb3('getTransactionReceipt', [txHash]);
          }
        };
      } else {
        // Создаем провайдер из window.ethereum
        this.provider = new ethers.BrowserProvider(ethereum);
        
        // Получаем signer
        this.signer = await this.provider.getSigner();
        
        // Проверяем, что signer валидный
        if (!this.signer) {
          throw new Error('Failed to get signer from MetaMask. Please make sure your wallet is unlocked.');
        }
      }
      
      // Создаем контракт
      if (!this.config.CONTRACT_ABI || this.config.CONTRACT_ABI.length === 0) {
        throw new Error('Contract ABI not loaded. Make sure config.js is loaded before content.js');
      }
      
      this.contract = new ethers.Contract(
        this.config.PREDICTION_CONTRACT_ADDRESS,
        this.config.CONTRACT_ABI,
        this.signer
      );
      
      return this.contract;
      
    } catch (error) {
      throw error;
    }
  }

  // Проверка статусов контрактов (автоматически: таймаут, консенсус, батчи refund/distribution)
  // ОПТИМИЗИРОВАНО: запросы выполняются параллельно
  async checkContractStatuses() {
    if (!this.isConnected || this.activeContractPredictions.size === 0) return;
    
    // Собираем все contractId для параллельной проверки
    const contractIds = Array.from(this.activeContractPredictions.keys());
    
    // Проверяем статусы параллельно
    const statusPromises = contractIds.map(async (contractId) => {
      try {
        const status = await this.getPredictionStatus(contractId);
        return { contractId, status };
      } catch (err) {
        return { contractId, status: null };
      }
    });
    
    const statusResults = await Promise.all(statusPromises);
    
    // Обрабатываем результаты
    const syncPromises = [];
    for (const { contractId, status } of statusResults) {
      if (!status) continue;
      
      // ВАЖНО (новый метод): не делаем автоматических write-транзакций,
      // иначе MetaMask будет всплывать без клика пользователя.
      // Тут только read-only синхронизация, чтобы Active/History отображались корректно.
      if (status === 'open' || status === 'active') {
        continue;
      }
      
      if (status === 'resolved' || status === 'cancelled' || status === 'forfeited') {
        // Добавляем синхронизацию в очередь (выполнятся параллельно)
        syncPromises.push(
          this.syncLocalBetStatusFromContract(contractId).then(() => {
            this.activeContractPredictions.delete(contractId);
            this.lastReportTimes.delete(contractId);
          }).catch(() => {})
        );
      }
    }
    
    // Ждем завершения всех синхронизаций параллельно
    if (syncPromises.length > 0) {
      await Promise.all(syncPromises);
    }
  }

  // ИСПРАВЛЕННАЯ ФУНКЦИЯ: Получение статуса предикта из контракта через ethers.js с кэшированием
  async getPredictionStatus(contractId) {
    try {
      // Конвертируем contractId в bytes32 если это строка
      let predictionId;
      if (typeof contractId === 'string') {
        if (contractId.startsWith('0x') && contractId.length === 66) {
          predictionId = contractId;
        } else {
          predictionId = ethers.id(contractId).slice(0, 66);
        }
      } else {
        predictionId = contractId;
      }
      
      // Проверяем кэш
      const cacheKey = predictionId;
      const cached = this.statusCache.get(cacheKey);
      if (cached && (Date.now() - cached.timestamp) < this.statusCacheTTL) {
        return cached.status;
      }
      
      // Добавляем запрос в очередь для rate limiting
      const status = await this.queueRpcRequest(async () => {
      // Получаем контракт (read-only, используем JsonRpcProvider для чтения)
      if (!this.provider) {
        const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
        this.provider = new ethers.JsonRpcProvider(rpcUrl);
      }
      
      const contract = new ethers.Contract(
        this.config.PREDICTION_CONTRACT_ADDRESS,
        this.config.CONTRACT_ABI,
        this.provider
      );
      
      // Вызываем getPredictionInfo через RPC провайдер
      const info = await contract.getPredictionInfo(predictionId);
      
        // Статусы: 0 = OPEN, 1 = ACTIVE, 2 = RESOLVED, 3 = CANCELLED
        const statusNum = Number(info.status);
        
        let statusStr = 'unknown';
        if (statusNum === 0) statusStr = 'open';
        else if (statusNum === 1) statusStr = 'active';
        else if (statusNum === 2) statusStr = 'resolved';
        else if (statusNum === 3) statusStr = 'cancelled';
        
        // Сохраняем в кэш
        this.statusCache.set(cacheKey, {
          status: statusStr,
          timestamp: Date.now()
        });
        
        return statusStr;
      });
      
      return status;
      
    } catch (error) {
      // Если ошибка связана с тем, что предикт не существует, возвращаем 'unknown'
      if (error.message && (error.message.includes('missing revert data') || error.message.includes('CALL_EXCEPTION'))) {
        return 'unknown';
      }
      // Если ошибка rate limiting, возвращаем кэшированное значение если есть
      if (error.message && error.message.includes('rate limit')) {
        const cacheKey = typeof contractId === 'string' && contractId.startsWith('0x') && contractId.length === 66 
          ? contractId 
          : ethers.id(contractId).slice(0, 66);
        const cached = this.statusCache.get(cacheKey);
        if (cached) {
          return cached.status;
        }
      }
      return 'unknown';
    }
  }

  // Получить ID предикта по каналу из контракта
  async getContractPredictionId(channel) {
    try {
      if (!this.provider) {
        const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
        this.provider = new ethers.JsonRpcProvider(rpcUrl);
      }
      const contract = new ethers.Contract(
        this.config.PREDICTION_CONTRACT_ADDRESS,
        this.config.CONTRACT_ABI,
        this.provider
      );
      return await contract.currentPrediction(channel);
    } catch (e) {
      return null;
    }
  }

  // Проверить, отправлял ли пользователь уже репорт
  async checkHasReported(predictionId) {
    try {
      if (!this.walletAddress) return false;
      if (!this.provider) {
        const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
        this.provider = new ethers.JsonRpcProvider(rpcUrl);
      }
      const contract = new ethers.Contract(
        this.config.PREDICTION_CONTRACT_ADDRESS,
        this.config.CONTRACT_ABI,
        this.provider
      );
      return await contract.hasReported(predictionId, this.walletAddress);
    } catch (e) {
      return false;
    }
  }

  // Получение открытого предикта по каналу (с кэшированием)
  async getOpenPredictionIdForChannel(channel) {
    try {
      if (!channel) return null;
      
      // Проверяем кэш
      const cached = this.openPredictionCache.get(channel);
      if (cached && (Date.now() - cached.timestamp) < this.openPredictionCacheTTL) {
        return cached.predictionId;
      }
      
      if (!this.provider) {
        const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
        this.provider = new ethers.JsonRpcProvider(rpcUrl);
      }
      
      const contract = new ethers.Contract(
        this.config.PREDICTION_CONTRACT_ADDRESS,
        this.config.CONTRACT_ABI,
        this.provider
      );
      
      const predictionId = await this.queueRpcRequest(async () => {
        return await contract.currentPrediction(channel);
      });
      
      // Проверяем, что предикт действительно существует и открыт
      if (predictionId && predictionId !== '0x0000000000000000000000000000000000000000000000000000000000000000') {
        const predictionInfo = await this.queueRpcRequest(async () => {
          return await contract.getPredictionInfo(predictionId);
        });
        
        // Проверяем статус (0 = OPEN, 1 = ACTIVE) - конвертируем BigInt в Number
        const status = Number(predictionInfo?.status ?? predictionInfo?.[6] ?? 99);
        if (predictionInfo && (status === 0 || status === 1)) {
          // Сохраняем в кэш
          this.openPredictionCache.set(channel, {
            predictionId: predictionId,
            timestamp: Date.now()
          });
          return predictionId;
        }
      }
      
      // Сохраняем null в кэш, чтобы не запрашивать слишком часто
      this.openPredictionCache.set(channel, {
        predictionId: null,
        timestamp: Date.now()
      });
      
      return null;
    } catch (error) {
      // Не логируем ошибки rate limit, они обрабатываются автоматически
      const isRateLimit = error.message?.includes('rate limit') || 
                         error.message?.includes('Too many requests') ||
                         (error.code === 'BAD_DATA' && error.message?.includes('rate limit'));
      
      // Возвращаем кэшированное значение если есть
      const cached = this.openPredictionCache.get(channel);
      if (cached) {
        return cached.predictionId;
      }
      
      return null;
    }
  }

  // Получение коэффициентов для предикта (с кэшированием)
  async getOddsForPrediction(contractId) {
    try {
      if (!contractId) return { odds0: null, odds1: null };
      
      // Конвертируем contractId в bytes32 если это строка
      let predictionId;
      if (typeof contractId === 'string') {
        if (contractId.startsWith('0x') && contractId.length === 66) {
          predictionId = contractId;
        } else {
          predictionId = ethers.id(contractId).slice(0, 66);
        }
      } else {
        predictionId = contractId;
      }
      
      // Проверяем кэш
      const cached = this.oddsCache.get(predictionId);
      if (cached && (Date.now() - cached.timestamp) < this.oddsCacheTTL) {
        return { odds0: cached.odds0, odds1: cached.odds1 };
      }
      
      // Получаем контракт (read-only)
      if (!this.provider) {
        const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
        this.provider = new ethers.JsonRpcProvider(rpcUrl);
      }
      
      const contract = new ethers.Contract(
        this.config.PREDICTION_CONTRACT_ADDRESS,
        this.config.CONTRACT_ABI,
        this.provider
      );
      
      // Сначала проверяем, существует ли предикт через predictions mapping
      // Это более надежный способ, так как getPredictionInfo может падать на несуществующих предиктах
      try {
        const pred = await this.queueRpcRequest(async () => {
          return await contract.predictions(predictionId);
        });
        
        // Если предикт не существует (id == bytes32(0) или totalPool == 0)
        if (!pred || 
            !pred.id || 
            pred.id === '0x0000000000000000000000000000000000000000000000000000000000000000' || 
            !pred.totalPool || 
            pred.totalPool === 0n) {
          return { odds0: null, odds1: null };
        }
      } catch (predError) {
        // Если predictions не работает, пробуем getPredictionInfo
        try {
          const predictionInfo = await this.queueRpcRequest(async () => {
            return await contract.getPredictionInfo(predictionId);
          });
          
          // Если предикт не существует (totalPool == 0), возвращаем null
          if (!predictionInfo || !predictionInfo.totalPool || predictionInfo.totalPool === 0n) {
            return { odds0: null, odds1: null };
          }
        } catch (checkError) {
          // Если и это не работает, просто возвращаем null (предикт не существует)
          return { odds0: null, odds1: null };
        }
      }
      
      // Вызываем getOddsForBothOptions через RPC провайдер
      // Теперь мы уверены, что предикт существует
      try {
        const [odds0, odds1] = await this.queueRpcRequest(async () => {
          return await contract.getOdds(predictionId);
        });
        
        const result = {
          odds0: odds0 && odds0 > 0n ? Number(odds0) / 10000 : null, // Конвертируем из формата 13500 (1.35x) в 1.35
          odds1: odds1 && odds1 > 0n ? Number(odds1) / 10000 : null
        };
        
        // Сохраняем в кэш
        this.oddsCache.set(predictionId, {
          odds0: result.odds0,
          odds1: result.odds1,
          timestamp: Date.now()
        });
        
        return result;
      } catch (oddsError) {
        // Если getOddsForBothOptions падает (например, предикт не существует в новой версии контракта)
        // возвращаем null без логирования ошибки
        return { odds0: null, odds1: null };
      }
    } catch (error) {
      // Не логируем ошибку, если это просто отсутствующий предикт или revert или rate limit
      const isRevertError = error.code === 'CALL_EXCEPTION' || 
                           error.message?.includes('missing revert data') ||
                           error.message?.includes('revert') ||
                           error.reason === null;
      
      const isRateLimit = error.message?.includes('rate limit') || 
                         error.message?.includes('Too many requests') ||
                         (error.code === 'BAD_DATA' && error.message?.includes('rate limit'));
      
      // Возвращаем кэшированное значение если есть
      if (typeof contractId === 'string') {
        let predictionId;
        if (contractId.startsWith('0x') && contractId.length === 66) {
          predictionId = contractId;
        } else {
          predictionId = ethers.id(contractId).slice(0, 66);
        }
        const cached = this.oddsCache.get(predictionId);
        if (cached) {
          return { odds0: cached.odds0, odds1: cached.odds1 };
        }
      }
      
      return { odds0: null, odds1: null };
    }
  }
  
  // НОВАЯ ФУНКЦИЯ: Очередь для RPC запросов (rate limiting с повторными попытками)
  async queueRpcRequest(requestFn, retries = 0) {
    return new Promise((resolve, reject) => {
      this.rpcQueue.push({ requestFn, resolve, reject, retries });
      this.processRpcQueue();
    });
  }
  
  async processRpcQueue() {
    if (this.rpcProcessing || this.rpcQueue.length === 0) {
      return;
    }
    
    this.rpcProcessing = true;
    
    while (this.rpcQueue.length > 0) {
      const { requestFn, resolve, reject, retries } = this.rpcQueue.shift();
      
      try {
        const result = await requestFn();
        resolve(result);
      } catch (error) {
        // Проверяем, является ли ошибка rate limit
        const isRateLimit = error.message?.includes('rate limit') || 
                           error.message?.includes('Too many requests') ||
                           error.code === 'BAD_DATA' && error.message?.includes('rate limit');
        
        if (isRateLimit && retries < this.maxRetries) {
          // Если это rate limit и есть попытки, добавляем запрос обратно в очередь с задержкой
          const retryDelay = this.rateLimitRetryDelay * (retries + 1); // Экспоненциальная задержка
          
          setTimeout(() => {
            this.rpcQueue.push({ requestFn, resolve, reject, retries: retries + 1 });
            this.processRpcQueue();
          }, retryDelay);
        } else {
          // Если не rate limit или закончились попытки, отклоняем запрос
          reject(error);
        }
      }
      
      // Задержка между запросами (увеличена для избежания rate limit)
      if (this.rpcQueue.length > 0) {
        await new Promise(resolve => setTimeout(resolve, this.rpcDelay));
      }
    }
    
    this.rpcProcessing = false;
  }

  // НОВАЯ ФУНКЦИЯ: Обновление статусов ставок
  async updateBetStatuses(contractId, status) {
    // Обновляем локальные записи ставок
    this.userBets = this.userBets.map(bet => {
      if (bet.contractId === contractId) {
        return {
          ...bet,
          status: status,
          resolveTime: Date.now()
        };
      }
      return bet;
    });
    
    // Сохраняем обновленные ставки
    await this.saveUserBets();
    
    // Обновляем UI
    this.safeUpdateUI();
  }

  // Получение списка активных предиктов со всех каналов
  async getActivePredictionsList(offset = 0, limit = 50) {
    try {
      // Проверяем наличие конфигурации
      if (!this.config || !this.config.PREDICTION_CONTRACT_ADDRESS || !this.config.CONTRACT_ABI) {
        return { predictions: [], totalCount: 0 };
      }
      
      if (!this.provider) {
        const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
        this.provider = new ethers.JsonRpcProvider(rpcUrl);
      }
      
      const contract = new ethers.Contract(
        this.config.PREDICTION_CONTRACT_ADDRESS,
        this.config.CONTRACT_ABI,
        this.provider
      );
      
      // Запрос с таймаутом; при ошибке — одна повторная попытка
      let result;
      const doRequest = () => {
        const requestPromise = this.queueRpcRequest(async () => {
          return await contract.getActivePredictions(offset, limit);
        });
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Request timeout')), 20000);
        });
        return Promise.race([requestPromise, timeoutPromise]);
      };
      try {
        result = await doRequest();
      } catch (firstError) {
        try {
          await new Promise(r => setTimeout(r, 1500));
          result = await doRequest();
        } catch (retryError) {
          return { predictions: [], totalCount: 0, error: true };
        }
      }
      
      // Проверяем, что результат валиден; безопасное извлечение (после ставки RPC может вернуть нестандартный формат)
      if (!result) {
        return { predictions: [], totalCount: 0, error: true };
      }
      let ids, channels, totalPools, createdAts, statuses, totalCount;
      try {
        ids = (result.ids !== undefined ? result.ids : result[0]) || [];
        channels = (result.channels !== undefined ? result.channels : result[1]) || [];
        totalPools = (result.totalPools !== undefined ? result.totalPools : result[2]) || [];
        createdAts = (result.createdAts !== undefined ? result.createdAts : result[3]) || [];
        statuses = (result.statuses !== undefined ? result.statuses : result[4]) || [];
        totalCount = result.totalCount !== undefined ? result.totalCount : (result[5] || 0);
      } catch (e) {
        return { predictions: [], totalCount: 0, error: true };
      }
      if (!Array.isArray(ids) || !Array.isArray(channels) || ids.length !== channels.length) {
        return { predictions: [], totalCount: 0, error: true };
      }
      
      const predictions = [];
      const validIds = [];
      const validIndices = [];
      
      // Собираем валидные ID и их индексы
      for (let i = 0; i < ids.length; i++) {
        if (!ids[i] || ids[i] === '0x0000000000000000000000000000000000000000000000000000000000000000') {
          continue;
        }
        validIds.push(ids[i]);
        validIndices.push(i);
      }
      
      // Если нет валидных ID, возвращаем пустой результат
      if (validIds.length === 0) {
        return { predictions: [], totalCount: 0 };
      }
      
      // Ограничиваем количество параллельных запросов (максимум 5 одновременно для надежности)
      const MAX_CONCURRENT = 5;
      const infoPromises = [];
      
      for (let i = 0; i < validIds.length; i += MAX_CONCURRENT) {
        const batch = validIds.slice(i, i + MAX_CONCURRENT);
        const batchIndices = validIndices.slice(i, i + MAX_CONCURRENT);
        
        const batchPromises = batch.map(async (id, idx) => {
          // Проверяем кэш (значения в кэше могут быть в wei, если кэш заполнен из syncLocalBetStatusFromContract)
          const cacheKey = id;
          const cached = this.predictionInfoCache.get(cacheKey);
          if (cached && (Date.now() - cached.timestamp) < this.predictionInfoCacheTTL) {
            let p0 = cached.info.pool0 != null ? Number(cached.info.pool0) : 0;
            let p1 = cached.info.pool1 != null ? Number(cached.info.pool1) : 0;
            if (p0 > 1e15 || p1 > 1e15) {
              p0 = p0 / 1e18;
              p1 = p1 / 1e18;
            }
            return { index: batchIndices[idx], pool0: p0, pool1: p1, status: cached.info.status ?? 0 };
          }
          
          try {
            // Простой запрос без Promise.race для избежания проблем
            const info = await this.queueRpcRequest(async () => {
              return await contract.getPredictionInfo(id);
            });
            
            // getPredictionInfo возвращает: channel, totalPool, pool0, pool1, createdAt, lockedAt, status, winningOption, bettorsCount, reports0, reports1
            const pool0 = Number(info.pool0 || info[2] || 0) / 1e18;
            const pool1 = Number(info.pool1 || info[3] || 0) / 1e18;
            // Статус берём из getPredictionInfo — надёжнее, чем массив statuses из getActivePredictions
            let statusFromInfo = info.status !== undefined ? info.status : info[6];
            if (typeof statusFromInfo === 'bigint') statusFromInfo = Number(statusFromInfo);
            else if (typeof statusFromInfo === 'string') statusFromInfo = parseInt(statusFromInfo, 10);
            else statusFromInfo = Number(statusFromInfo ?? 0);
            
            // Сохраняем в кэш (включая статус)
            this.predictionInfoCache.set(cacheKey, {
              info: { pool0, pool1, status: statusFromInfo },
              timestamp: Date.now()
            });
            
            return { index: batchIndices[idx], pool0, pool1, status: statusFromInfo };
          } catch (e) {
            // Если не удалось загрузить — используем 0, статус OPEN (0)
            return { index: batchIndices[idx], pool0: 0, pool1: 0, status: 0 };
          }
        });
        
        // Ждем завершения текущего батча перед следующим с обработкой ошибок
        try {
          const batchResults = await Promise.allSettled(batchPromises);
          batchResults.forEach((result, idx) => {
            if (result.status === 'fulfilled') {
              infoPromises.push(result.value);
            } else {
              // Если запрос не удался, используем значения по умолчанию (OPEN = 0)
              infoPromises.push({ index: batchIndices[idx], pool0: 0, pool1: 0, status: 0 });
            }
          });
        } catch (e) {
          // Если весь батч не удался, добавляем значения по умолчанию для всех
          batchIndices.forEach(idx => {
            infoPromises.push({ index: idx, pool0: 0, pool1: 0, status: 0 });
          });
        }
      }
      
      // Создаем мапу для быстрого доступа (pool0, pool1, status из getPredictionInfo)
      const infoMap = new Map();
      infoPromises.forEach(item => {
        if (item && item.index !== undefined) {
          infoMap.set(item.index, {
            pool0: item.pool0 || 0,
            pool1: item.pool1 || 0,
            status: item.status !== undefined ? Number(item.status) : 0
          });
        }
      });
      
      // Формируем результат: статус берём из getPredictionInfo (надёжнее, чем statuses из getActivePredictions)
      for (let i = 0; i < ids.length; i++) {
        if (!ids[i] || ids[i] === '0x0000000000000000000000000000000000000000000000000000000000000000') {
          continue;
        }
        
        const info = infoMap.get(i) || { pool0: 0, pool1: 0, status: 0 };
        
        try {
          // Приоритет: статус из getPredictionInfo; запасной вариант — массив statuses
          let statusValue = info.status;
          if (statusValue === undefined || isNaN(statusValue)) {
            let s = statuses[i];
            if (typeof s === 'bigint') s = Number(s);
            else if (typeof s === 'string') s = parseInt(s, 10);
            else s = Number(s || 0);
            statusValue = isNaN(s) ? 0 : s;
          }
          
          predictions.push({
            id: ids[i],
            channel: channels[i] || 'unknown',
            totalPool: Number(totalPools[i] || 0) / 1e18,
            startTime: Number(createdAts[i] || 0),
            status: statusValue, // 0 = OPEN, 1 = ACTIVE
            option0Amount: info.pool0 || 0,
            option1Amount: info.pool1 || 0
          });
        } catch (e) {
          // Пропускаем некорректные записи
          continue;
        }
      }
      
      return {
        predictions: predictions,
        totalCount: Number(totalCount || 0)
      };
    } catch (error) {
      // Ошибка при разборе или getPredictionInfo — помечаем как ошибку загрузки
      return { predictions: [], totalCount: 0, error: true };
    }
  }

  attemptImmediateInsert() {
    
    // Сначала проверяем, находимся ли мы на странице стрима
    const isStreamPage = this.isStreamPage();
    if (!isStreamPage) {
      return false;
    }
    
    // Немедленная попытка найти чат и вставить кнопку
    const inserted = this.tryInsertIndicator();
    if (inserted) {
      return true;
    }
    
    // Если не получилось, делаем еще 3 быстрых попытки
    setTimeout(() => this.tryInsertIndicator(), 100);
    setTimeout(() => this.tryInsertIndicator(), 300);
    setTimeout(() => this.tryInsertIndicator(), 500);
    
    return false;
  }

  isStreamPage() {
    const url = window.location.href;
    const isTwitch = url.includes('twitch.tv/');
    
    if (!isTwitch) return false;
    
    const isHomePage = url.endsWith('twitch.tv/') || 
                      url.includes('twitch.tv/directory') ||
                      url.includes('twitch.tv/videos') ||
                      url.includes('twitch.tv/clips');
    
    return !isHomePage;
  }

  startAdvancedPredictionWatcher() {
    
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.checkForPredictionsInElement(node);
            }
          }
        }
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    // Периодический поиск
    setInterval(() => {
      this.scanDocumentForPredictions();
    }, 1000);
    
    // Первоначальный поиск сразу
    this.scanDocumentForPredictions();
  }

  setupPredictionCloseWatcher() {
    this.predictionObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.removedNodes.length > 0) {
          for (const node of mutation.removedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (this.isPredictionWindow(node)) {
                // Очищаем элементы перед очисткой Map
                this.cleanupPolElements(node);
                this.processedPredictions.clear();
                this.polButtons.clear();
                
                setTimeout(() => {
                  this.scanDocumentForPredictions();
                }, 100);
              }
            }
          }
        }
      }
    });
    
    this.predictionObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  isPredictionWindow(element) {
    if (!element || !element.textContent) return false;
    
    const text = element.textContent.toLowerCase().trim();
    
    const hasPredictionKeyword = this.hasKeyword(text, 'prediction');
    const hasPointsKeyword = this.hasKeyword(text, 'points');
    
    const buttons = element.querySelectorAll ? element.querySelectorAll('button') : [];
    const hasBetButtons = buttons.length >= 2;
    
    return (hasPredictionKeyword || hasPointsKeyword) && hasBetButtons;
  }

  scanDocumentForPredictions() {
    this.cleanupProcessedPredictions();
    
    const selectors = [
      '[data-a-target*="prediction"]',
      '[data-test-selector*="prediction"]',
      '[class*="prediction"]',
      '[role="dialog"]',
      '[role="alertdialog"]',
      '.prediction-widget',
      '.prediction-card',
      'div[class*="prediction"]',
      'section[class*="prediction"]',
      '.predictions-panel',
      '.prediction-panel'
    ];
    
    for (const selector of selectors) {
      try {
        const elements = document.querySelectorAll(selector);
        for (const element of elements) {
          if (!document.body.contains(element)) {
            this.processedPredictions.delete(element);
            continue;
          }
          
          if (this.processedPredictions.has(element)) continue;
          
          // КРИТИЧЕСКИ ВАЖНО: Исключаем элементы из UI расширения и чата
          if (element.id && (element.id.includes('twitch-bets') || element.id.includes('chat'))) {
            continue;
          }
          
          const text = element.textContent?.toLowerCase() || '';
          
          // КРИТИЧЕСКИ ВАЖНО: Сразу исключаем окно Power-ups & Rewards
          if (text.includes('power-ups') || text.includes('powerups') || 
              (text.includes('rewards') && (text.includes('message effects') || text.includes('gigantify') || text.includes('emote')))) {
            continue; // Пропускаем окно Power-ups & Rewards
          }
          
          // Проверяем заголовок окна
          const windowTitle = element.querySelector('h1, h2, h3, [class*="title"], [class*="header"]');
          if (windowTitle) {
            const titleText = (windowTitle.textContent || '').toLowerCase();
            if (titleText.includes('power-ups') || titleText.includes('powerups') || 
                (titleText.includes('rewards') && titleText.includes('power'))) {
              continue; // Пропускаем окно Power-ups & Rewards
            }
          }
          
          // Проверяем на завершенный предикт
          const resultKeywords = [
            'prediction ended', 'prediction result', 'see results', 'winner:', 
            'итоги', 'результаты', 'outcome', 'results', 'won', 'победил',
            'prediction results', 'prediction result is', 'completed'
          ];
          
          // Если это завершенный предикт, обрабатываем его отдельно
          if (resultKeywords.some(keyword => text.includes(keyword))) {
            this.handleEndedPrediction(element);
            continue;
          }
          
          // Проверяем на таймер 0:00 или "ended" - это означает что предикт закрылся
          const hasEndedTimer = /(0:00|ended|завершено|закончено)/i.test(text);
          if (hasEndedTimer) {
            // Проверяем, есть ли активный предикт с contractId, который нужно заблокировать
            this.checkAndLockPredictionIfNeeded();
            continue;
          }
          
          const rect = element.getBoundingClientRect();
          if (rect.top < 100 && rect.height < 50) {
            continue;
          }
          
          if (this.isTwitchPrediction(element)) {
            this.processPrediction(element);
            return;
          }
        }
      } catch (error) {
      }
    }
  }

  handleEndedPrediction(predictionElement) {
    if (this.processedPredictions.has(predictionElement)) {
      return;
    }
    
    this.processedPredictions.add(predictionElement);
    
    // Ищем победителя в элементе предикта
    const winningOption = this.getWinningOptionFromEndedPrediction(predictionElement);
    
    if (winningOption !== null) {
      
      // Ищем соответствующий активный предикт по каналу
      const activePredictionId = this.findActivePredictionForChannel(this.currentChannel);
      
      if (activePredictionId) {
        const prediction = this.activePredictions.get(activePredictionId);
        if (prediction && prediction.contractId) {
          // Отправляем отчет о победителе
          const result = winningOption === 0 ? this.config.REPORT_RESULTS.FINISHED_0 : this.config.REPORT_RESULTS.FINISHED_1;
          this.sendReport(prediction.channel, result, prediction.contractId);
        }
      } else {
      }
    }
  }

  findActivePredictionForChannel(channel) {
    let activePredictionId = null;
    let latestTime = 0;
    
    this.activePredictions.forEach((prediction, predictionId) => {
      if (prediction.channel === channel && prediction.status === 'active') {
        if (prediction.startTime > latestTime) {
          latestTime = prediction.startTime;
          activePredictionId = predictionId;
        }
      }
    });
    
    return activePredictionId;
  }
  
  // НОВАЯ ФУНКЦИЯ: Проверка и блокировка предикта если нужно
  async checkAndLockPredictionIfNeeded() {
    // Новый контракт больше НЕ использует отдельный lockPrediction() (он удалён).
    // Ставки закрываются автоматически при первом FINISHED_* отчёте.
    return;
  }

  cleanupProcessedPredictions() {
    const elementsToRemove = [];
    
    for (const element of this.processedPredictions) {
      if (!document.body.contains(element)) {
        elementsToRemove.push(element);
      }
    }
    
    for (const element of elementsToRemove) {
      this.processedPredictions.delete(element);
    }
  }

  checkForPredictionsInElement(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return;
    
    const text = element.textContent?.toLowerCase() || '';
    
    // Проверяем, не завершен ли предикт (многоязычно)
    const hasResult = this.hasKeyword(text, 'result') || this.hasKeyword(text, 'seeResults');
    const hasWinner = this.hasKeyword(text, 'winner');
    const hasEnded = this.hasKeyword(text, 'endedPhrase');
    
    if (hasResult || hasWinner || hasEnded) {
      this.handleEndedPrediction(element);
      return;
    }
    
    if (!this.hasSeeResultsButton(element) && 
        this.isTwitchPrediction(element) && 
        !this.processedPredictions.has(element)) {
      this.processPrediction(element);
      return;
    }
    
    const selectors = ['[data-a-target*="prediction"]', '[class*="prediction"]', '[role="dialog"]'];
    for (const selector of selectors) {
      const children = element.querySelectorAll ? element.querySelectorAll(selector) : [];
      for (const child of children) {
        if (this.isTwitchPrediction(child) && !this.processedPredictions.has(child)) {
          this.processPrediction(child);
          break;
        }
      }
    }
  }

  hasSeeResultsButton(element) {
    if (!element.querySelectorAll) return false;
    
    const buttons = element.querySelectorAll('button');
    for (const button of buttons) {
      const buttonText = button.textContent?.toLowerCase() || '';
      const resultKeywords = [
        'see results', 'view results', 'results', 'outcome',
        'посмотреть результаты', 'результаты', 'итоги'
      ];
      if (resultKeywords.some(keyword => buttonText.includes(keyword))) {
        return true;
      }
    }
    return false;
  }

  isTwitchPrediction(element) {
    if (!element || !element.textContent) return false;
    
    // КРИТИЧЕСКИ ВАЖНО: САМОЕ ПЕРВОЕ - проверяем на Power-ups & Rewards на всех языках
    const text = element.textContent?.toLowerCase() || '';
    const powerUpsKeywords = [
      'power-ups', 'powerups', 'power up',
      'potenziamenti', 'ricompense', 'potenziamenti e ricompense', // Итальянский
      'mejoras', 'recompensas', // Испанский
      'améliorations', 'récompenses', // Французский
      'verbesserungen', 'belohnungen', // Немецкий
      'усиления', 'награды', // Русский
      '파워업', '보상', // Корейский
      'パワーアップ', '報酬' // Японский
    ];
    
    if (powerUpsKeywords.some(keyword => text.includes(keyword))) {
      return false;
    }
    
    // Проверяем заголовок окна
    const windowTitle = element.querySelector('h1, h2, h3, [class*="title"], [class*="header"]');
    if (windowTitle) {
      const titleText = (windowTitle.textContent || '').toLowerCase();
      if (powerUpsKeywords.some(keyword => titleText.includes(keyword)) ||
          (titleText.includes('rewards') && (titleText.includes('power') || titleText.includes('&')))) {
        return false;
      }
    }
    
    // Проверяем наличие элементов Power-ups
    const hasPowerUpsElementsCheck = element.querySelector('[class*="power-up"], [class*="powerup"], [class*="message-effects"], [class*="gigantify"]') !== null;
    if (hasPowerUpsElementsCheck) {
      return false;
    }
    
    // КРИТИЧЕСКИ ВАЖНО: Исключаем элементы из UI расширения и чата
    // Проверяем только сам элемент (не родители), чтобы не влиять на другие части кода
    try {
      // Проверяем только точные совпадения ID
      if (element.id === 'twitch-bets-extension' || 
          element.id === 'twitch-bets-ui' || 
          element.id === 'twitch-bets-indicator') {
        return false;
      }
      // Исключаем элементы чата
      if (element.id && (element.id.includes('chat-input') || element.id.includes('chat-buttons'))) {
        return false;
      }
    } catch (e) {
      // Игнорируем ошибки
    }
    
    // КРИТИЧЕСКИ ВАЖНО: Исключаем элементы из других модальных окон
    const excludedKeywords = [
      'rewards',
      'message effects',
      'gigantify',
      'emote',
      'celebration',
      'channel points store'
    ];
    
    // Если элемент содержит "rewards" И один из ключевых слов Power-ups - это не prediction
    if (text.includes('rewards') && (text.includes('message effects') || text.includes('gigantify') || text.includes('emote') || text.includes('celebration'))) {
      return false;
    }
    
    // Если элемент содержит много ключевых слов из других окон, это не окно prediction
    const excludedCount = excludedKeywords.filter(kw => text.includes(kw)).length;
    if (excludedCount >= 2) {
      return false;
    }
    
    // Проверяем, что это не окно Rewards (обычно содержит "rewards" и список наград)
    if (text.includes('rewards') && (text.includes('message effects') || text.includes('gigantify') || text.includes('emote'))) {
      return false;
    }
    
    // Используем i18n систему для многоязычной поддержки
    const hasPredictionKeyword = this.hasKeyword(text, 'prediction');
    const hasPointsKeyword = this.hasKeyword(text, 'points');
    const hasResultKeyword = this.hasKeyword(text, 'result') || this.hasKeyword(text, 'winner');
    
    // Специфичные для prediction ключевые слова (многоязычно)
    const predictionSpecificKeywords = [
      'submissions closed', 'submission closes', 'submission closed',
      'waiting for result', 'waiting for outcome',
      'prediction started', 'prediction begins',
      'closing in', 'ends in', 'termina en', 'se termine dans', 'endet in',
      'закроется через', 'закрывается через', 'завершится через',
      '종료', '마감', '제출이 마감', '마감됩니다',
      '終了', '締切', '提出が締切',
      'termina tra', 'chiude tra', 'termina in'
    ];
    
    const hasPredictionSpecific = predictionSpecificKeywords.some(keyword => text.includes(keyword));
    
    const buttons = element.querySelectorAll ? element.querySelectorAll('button') : [];
    const hasBetButtons = buttons.length >= 2;
    
    const hasTimer = /\d+:\d+(?::\d+)?/.test(text);
    
    // Если есть признаки завершенного предикта - пропускаем для обычной обработки
    if (hasResultKeyword) {
      return false;
    }
    
    // Проверяем на таймер 0:00 или "ended" - многоязычно
    const hasEndedTimer = /(0:00|0:0)/.test(text) || this.hasKeyword(text, 'ended');
    if (hasEndedTimer) {
      return false;
    }
    
    // Если есть специфичные для prediction ключевые слова - это точно окно prediction
    if (hasPredictionSpecific) {
      return true;
    }
    
    return (
      (hasPredictionKeyword && hasBetButtons) ||
      (hasPointsKeyword && hasBetButtons) ||
      (hasPredictionKeyword && hasTimer) ||
      (hasPointsKeyword && hasTimer)
    );
  }

  processPrediction(predictionElement) {
    // ВАЖНО: Если предикт уже обрабатывался, но элементы могли остаться в DOM,
    // очищаем их перед повторной обработкой
    if (this.processedPredictions.has(predictionElement)) {
      // Проверяем, есть ли элементы в DOM
      const existingElements = predictionElement.querySelectorAll('.twitch-bets-pol-option');
      if (existingElements.length > 0) {
        // Элементы есть - очищаем их и обновляем
        this.cleanupPolElements(predictionElement);
        // Также очищаем записи из polButtons для этого предикта
        const predictionId = predictionElement.id || '';
        for (const [key, buttonData] of this.polButtons.entries()) {
          if (key.includes(predictionId) || 
              (buttonData.element && predictionElement.contains(buttonData.element))) {
            this.polButtons.delete(key);
          }
        }
        // Обновляем элементы
        this.injectPolBets(predictionElement);
      }
      return;
    }
    
    this.processedPredictions.add(predictionElement);
    this.currentPredictionElement = predictionElement;
    
    // Обновляем текущий канал
    this.currentChannel = this.extractChannelName();
    
    // Генерируем уникальный ID для предикта
    this.currentPredictionId = 'prediction_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    
    // Получаем вопрос предикта
    let predictionQuestion = this.extractPredictionQuestion(predictionElement);
    
    // Названия опций из DOM больше не парсим (слишком нестабильно).
    // Для контракта/логики достаточно индексов 0/1.
    const options = ['Option 1', 'Option 2'];
    
    // Сохраняем информацию о предикте
    // startTime в секундах (Unix) — для _referenceStartTime в placeBet
    const startTimeSec = Math.floor(Date.now() / 1000);
    this.activePredictions.set(this.currentPredictionId, {
      element: predictionElement,
      question: predictionQuestion,
      options: options,
      startTime: startTimeSec,
      status: 'active',
      userBets: [],
      channel: this.currentChannel,
      predictionElement: predictionElement,
      contractId: null // Будет установлен при первой ставке
    });
    
    // Вставляем POL ставки сразу (без задержки для ускорения)
    this.injectPolBets(predictionElement);
  }

  extractPredictionQuestion(predictionElement) {
    try {
      // Сначала пытаемся найти вопрос в структурированных элементах DOM
      // Ищем в заголовках, параграфах и других текстовых элементах
      const possibleQuestionSelectors = [
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        '[class*="question"]', '[class*="title"]', '[class*="header"]',
        'p', 'div[role="heading"]', 'span[class*="text"]', 'div[class*="text"]'
      ];
      
      // Ищем вопрос в верхней части предикта (первые 35% высоты)
      const predictionRect = predictionElement.getBoundingClientRect();
      const predictionTop = predictionRect.top;
      const predictionHeight = predictionRect.height;
      const questionAreaBottom = predictionTop + predictionHeight * 0.35;
      
      // Собираем все кандидаты на вопрос
      const questionCandidates = [];
      
      for (const selector of possibleQuestionSelectors) {
        const elements = predictionElement.querySelectorAll(selector);
        for (const elem of elements) {
          const elemRect = elem.getBoundingClientRect();
          const elemText = (elem.textContent || '').trim();
          
          // Пропускаем элементы вне области вопроса (слишком низко)
          if (elemRect.top > questionAreaBottom) {
            continue;
          }
          
          // Пропускаем элементы, которые слишком малы (вероятно, не вопрос)
          if (elemText.length < 3) {
            continue;
          }
          
          // Пропускаем элементы, которые слишком сдвинуты влево или вправо (вероятно, не основной вопрос)
          const predictionCenterX = predictionRect.left + predictionRect.width / 2;
          const elemCenterX = elemRect.left + elemRect.width / 2;
          const horizontalOffset = Math.abs(elemCenterX - predictionCenterX);
          // Если элемент сдвинут более чем на 30% ширины предикта - пропускаем
          if (horizontalOffset > predictionRect.width * 0.3) {
            continue;
          }
          
          const lowerText = elemText.toLowerCase();
          
          // Пропускаем элементы с ключевыми словами, которые не являются вопросом
          const hasPointsKeyword = this.hasKeyword(lowerText, 'points');
          const hasPredictionKeyword = this.hasKeyword(lowerText, 'prediction');
          const hasTimer = /\d+:\d+/.test(lowerText);
          const hasEndsIn = lowerText.includes('ends in') || 
                           lowerText.includes('termina en') || 
                           lowerText.includes('se termine') || 
                           lowerText.includes('endet in') ||
                           lowerText.includes('закроется') || 
                           lowerText.includes('завершится') ||
                           lowerText.includes('termina tra') || 
                           lowerText.includes('chiude');
          
          // Пропускаем элементы с опциями (обычно содержат "Option", "1.", "2." и т.д.)
          const hasOptionMarker = /^[12][\.\)]\s/.test(elemText) || 
                                 lowerText.includes('option') ||
                                 lowerText.includes('опция');
          
          // Пропускаем элементы, которые являются заголовками окна (содержат "Prediction", "Прогноз" и т.д.)
          const isWindowTitle = lowerText === 'prediction' ||
                               lowerText === 'прогноз' ||
                               lowerText === 'pronostico' ||
                               lowerText === 'prédiction' ||
                               lowerText === 'vorhersage';
          
          // Пропускаем элементы, которые содержат только проценты или числа
          const isJustStats = /^[\d\s%\.\-:]+$/.test(elemText) || 
                            lowerText.includes('баллов') ||
                            lowerText.includes('очков') ||
                            lowerText.includes('points') ||
                            lowerText.includes('pts');
          
          if (!hasPointsKeyword && !hasPredictionKeyword && !hasTimer && !hasEndsIn && !hasOptionMarker && !isWindowTitle && !isJustStats) {
            // Нашли потенциальный вопрос - сохраняем с приоритетом
            const question = elemText.substring(0, 200).trim();
            if (question.length > 3) {
              // Приоритет: заголовки выше, чем обычные элементы
              // Также учитываем позицию - элементы ближе к центру верхней части имеют больший приоритет
              const priority = (selector.startsWith('h') || selector.includes('title') || selector.includes('header')) ? 1 : 2;
              const centerDistance = Math.abs(elemRect.left + elemRect.width / 2 - (predictionRect.left + predictionRect.width / 2));
              questionCandidates.push({ text: question, priority, top: elemRect.top, centerDistance });
            }
          }
        }
      }
      
      // Сортируем кандидатов: сначала по приоритету, потом по расстоянию от центра, потом по позиции (выше = лучше)
      questionCandidates.sort((a, b) => {
        if (a.priority !== b.priority) {
          return a.priority - b.priority;
        }
        // Предпочитаем элементы ближе к центру (не сдвинутые влево или вправо)
        if (Math.abs(a.centerDistance - b.centerDistance) > 10) {
          return a.centerDistance - b.centerDistance;
        }
        return a.top - b.top;
      });
      
      // Возвращаем первый (лучший) кандидат
      if (questionCandidates.length > 0) {
        return questionCandidates[0].text;
      }
      
      // Если не нашли в структурированных элементах, используем старый метод
      // Но теперь ищем более тщательно, пропуская служебные строки
      const text = predictionElement.textContent || '';
      const lines = text.split('\n').filter(line => line.trim());
      
      // Ищем первую строку, которая похожа на вопрос (не служебная информация)
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.length < 3) continue;
        
        const lowerLine = line.toLowerCase();
        const hasPointsKeyword = this.hasKeyword(lowerLine, 'points');
        const hasPredictionKeyword = this.hasKeyword(lowerLine, 'prediction');
        const hasTimer = /\d+:\d+/.test(lowerLine);
        const hasEndsIn = lowerLine.includes('ends in') || 
                         lowerLine.includes('termina en') || 
                         lowerLine.includes('se termine') || 
                         lowerLine.includes('endet in') ||
                         lowerLine.includes('закроется') || 
                         lowerLine.includes('завершится') ||
                         lowerLine.includes('termina tra') || 
                         lowerLine.includes('chiude');
        
        const hasOptionMarker = /^[12][\.\)]\s/.test(line) || 
                               lowerLine.includes('option') ||
                               lowerLine.includes('опция');
        
        const isWindowTitle = lowerLine === 'prediction' ||
                             lowerLine === 'прогноз' ||
                             lowerLine === 'pronostico' ||
                             lowerLine === 'prédiction' ||
                             lowerLine === 'vorhersage';
        
        // Пропускаем элементы, которые содержат только проценты, числа или статистику
        const isJustStats = /^[\d\s%\.\-:]+$/.test(line) || 
                          lowerLine.includes('баллов') ||
                          lowerLine.includes('очков') ||
                          lowerLine.includes('points') ||
                          lowerLine.includes('pts');
        
        // Проверяем, что строка не является просто числом или процентом
        const isJustNumber = /^[\d\s%\.]+$/.test(line);
        
        if (!hasPointsKeyword && !hasPredictionKeyword && !hasTimer && !hasEndsIn && 
            !hasOptionMarker && !isWindowTitle && !isJustNumber && !isJustStats && line.length > 3) {
          // Нашли потенциальный вопрос
          return line.substring(0, 200);
        }
      }
      
      return 'Twitch Prediction ' + new Date().toLocaleTimeString();
    } catch (error) {
      return 'Twitch Prediction';
    }
  }

  extractPredictionOptions(_predictionElement) {
    // По просьбе: полностью отключаем поиск/парсинг названий опций из Twitch DOM.
    return ['Option 1', 'Option 2'];
  }

  cleanupPolElements(predictionElement, preserveValid = false) {
    if (!predictionElement) return;
    
    // Удаляем все POL элементы из предикта
    const existingPolElements = predictionElement.querySelectorAll('.twitch-bets-pol-option');
    existingPolElements.forEach(el => {
      try {
        // Если preserveValid = true, проверяем, валиден ли элемент перед удалением
        if (preserveValid) {
          const optionIndex = el.getAttribute('data-option-index');
          const wrapper = el.closest('.twitch-bets-wrapper');
          if (wrapper && optionIndex !== null) {
            const buttonInWrapper = wrapper.querySelector('button');
            // Проверяем, что элемент рядом с правильной кнопкой и не в Power-ups
            if (buttonInWrapper && 
                !buttonInWrapper.textContent?.toLowerCase().includes('power-up') &&
                !buttonInWrapper.textContent?.toLowerCase().includes('potenziamenti') &&
                !buttonInWrapper.textContent?.toLowerCase().includes('ricompense')) {
              // Проверяем, что элемент находится в правильном wrapper для своей опции
              const buttonKey = `${buttonInWrapper.closest('[id]')?.id || 'unknown'}-${optionIndex}`;
              const existingButton = this.polButtons.get(buttonKey);
              // Если элемент в Map и он правильный - не удаляем
              if (existingButton && existingButton.element === el) {
                return; // Пропускаем валидный элемент
              }
            }
          }
        }
        
        // Удаляем элемент из Map если он там есть
        for (const [key, buttonData] of this.polButtons.entries()) {
          if (buttonData.element === el) {
            this.polButtons.delete(key);
            break;
          }
        }
        el.remove();
      } catch (e) {
        // Игнорируем ошибки
      }
    });
    
    // Удаляем wrappers, которые содержат только наши элементы (без кнопок Twitch)
    const existingWrappers = predictionElement.querySelectorAll('.twitch-bets-wrapper');
    existingWrappers.forEach(wrapper => {
      try {
        // Проверяем, есть ли в wrapper кнопка Twitch (не наша)
        const twitchButtons = wrapper.querySelectorAll('button');
        let hasTwitchButton = false;
        for (const btn of twitchButtons) {
          // Проверяем, что это не наша кнопка POL
          if (!btn.classList.contains('twitch-bets-pol-connect') &&
              !btn.classList.contains('twitch-bets-place-pol-bet') &&
              !btn.classList.contains('twitch-bets-quick-amount')) {
            hasTwitchButton = true;
            break;
          }
        }
        
        // Если в wrapper нет кнопки Twitch, удаляем его полностью
        // Если есть кнопка Twitch, удаляем только наши POL элементы из него
        if (!hasTwitchButton) {
          wrapper.remove();
        } else {
          // Удаляем только наши элементы, оставляя кнопку Twitch
          const polElementsInWrapper = wrapper.querySelectorAll('.twitch-bets-pol-option');
          polElementsInWrapper.forEach(el => {
            try {
              // Удаляем элемент из Map если он там есть
              for (const [key, buttonData] of this.polButtons.entries()) {
                if (buttonData.element === el) {
                  this.polButtons.delete(key);
                  break;
                }
              }
              el.remove();
            } catch (e) {
              // Игнорируем ошибки
            }
          });
        }
      } catch (e) {
        // Игнорируем ошибки
      }
    });
  }

  injectPolBets(predictionElement) {
    if (!predictionElement) return;
    
    // КРИТИЧЕСКИ ВАЖНО: Проверяем, находится ли предикт в верхней части чата
    // Если элемент находится слишком высоко (в верхних 250px экрана), не вставляем POL элементы
    const predictionRect = predictionElement.getBoundingClientRect();
    if (predictionRect.top < 250 && predictionRect.height < 100) {
      // Это верхний виджет в чате - не вставляем туда POL элементы
      this.cleanupPolElements(predictionElement);
      return;
    }
    
    // Дополнительная проверка: ищем признаки верхнего виджета по тексту
    const predictionText = (predictionElement.textContent || '').toLowerCase();
    // Проверяем наличие паттернов верхнего виджета (например, "0 vs 0 Predict")
    const isTopWidget = /\d+\s*(vs|против)\s*\d+\s*(predict|предикт)/i.test(predictionText) ||
                       (predictionText.includes('vs') && predictionText.includes('predict') && predictionRect.top < 300);
    
    if (isTopWidget) {
      // Это верхний виджет - не вставляем туда POL элементы
      this.cleanupPolElements(predictionElement);
      return;
    }
    
    // Debounce: предотвращаем множественные вызовы в течение короткого времени
    const now = Date.now();
    if (this._lastInjectTime && (now - this._lastInjectTime) < 200) {
      // Отменяем предыдущий вызов и планируем новый
      if (this._injectPolBetsDebounce) {
        clearTimeout(this._injectPolBetsDebounce);
      }
      this._injectPolBetsDebounce = setTimeout(() => {
        this.injectPolBets(predictionElement);
      }, 200);
      return;
    }
    this._lastInjectTime = now;
    
    // Быстрая проверка закрытого предикта (только по тексту, без сложных проверок) - многоязычно
    const isClosed = this.hasKeyword(predictionText, 'winner') ||
                    this.hasKeyword(predictionText, 'endedPhrase') ||
                    predictionText.includes('nobody thought');
    
    if (isClosed) {
      // Удаляем существующие POL элементы если предикт закрыт
      this.cleanupPolElements(predictionElement);
      return;
    }
    
    // КРИТИЧЕСКИ ВАЖНО: Проверяем статус контракта для текущего канала
    // Если предикт ACTIVE (1) или RESOLVED (2), не показываем виджет
    const activePredictionId = this.findActivePredictionForChannel(this.currentChannel);
    if (activePredictionId) {
      const prediction = this.activePredictions.get(activePredictionId);
      if (prediction && prediction.contractId) {
        // Проверяем синхронно через кэш статуса
        const cacheKey = prediction.contractId;
        const cachedStatus = this.statusCache.get(cacheKey);
        if (cachedStatus && (Date.now() - cachedStatus.timestamp) < this.statusCacheTTL) {
          if (cachedStatus.status === 'active' || cachedStatus.status === 'resolved') {
            // Удаляем существующие POL элементы если предикт активен или закрыт
            this.cleanupPolElements(predictionElement);
            return;
          }
        }
        
        // Если кэша нет, проверяем асинхронно и удаляем элементы если нужно
        this.getPredictionStatus(prediction.contractId).then(status => {
          // Статусы: 'open' = 0, 'active' = 1, 'resolved' = 2, 'cancelled' = 3
          if (status === 'active' || status === 'resolved') {
            // Удаляем существующие POL элементы если предикт активен или закрыт
            this.cleanupPolElements(predictionElement);
          }
        }).catch(() => {
          // Игнорируем ошибки при проверке статуса
        });
      }
    }
    
    // Дополнительная проверка: ищем все активные предикты для текущего канала
    // и проверяем их статусы
    for (const [predId, pred] of this.activePredictions.entries()) {
      if (pred.channel === this.currentChannel && pred.contractId) {
        const cacheKey = pred.contractId;
        const cachedStatus = this.statusCache.get(cacheKey);
        if (cachedStatus && (Date.now() - cachedStatus.timestamp) < this.statusCacheTTL) {
          if (cachedStatus.status === 'active' || cachedStatus.status === 'resolved') {
            // Если есть активный или закрытый предикт с контрактом, не показываем виджет
            this.cleanupPolElements(predictionElement);
            return;
          }
        }
      }
    }
    
    // Создаем уникальный ID для предикта если его нет
    if (!predictionElement.id) {
      predictionElement.id = `prediction-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }
    
    const predictionId = predictionElement.id;
    
    // Проверяем, не обрабатывается ли уже этот предикт
    const processingKey = `pol-inject-${predictionId}`;
    if (this.polButtons.has(processingKey)) {
      // Проверяем, может быть элементы уже созданы и в DOM
      const existingElements = predictionElement.querySelectorAll('.twitch-bets-pol-option');
      if (existingElements.length >= 2) {
        // Элементы уже есть - не обрабатываем повторно
        return;
      }
      // Если элементов нет, но идет обработка - ждем
      return;
    }
    
    // ВАЖНО: Перед созданием новых элементов проверяем существующие элементы
    // НЕ удаляем элементы, которые уже существуют и находятся в правильном месте
    // Это предотвращает мигание при клике на custom amount
    const existingElements = predictionElement.querySelectorAll('.twitch-bets-pol-option');
    if (existingElements.length > 0) {
      // Проверяем, все ли элементы в правильном месте и валидны
      let validElementsCount = 0;
      existingElements.forEach(el => {
        const optionIndex = el.getAttribute('data-option-index');
        const wrapper = el.closest('.twitch-bets-wrapper');
        if (wrapper && optionIndex !== null) {
          const buttonInWrapper = wrapper.querySelector('button');
          // Проверяем, что элемент рядом с правильной кнопкой и не в Power-ups
          if (buttonInWrapper && 
              !buttonInWrapper.textContent?.toLowerCase().includes('power-up') &&
              !buttonInWrapper.textContent?.toLowerCase().includes('potenziamenti') &&
              !buttonInWrapper.textContent?.toLowerCase().includes('ricompense')) {
            // Проверяем, что элемент находится в правильном wrapper для своей опции
            const buttonKey = `${buttonInWrapper.closest('[id]')?.id || 'unknown'}-${optionIndex}`;
            const existingButton = this.polButtons.get(buttonKey);
            if (existingButton && existingButton.element === el) {
              validElementsCount++;
            } else {
              // Элемент существует, но не в Map - возможно, это старый элемент
              // Проверяем, что он действительно рядом с кнопкой ставки
              const buttonText = buttonInWrapper.textContent?.toLowerCase() || '';
              if (buttonText.includes('points') || buttonText.includes('pts') || 
                  /\d+\s*(points|pts)/i.test(buttonText)) {
                validElementsCount++;
              }
            }
          }
        }
      });
      
      // Если все элементы валидны и их ровно 2, не удаляем их и не пересоздаем
      if (validElementsCount === 2 && existingElements.length === 2) {
        // Элементы уже есть и они в правильном месте - не обрабатываем повторно
        // Просто обновляем их состояние в Map
        existingElements.forEach(el => {
          const optionIndex = el.getAttribute('data-option-index');
          const wrapper = el.closest('.twitch-bets-wrapper');
          if (wrapper) {
            const buttonInWrapper = wrapper.querySelector('button');
            if (buttonInWrapper) {
              // Используем более надежный способ создания ключа
              const containerId = buttonInWrapper.closest('[id]')?.id || 
                                 buttonInWrapper.closest('[data-a-target]')?.getAttribute('data-a-target') ||
                                 'unknown';
              const buttonKey = `${containerId}-${optionIndex}`;
              const walletData = this.getWalletDataSync();
              this.polButtons.set(buttonKey, {
                element: el,
                connected: walletData.connected,
                isCustom: buttonInWrapper.textContent?.toLowerCase().includes('custom') || false
              });
            }
          }
        });
        // НЕ удаляем флаг обработки сразу, чтобы предотвратить повторные вызовы
        // Удалим его через некоторое время
        setTimeout(() => {
          if (this.polButtons.has(processingKey)) {
            this.polButtons.delete(processingKey);
          }
        }, 2000); // Увеличиваем до 2 секунд для надежности
        return;
      }
      
      // Если есть валидные элементы, но не все - удаляем только невалидные
      // И сохраняем валидные в Map
      if (validElementsCount > 0) {
        existingElements.forEach(el => {
          const optionIndex = el.getAttribute('data-option-index');
          const wrapper = el.closest('.twitch-bets-wrapper');
          let isValid = false;
          
          if (wrapper && optionIndex !== null) {
            const buttonInWrapper = wrapper.querySelector('button');
            if (buttonInWrapper && 
                !buttonInWrapper.textContent?.toLowerCase().includes('power-up') &&
                !buttonInWrapper.textContent?.toLowerCase().includes('potenziamenti') &&
                !buttonInWrapper.textContent?.toLowerCase().includes('ricompense')) {
              const buttonText = buttonInWrapper.textContent?.toLowerCase() || '';
              // Проверяем, что это кнопка ставки (содержит points/pts или числа)
              if (buttonText.includes('points') || buttonText.includes('pts') || 
                  /\d+\s*(points|pts)/i.test(buttonText) ||
                  buttonText.includes('custom') || buttonText.includes('amount')) {
                isValid = true;
                // Сохраняем в Map даже если его там не было
                const containerId = buttonInWrapper.closest('[id]')?.id || 
                                   buttonInWrapper.closest('[data-a-target]')?.getAttribute('data-a-target') ||
                                   'unknown';
                const buttonKey = `${containerId}-${optionIndex}`;
                const walletData = this.getWalletDataSync();
                this.polButtons.set(buttonKey, {
                  element: el,
                  connected: walletData.connected,
                  isCustom: buttonText.includes('custom') || false
                });
              }
            }
          }
          
          // Удаляем только невалидные элементы
          if (!isValid) {
            try {
              for (const [key, buttonData] of this.polButtons.entries()) {
                if (buttonData.element === el) {
                  this.polButtons.delete(key);
                  break;
                }
              }
              el.remove();
            } catch (e) {
              // Игнорируем ошибки
            }
          }
        });
        
        // Если после удаления невалидных элементов осталось 2 валидных - не создаем новые
        const remainingElements = predictionElement.querySelectorAll('.twitch-bets-pol-option');
        if (remainingElements.length === 2) {
          setTimeout(() => {
            if (this.polButtons.has(processingKey)) {
              this.polButtons.delete(processingKey);
            }
          }, 1000);
          return;
        }
      }
    }
    
    // КРИТИЧЕСКИ ВАЖНО: НЕ удаляем элементы, если они уже существуют и валидны
    // Это предотвращает мигание при клике на custom amount
    // НО если элементов нет или они невалидны - удаляем старые перед созданием новых
    if (existingElements.length === 0 || validElementsCount < 2) {
      // Удаляем только если нет элементов или их недостаточно
      if (!this.polButtons.has(processingKey)) {
        this.cleanupPolElements(predictionElement, true); // preserveValid = true
      }
    }
    
    // Помечаем как обрабатываемый (временно)
    this.polButtons.set(processingKey, { element: null, connected: false, isCustom: false });
    
    // Сразу ищем опции без задержки
    try {
      const options = this.findPredictionOptions(predictionElement);
      
      if (options.length === 0) {
        // Быстрый retry
        setTimeout(() => {
          // Проверяем, что предикт все еще существует
          if (!document.body.contains(predictionElement)) {
            this.polButtons.delete(processingKey);
            return;
          }
          
          const retryOptions = this.findPredictionOptions(predictionElement);
          if (retryOptions.length > 0) {
            const walletData = this.getWalletDataSync();
            const mainOptions = this.filterMainOptions(retryOptions, predictionElement);
            this.updatePolBets(mainOptions, walletData);
          }
          // Удаляем флаг обработки после небольшой задержки
          setTimeout(() => this.polButtons.delete(processingKey), 500);
        }, 10);
        return;
      }
      
      const walletData = this.getWalletDataSync();
      const mainOptions = this.filterMainOptions(options, predictionElement);
      
      // Обновляем элементы только если их действительно нужно создать/обновить
      this.updatePolBets(mainOptions, walletData);
      
      // Удаляем флаг обработки после задержки, чтобы предотвратить множественные вызовы
      setTimeout(() => this.polButtons.delete(processingKey), 500);
    } catch (error) {
      // Удаляем флаг обработки при ошибке
      this.polButtons.delete(processingKey);
    }
  }

  updatePolBets(options, walletData) {
    // Обновляем текущий канал перед созданием элементов
    this.currentChannel = this.extractChannelName();
    
    // ОГРАНИЧИВАЕМ: обрабатываем только 2 опции (левая и правая)
    if (options.length > 2) {
      options = options.slice(0, 2);
    }
    
    // Собираем все существующие элементы ДО начала операций - защищаем их от удаления
    const protectedElements = new Set();
    for (const [key, buttonData] of this.polButtons.entries()) {
      if (buttonData.element && buttonData.element.parentNode && document.body.contains(buttonData.element)) {
        protectedElements.add(buttonData.element);
      }
    }
    
    // Дополнительно: защищаем все элементы, которые находятся в правильном месте
    // даже если они не в Map (могут быть созданы ранее, но Map был очищен)
    options.forEach((option, idx) => {
      const twitchButton = option.element;
      let buttonWrapper = twitchButton.closest('.twitch-bets-wrapper');
      if (!buttonWrapper) {
        const parent = twitchButton.parentElement;
        if (parent) {
          const allWrappers = parent.querySelectorAll('.twitch-bets-wrapper');
          for (const w of allWrappers) {
            const btnInW = w.querySelector('button');
            if (btnInW === twitchButton) {
              buttonWrapper = w;
              break;
            }
          }
        }
      }
      
      if (buttonWrapper) {
        const existingElement = buttonWrapper.querySelector(`.twitch-bets-pol-option[data-option-index="${idx}"]`);
        if (existingElement && existingElement.parentNode === buttonWrapper) {
          // Элемент в правильном месте - защищаем его
          protectedElements.add(existingElement);
        }
      }
    });
    
    // Создаем элементы синхронно для максимальной скорости
    for (let idx = 0; idx < options.length && idx < 2; idx++) {
      const option = options[idx];
      const index = idx;
      const buttonKey = `${option.container?.id || 'unknown'}-${index}`;
      
      // Проверяем, существует ли элемент в Map и он в DOM
      let polElement = null;
      if (this.polButtons.has(buttonKey)) {
        const existingButton = this.polButtons.get(buttonKey);
        if (existingButton.element && existingButton.element.parentNode && document.body.contains(existingButton.element)) {
          // Проверяем, что элемент рядом с правильной кнопкой Twitch
          const twitchButton = option.element;
          const elementWrapper = existingButton.element.closest('.twitch-bets-wrapper');
          let buttonWrapper = twitchButton.closest('.twitch-bets-wrapper');
          
          // Если не нашли через closest, ищем в родительском контейнере
          if (!buttonWrapper) {
            const parent = twitchButton.parentElement;
            if (parent) {
              const allWrappers = parent.querySelectorAll('.twitch-bets-wrapper');
              for (const w of allWrappers) {
                const btnInW = w.querySelector('button');
                if (btnInW === twitchButton) {
                  buttonWrapper = w;
                  break;
                }
              }
            }
          }
          
          if (elementWrapper && elementWrapper === buttonWrapper && elementWrapper.contains(twitchButton)) {
            // Элемент в правильном месте - используем его, НЕ пересоздаем
            polElement = existingButton.element;
            protectedElements.add(polElement);
            // Обновляем данные в Map на случай изменения состояния кошелька
            this.polButtons.set(buttonKey, {
              element: polElement,
              connected: walletData.connected,
              isCustom: twitchButton.textContent?.toLowerCase().includes('custom') || false
            });
            continue;
          }
        }
      }
      
      // Ищем существующий элемент в DOM рядом с кнопкой
      const twitchButton = option.element;
      // Ищем wrapper, который содержит именно нашу кнопку Twitch
      let buttonWrapper = twitchButton.closest('.twitch-bets-wrapper');
      // Проверяем, что найденный wrapper содержит именно нашу кнопку
      if (buttonWrapper) {
        const buttonInWrapper = buttonWrapper.querySelector('button');
        if (buttonInWrapper !== twitchButton) {
          // Это не наш wrapper, ищем дальше
          buttonWrapper = null;
          // Ищем среди всех wrappers в родительском контейнере
          const parent = twitchButton.parentElement;
          if (parent) {
            const allWrappers = parent.querySelectorAll('.twitch-bets-wrapper');
            for (const w of allWrappers) {
              const btnInW = w.querySelector('button');
              if (btnInW === twitchButton) {
                buttonWrapper = w;
                break;
              }
            }
          }
        }
      } else {
        // Если не нашли через closest, ищем в родительском контейнере
        const parent = twitchButton.parentElement;
        if (parent) {
          const allWrappers = parent.querySelectorAll('.twitch-bets-wrapper');
          for (const w of allWrappers) {
            const btnInW = w.querySelector('button');
            if (btnInW === twitchButton) {
              buttonWrapper = w;
              break;
            }
          }
        }
      }
      
      if (buttonWrapper) {
        const existingInWrapper = buttonWrapper.querySelector(`.twitch-bets-pol-option[data-option-index="${index}"]`);
        if (existingInWrapper && existingInWrapper.parentNode === buttonWrapper) {
          // Элемент уже существует в правильном месте
          polElement = existingInWrapper;
          protectedElements.add(polElement);
          this.polButtons.set(buttonKey, {
            element: polElement,
            connected: walletData.connected,
            isCustom: twitchButton.textContent?.toLowerCase().includes('custom') || false
          });
          continue;
        }
      }
      
      // Удаляем ТОЛЬКО дубликаты из wrapper этой конкретной кнопки
      // НЕ удаляем элементы, которые уже существуют и находятся в правильном месте
      if (buttonWrapper) {
        const allPolElementsInWrapper = buttonWrapper.querySelectorAll('.twitch-bets-pol-option');
        allPolElementsInWrapper.forEach(el => {
          if (el && el.parentNode) {
            const elOptionIndex = el.getAttribute('data-option-index');
            
            // Пропускаем защищенные элементы
            if (protectedElements.has(el)) {
              return;
            }
            
            // Пропускаем элемент, который мы уже нашли выше (existingInWrapper)
            if (el === existingInWrapper || el === polElement) {
              return;
            }
            
            // Проверяем, находится ли элемент в правильном месте
            // Если элемент находится в правильном wrapper рядом с правильной кнопкой - не удаляем
            const buttonInWrapper = buttonWrapper.querySelector('button');
            const isInCorrectPlace = buttonInWrapper === twitchButton && 
                                    el.closest('.twitch-bets-wrapper') === buttonWrapper;
            
            // Удаляем только если:
            // 1. Это дубликат с правильным index (но не тот, который мы нашли выше) И элемент не в правильном месте
            // 2. Это элемент с неправильным index в этом wrapper
            const shouldRemove = !isInCorrectPlace && (
              (elOptionIndex === String(index) && el !== existingInWrapper && el !== polElement) ||
              (elOptionIndex !== String(index) && elOptionIndex !== null)
            );
            
            if (shouldRemove) {
              try {
                // Удаляем из Map
                for (const [key, buttonData] of this.polButtons.entries()) {
                  if (buttonData.element === el) {
                    this.polButtons.delete(key);
                    break;
                  }
                }
                el.remove();
              } catch (e) {
                // Игнорируем ошибки
              }
            }
          }
        });
      }
      
      // Также удаляем элементы с правильным index из других wrapper'ов (неправильное место)
      if (buttonWrapper) {
        const predictionElement = twitchButton.closest('[role="dialog"], [class*="prediction"], [data-a-target*="prediction"]') || 
                                 document.querySelector('[role="dialog"]');
        if (predictionElement) {
          const allWrappers = predictionElement.querySelectorAll('.twitch-bets-wrapper');
          allWrappers.forEach(w => {
            if (w !== buttonWrapper) {
              const wrongElements = w.querySelectorAll(`.twitch-bets-pol-option[data-option-index="${index}"]`);
              wrongElements.forEach(el => {
                if (el && !protectedElements.has(el) && el.parentNode) {
                  try {
                    // Удаляем из Map
                    for (const [key, buttonData] of this.polButtons.entries()) {
                      if (buttonData.element === el) {
                        this.polButtons.delete(key);
                        break;
                      }
                    }
                    el.remove();
                  } catch (e) {
                    // Игнорируем ошибки
                  }
                }
              });
            }
          });
        }
      }
      
      // Удаляем из Map только если элемент не в правильном месте
      if (this.polButtons.has(buttonKey)) {
        const oldButton = this.polButtons.get(buttonKey);
        if (oldButton.element) {
          const oldWrapper = oldButton.element.closest('.twitch-bets-wrapper');
          if (oldWrapper !== buttonWrapper || !oldWrapper?.contains(twitchButton)) {
            // Элемент не в правильном месте - удаляем из Map, но не из DOM (он уже удален выше если был дубликатом)
            this.polButtons.delete(buttonKey);
          }
        }
      }
      
      // ФИНАЛЬНАЯ ПРОВЕРКА: перед созданием нового элемента проверяем, нет ли уже элемента в правильном wrapper
      if (buttonWrapper) {
        const finalCheck = buttonWrapper.querySelector(`.twitch-bets-pol-option[data-option-index="${index}"]`);
        if (finalCheck && finalCheck.parentNode === buttonWrapper) {
          // Элемент уже существует в правильном месте - используем его
          polElement = finalCheck;
          protectedElements.add(polElement);
          this.polButtons.set(buttonKey, {
            element: polElement,
            connected: walletData.connected,
            isCustom: twitchButton.textContent?.toLowerCase().includes('custom') || false
          });
          continue;
        }
      }
      
      // Создаем новый элемент - он сам найдет/создаст правильный wrapper
      try {
        polElement = this.createPolBetElement(option, index, walletData, protectedElements);
      } catch (error) {
        continue;
      }
      
      if (polElement) {
        protectedElements.add(polElement);
        this.polButtons.set(buttonKey, {
          element: polElement,
          connected: walletData.connected,
          isCustom: twitchButton.textContent?.toLowerCase().includes('custom') || false
        });
      }
    }
    
    // Сразу запускаем обновление процентов (без await чтобы не блокировать)
    this.updateAllPolPercentages();
  }

  getWalletDataSync() {
    return {
      balance: this.userBalance.pol || 0,
      address: this.walletAddress || '',
      connected: this.isConnected || false
    };
  }

  findPredictionOptions(predictionElement) {
    const options = [];
    
    // КРИТИЧЕСКИ ВАЖНО: Проверяем, находится ли предикт в верхней части чата
    // Если элемент находится слишком высоко (в верхних 250px экрана), не ищем опции
    const predictionRect = predictionElement.getBoundingClientRect();
    if (predictionRect.top < 250 && predictionRect.height < 100) {
      // Это верхний виджет в чате - не обрабатываем его
      return [];
    }
    
    // Дополнительная проверка: ищем признаки верхнего виджета по тексту
    const predictionText = (predictionElement.textContent || '').toLowerCase();
    // Проверяем наличие паттернов верхнего виджета (например, "0 vs 0 Predict")
    const isTopWidget = /\d+\s*(vs|против)\s*\d+\s*(predict|предикт)/i.test(predictionText) ||
                       (predictionText.includes('vs') && predictionText.includes('predict') && predictionRect.top < 300);
    
    if (isTopWidget) {
      // Это верхний виджет - не обрабатываем его
      return [];
    }
    
    // Проверяем, что это не окно Power-ups
    const powerUpsKeywords = [
      'potenziamenti', 'ricompense', 'potenziamenti e ricompense',
      'power-ups', 'powerups', 'power up',
      'mejoras', 'recompensas',
      'améliorations', 'récompenses',
      'verbesserungen', 'belohnungen',
      'усиления', 'награды',
      '파워업', '보상',
      'パワーアップ', '報酬'
    ];
    
    if (powerUpsKeywords.some(keyword => predictionText.includes(keyword))) {
      // Дополнительная проверка: если есть элементы Power-ups
      if (predictionElement.querySelector('[class*="power-up"], [class*="powerup"], [class*="message-effects"], [class*="gigantify"]')) {
        return []; // Не обрабатываем окно Power-ups
      }
    }
    
    // Получаем границы предикта для фильтрации
    const predictionTop = predictionRect.top;
    const predictionBottom = predictionRect.bottom;
    const predictionHeight = predictionRect.height;
    const predictionCenterY = predictionTop + predictionHeight / 2;
    
    // Ищем только кнопки в НИЖНЕЙ половине предикта (не в заголовке)
    const buttons = predictionElement.querySelectorAll('button');
    buttons.forEach(button => {
      const text = button.textContent?.toLowerCase().trim() || '';
      
      // Пропускаем кнопки Power-ups
      if (powerUpsKeywords.some(keyword => text.includes(keyword))) {
        return;
      }
      
      // Пропускаем кнопку "выбрать свое количество" на русском - это заголовок, а не кнопка ставки
      const isCustomAmountHeader = text.includes('выбрать свое количество') ||
                                   text.includes('choose your own') ||
                                   text.includes('elegir tu propia') ||
                                   text.includes('choisir votre propre');
      
      const isOption = text.includes('points') || 
                      text.includes('pts') || 
                      text.includes('баллов') ||
                      text.includes('очков') ||
                      /\d+\s*(points|pts|баллов|очков)/i.test(text);
      
      const isResultsButton = text.includes('see results') || 
                             text.includes('outcome') || 
                             text.includes('results') ||
                             text.includes('prediction result') ||
                             text.includes('посмотреть результаты') ||
                             text.includes('результаты') ||
                             text.includes('итоги');
      
      // Пропускаем кнопку "Голосовать" на русском - это не кнопка ставки за баллы
      const isVoteButton = text === 'голосовать' || text === 'vote' || text === 'votar' || text === 'voter';
      
      if (isOption && !isResultsButton && !isCustomAmountHeader && !isVoteButton && button.offsetParent !== null) {
        // Проверяем, что кнопка находится в нижней части предикта
        const buttonRect = button.getBoundingClientRect();
        const buttonCenterY = buttonRect.top + buttonRect.height / 2;
        const buttonTop = buttonRect.top;
        
        // Ищем кнопку "Predict" в заголовке для более точной фильтрации
        let headerPredictButton = null;
        const allButtons = predictionElement.querySelectorAll('button');
        for (const btn of allButtons) {
          const btnText = btn.textContent?.toLowerCase() || '';
          if (btnText.includes('predict') && 
              !btnText.includes('points') && 
              !btnText.includes('pts') && 
              !btnText.includes('баллов') &&
              !btnText.includes('очков') &&
              !/\d+\s*(points|pts|баллов|очков)/i.test(btnText) &&
              !/\d+/.test(btnText)) { // Не содержит цифр
            const btnRect = btn.getBoundingClientRect();
            if (btnRect.top < predictionTop + predictionHeight * 0.33) {
              headerPredictButton = btn;
              break;
            }
          }
        }
        
        if (headerPredictButton) {
          // Если есть кнопка "Predict" в заголовке, проверяем расстояние
          const headerRect = headerPredictButton.getBoundingClientRect();
          const headerBottom = headerRect.bottom;
          // Пропускаем только кнопки слишком близко к заголовку (50px)
          // Это предотвращает появление элементов в верхней части чата
          if (buttonTop < headerBottom + 50) {
            return;
          }
        }
        // Если нет кнопки "Predict" в заголовке, НЕ фильтруем - берем все найденные кнопки ставок
        // Это позволяет элементам появляться в custom amount и под обычными кнопками
        
        let container = button.parentElement;
        for (let i = 0; i < 3; i++) {
          if (container && container.tagName !== 'BUTTON') {
            break;
          }
          container = container?.parentElement;
        }
        
        if (container) {
          options.push({
            element: button,
            container: container,
            rect: buttonRect
          });
        }
      }
    });
    
    // Если не нашли в нижней части, ищем в группах кнопок (но тоже только в нижней части)
    if (options.length === 0) {
      // Сначала находим кнопку "Predict" в заголовке (если есть) - многоязычно
      let headerPredictButton = null;
      const allButtons = predictionElement.querySelectorAll('button');
      for (const btn of allButtons) {
        const btnText = btn.textContent?.toLowerCase() || '';
        // Проверяем наличие ключевых слов prediction на всех языках
        const hasPredictKeyword = this.hasKeyword(btnText, 'prediction');
        // Исключаем кнопки со словами points/pts на всех языках
        const hasPointsKeyword = this.hasKeyword(btnText, 'points');
        // Исключаем кнопки с числами
        const hasNumber = /\d+/.test(btnText);
        
        if (hasPredictKeyword && !hasPointsKeyword && !hasNumber) {
          const btnRect = btn.getBoundingClientRect();
          if (btnRect.top < predictionTop + predictionHeight * 0.33) {
            headerPredictButton = btn;
            break;
          }
        }
      }
      
      // Определяем порог для проверки
      let checkThreshold = 0;
      if (headerPredictButton) {
        const headerRect = headerPredictButton.getBoundingClientRect();
        checkThreshold = headerRect.bottom + 50; // Возвращаем к 50px
      }
      // Если нет кнопки "Predict" в заголовке, не фильтруем - берем все группы
      
      const buttonGroups = predictionElement.querySelectorAll('[role="group"], [class*="group"], [class*="buttons"]');
      buttonGroups.forEach(group => {
        const groupRect = group.getBoundingClientRect();
        const groupCenterY = groupRect.top + groupRect.height / 2;
        const groupTop = groupRect.top;
        
        // Пропускаем группы слишком близко к заголовку (только если есть кнопка "Predict")
        if (headerPredictButton && (groupTop < checkThreshold || groupCenterY < checkThreshold)) {
          return;
        }
        
        const groupButtons = group.querySelectorAll('button');
        if (groupButtons.length >= 2) {
          groupButtons.forEach((button, index) => {
            if (index < 2) {
              const buttonRect = button.getBoundingClientRect();
              const buttonCenterY = buttonRect.top + buttonRect.height / 2;
              const buttonTop = buttonRect.top;
              
              // Дополнительная проверка для каждой кнопки (только если есть кнопка "Predict")
              if (!headerPredictButton || (buttonCenterY >= checkThreshold && buttonTop >= checkThreshold)) {
                const container = button.parentElement;
                if (container) {
                  options.push({
                    element: button,
                    container: container,
                    rect: buttonRect
                  });
                }
              }
            }
          });
        }
      });
    }
    
    // Фильтруем, оставляя только 2 нижние опции
    return this.filterMainOptions(options, predictionElement);
  }

  filterMainOptions(options, predictionElement) {
    if (options.length <= 2) {
      return options;
    }
    
    const predictionRect = predictionElement.getBoundingClientRect();
    const predictionCenterY = predictionRect.top + predictionRect.height / 2;
    
    // Сортируем по Y координате (снизу вверх) и берем 2 самых нижних
    const sortedOptions = [...options].sort((a, b) => {
      const aY = a.rect.top + a.rect.height / 2;
      const bY = b.rect.top + b.rect.height / 2;
      return bY - aY; // Сначала самые нижние
    });
    
    // Берем только 2 самых нижних опции
    return sortedOptions.slice(0, 2);
  }

  createPolBetElement(option, index, walletData, trackedElements = new Set()) {
    const { element: twitchButton, container } = option;
    
    const buttonText = twitchButton.textContent?.toLowerCase() || '';
    
    // Быстрая проверка Power-ups на всех языках (только по тексту кнопки, без обхода родителей)
    const buttonTextLower = buttonText;
    const powerUpsKeywords = [
      'power-up', 'powerup', 'power up', 'reward',
      'potenziamenti', 'ricompense', // Итальянский
      'mejoras', 'recompensas', // Испанский
      'améliorations', 'récompenses', // Французский
      'verbesserungen', 'belohnungen', // Немецкий
      'награда', 'усиления', // Русский
      '파워업', '보상', // Корейский
      'パワーアップ', '報酬' // Японский
    ];
    
    if (powerUpsKeywords.some(keyword => buttonTextLower.includes(keyword))) {
      return null;
    }
    
    // Дополнительная проверка: проверяем родительский контейнер на наличие Power-ups
    let parent = twitchButton.parentElement;
    for (let i = 0; i < 5 && parent; i++) {
      const parentText = (parent.textContent || '').toLowerCase();
      if (powerUpsKeywords.some(keyword => parentText.includes(keyword))) {
        // Проверяем, что это действительно Power-ups, а не просто случайное совпадение
        if (parentText.includes('potenziamenti') || parentText.includes('ricompense') ||
            parentText.includes('message effects') || parentText.includes('gigantify') ||
            parentText.includes('effetti del messaggio') || parentText.includes('ingigantire')) {
          return null;
        }
      }
      parent = parent.parentElement;
    }
    
    // КРИТИЧЕСКАЯ ПРОВЕРКА: не создаем элементы для кнопок в верхней части предикта
    // Ищем родительский элемент предикта
    let predictionElement = twitchButton.closest('[class*="prediction"], [class*="Prediction"], [role="dialog"]');
    if (!predictionElement) {
      // Если не нашли, ищем по структуре
      let parent = twitchButton.parentElement;
      for (let i = 0; i < 10 && parent; i++) {
        if (parent.classList && (
          Array.from(parent.classList).some(c => c.toLowerCase().includes('prediction')) ||
          parent.getAttribute('role') === 'dialog'
        )) {
          predictionElement = parent;
          break;
        }
        parent = parent.parentElement;
      }
    }
    
    if (predictionElement) {
      const predictionRect = predictionElement.getBoundingClientRect();
      const buttonRect = twitchButton.getBoundingClientRect();
      const buttonTop = buttonRect.top;
      const predictionTop = predictionRect.top;
      const predictionHeight = predictionRect.height;
      
      // ПРОВЕРКА: не создаем элементы для кнопок в верхней части предикта
      // Ищем кнопку "Predict" в заголовке (без "points" в тексте и без цифр)
      const allButtons = predictionElement.querySelectorAll('button');
      let headerPredictButton = null;
      for (const btn of allButtons) {
        const btnText = btn.textContent?.toLowerCase() || '';
        // Ищем кнопку "Predict" которая НЕ является кнопкой ставки за баллы
        // Проверяем что это просто "Predict" или "Predict with..." но без цифр и без "points"
        const hasPredictKeyword = this.hasKeyword(btnText, 'predict');
        const hasPointsKeyword = this.hasKeyword(btnText, 'points');
        const hasNumbers = /\d+/.test(btnText);
        const hasPointsWithNumbers = /\d+\s*(points|pts|баллов|очков|puntos|punkte)/i.test(btnText);
        
        if (hasPredictKeyword && 
            !hasPointsKeyword && 
            !hasPointsWithNumbers &&
            !hasNumbers) { // Не содержит цифр
          const btnRect = btn.getBoundingClientRect();
          const btnTop = btnRect.top;
          // Если кнопка "Predict" находится в верхней четверти предикта - это заголовок
          if (btnTop < predictionTop + predictionHeight * 0.25) {
            headerPredictButton = btn;
            break;
          }
        }
      }
      
      // Если нашли кнопку "Predict" в заголовке, проверяем расстояние до нашей кнопки
      if (headerPredictButton) {
        const headerRect = headerPredictButton.getBoundingClientRect();
        const headerBottom = headerRect.bottom;
        
        // Пропускаем только кнопки слишком близко к заголовку (50px)
        // Это предотвращает появление элементов в верхней части чата
        if (buttonTop < headerBottom + 50) {
          return null;
        }
      }
      // Если не нашли кнопку "Predict" в заголовке, НЕ фильтруем - создаем элементы для всех найденных кнопок ставок
      // Это позволяет элементам появляться в custom amount и под обычными кнопками
    }
    
    // СНАЧАЛА находим или создаем wrapper ДО создания polDiv
    // Это гарантирует, что элемент будет создан сразу в правильном месте
    const polDiv = document.createElement('div');
    polDiv.className = 'twitch-bets-pol-option';
    polDiv.setAttribute('data-option-index', index); // Добавляем уникальный атрибут
    polDiv.setAttribute('data-container-id', container.id || `container-${Date.now()}-${index}`); // Уникальный ID контейнера
    
    // Проверяем кнопку "custom amount" на всех языках
    // ВАЖНО: "выбрать свое количество" на русском - это ЗАГОЛОВОК секции, а НЕ кнопка custom amount!
    // Кнопка custom amount на русском - это "другое" или "своя ставка"
    const isCustomAmountButton = buttonText.includes('custom') || 
                                buttonText.includes('predict with custom') ||
                                buttonText.includes('prédire avec une quantité personnalisée') ||
                                buttonText.includes('predecir con cantidad personalizada') ||
                                buttonText.includes('mit benutzerdefiniertem betrag vorhersagen') ||
                                buttonText.includes('pronostica con un valore personalizzato') ||
                                buttonText.includes('예측에 거는 포인트 변경') ||
                                buttonText.includes('своя ставка') || // Только "своя ставка"
                                (buttonText.includes('другое') && !buttonText.includes('выбрать')) || // "другое" но НЕ "выбрать свое количество"
                                (buttonText.includes('amount') && !buttonText.includes('choose') && !buttonText.includes('select')) ||
                                (buttonText.includes('cantidad') && !buttonText.includes('elegir') && !buttonText.includes('seleccionar')) ||
                                (buttonText.includes('quantité') && !buttonText.includes('choisir') && !buttonText.includes('sélectionner')) ||
                                (buttonText.includes('betrag') && !buttonText.includes('wählen') && !buttonText.includes('auswählen')) ||
                                (buttonText.includes('valore') && !buttonText.includes('scegli') && !buttonText.includes('seleziona'));
    
    // Проверяем, является ли интерфейс русским
    // Ищем predictionElement для проверки русского языка
    let predictionElementForCheck = twitchButton.closest('[class*="prediction"], [class*="Prediction"], [role="dialog"]');
    if (!predictionElementForCheck) {
      let parent = twitchButton.parentElement;
      for (let i = 0; i < 10 && parent; i++) {
        if (parent.classList && (
          Array.from(parent.classList).some(c => c.toLowerCase().includes('prediction')) ||
          parent.getAttribute('role') === 'dialog'
        )) {
          predictionElementForCheck = parent;
          break;
        }
        parent = parent.parentElement;
      }
    }
    
    const predictionText = predictionElementForCheck ? (predictionElementForCheck.textContent || '').toLowerCase() : '';
    const isRussianInterface = buttonText.includes('своя ставка') ||
                              buttonText.includes('выбрать свое количество') ||
                              buttonText.includes('другое') ||
                              buttonText.includes('баллов') ||
                              buttonText.includes('очков') ||
                              predictionText.includes('прогноз') ||
                              predictionText.includes('выйграешь') ||
                              predictionText.includes('проиграешь') ||
                              predictionText.includes('свое количество') ||
                              predictionText.includes('голосовать');
    
    // Цвета под интерфейс Twitch: левый вариант - синий, правый - розовый (точные цвета Twitch)
    const isLeftOption = index === 0;
    const primaryColor = isLeftOption ? '#387AFF' : '#F50096';
    const primaryColorRgb = isLeftOption ? '56, 122, 255' : '245, 0, 150';
    const gradientStart = isLeftOption ? '#387AFF' : '#F50096';
    const gradientEnd = isLeftOption ? '#2563EB' : '#C4007A';
    
    const polContainerStyle = isCustomAmountButton 
        ? `
            background: rgba(16, 16, 24, 0.95);
            border: 2px solid rgba(${primaryColorRgb}, 0.6);
            border-radius: 10px;
            padding: 6px;
            font-size: 14px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            width: 100%;
            box-sizing: border-box;
        `
        : `
            background: rgba(16, 16, 24, 0.95);
            border: 2px solid rgba(${primaryColorRgb}, 0.6);
            border-radius: 10px;
            padding: 6px;
            font-size: 14px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            width: 100%;
            box-sizing: border-box;
        `;
    
    // Показываем placeholder сразу, проценты обновятся через updateAllPolPercentages()
    let percentageDisplay = '—';
    
    if (!walletData.connected) {
      polDiv.innerHTML = `
            <button class="twitch-bets-pol-connect" style="
                width: 100%;
                padding: 4px 6px;
                background: rgba(145, 70, 255, 0.1);
                border: 1px solid rgba(145, 70, 255, 0.3);
                border-radius: 4px;
                color: #9146FF;
                font-size: 9px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 3px;
                transition: all 0.2s;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                height: 24px;
                min-height: 24px;
                ${isCustomAmountButton && !isRussianInterface ? 'margin-left: -115px !important;' : ''}
            ">
                <span style="font-size: 10px;">🦊</span>
                <span>Participate</span>
            </button>
        `;
      
      polDiv.querySelector('.twitch-bets-pol-connect').addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        await this.connectMetaMask();
      });
    } else {
      polDiv.innerHTML = `
            <div class="twitch-bets-pol-container" style="${polContainerStyle}">
                <div style="display: flex; align-items: center; gap: 4px; width: 100%;">
                    <button class="twitch-bets-quick-amount" data-amount="${this.config.MIN_BET_AMOUNT}" style="
                        padding: 8px 10px;
                        background: rgba(${primaryColorRgb}, 0.15);
                        border: 2px solid rgba(${primaryColorRgb}, 0.6);
                        border-radius: 6px;
                        color: ${primaryColor};
                        font-size: 14px;
                        font-weight: 700;
                        cursor: pointer;
                        transition: all 0.2s;
                        white-space: nowrap;
                        height: 42px;
                        flex: 1;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    ">${this.config.MIN_BET_AMOUNT} POL</button>
                    
                    <input type="text" 
                           class="twitch-bets-pol-amount" 
                           placeholder="POL"
                           style="
                               flex: 1;
                               padding: 8px 6px;
                               background: rgba(0, 0, 0, 0.5);
                               border: 2px solid rgba(${primaryColorRgb}, 0.6);
                               border-radius: 6px;
                               color: white;
                               font-size: 16px;
                               font-family: monospace;
                               height: 42px;
                               text-align: center;
                               box-sizing: border-box;
                           ">
                </div>
                
                <button class="twitch-bets-place-pol-bet" data-option="${index}" style="
                    width: auto;
                    min-width: 80%;
                    padding: 8px 16px;
                    background: linear-gradient(135deg, ${gradientStart}, ${gradientEnd});
                    border: none;
                    border-radius: 6px;
                    color: white;
                    font-size: 14px;
                    font-weight: 700;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 6px;
                    transition: all 0.2s;
                    height: 38px;
                    box-shadow: 0 2px 8px rgba(${primaryColorRgb}, 0.4);
                    box-sizing: border-box;
                    margin: 0 auto;
                ">
                    <span style="font-size: 14px;">🎯</span>
                    <span>Predict</span>
                </button>
                
                <div style="
                    text-align: center;
                    font-size: 13px;
                    color: ${primaryColor};
                    font-weight: 700;
                ">
                    <span class="twitch-bets-percentage-display" data-option-index="${index}">${percentageDisplay}</span>
                </div>
            </div>
        `;
      
      const quickAmountBtn = polDiv.querySelector('.twitch-bets-quick-amount');
      quickAmountBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        const amount = quickAmountBtn.getAttribute('data-amount');
        polDiv.querySelector('.twitch-bets-pol-amount').value = amount;
      });
      
      const placeBetBtn = polDiv.querySelector('.twitch-bets-place-pol-bet');
      placeBetBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        await this.handlePlacePolBet(polDiv, index, walletData);
      });
      
      const amountInput = polDiv.querySelector('.twitch-bets-pol-amount');
      amountInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          placeBetBtn.click();
        }
      });
      
      // Сохраняем ссылку на элемент для динамического обновления
      polDiv.setAttribute('data-channel', this.currentChannel || '');
      polDiv.setAttribute('data-option-index', index);
    }
    
    // СНАЧАЛА находим или создаем wrapper ДО добавления polDiv в DOM
    const buttonParentNode = twitchButton.parentNode;
    if (!buttonParentNode) {
      return null;
    }
    
    let wrapper = null;
    
    // Если родитель сам является wrapper, проверяем, что он содержит нашу кнопку
    if (buttonParentNode.classList && buttonParentNode.classList.contains('twitch-bets-wrapper')) {
      // Проверяем, что этот wrapper содержит именно нашу кнопку Twitch
      if (buttonParentNode.contains(twitchButton) && buttonParentNode.querySelector('button') === twitchButton) {
        wrapper = buttonParentNode;
      }
    }
    
    // Если wrapper не найден, ищем wrapper, который содержит именно нашу кнопку
    if (!wrapper) {
      // Ищем все wrappers в родительском контейнере
      const allWrappers = buttonParentNode.querySelectorAll('.twitch-bets-wrapper');
      for (const w of allWrappers) {
        // Проверяем, что wrapper содержит именно нашу кнопку Twitch
        const buttonInWrapper = w.querySelector('button');
        if (buttonInWrapper === twitchButton) {
          wrapper = w;
          break;
        }
      }
    }
    
    // Если wrapper не найден, создаем новый
    if (!wrapper) {
      wrapper = document.createElement('div');
      wrapper.className = 'twitch-bets-wrapper';
      wrapper.setAttribute('data-option-index', index); // Добавляем атрибут для идентификации
      wrapper.style.cssText = `
          display: flex;
          flex-direction: column;
          align-items: ${isCustomAmountButton && !isRussianInterface ? 'flex-start' : 'center'};
          width: ${isCustomAmountButton ? '100%' : 'fit-content'};
          margin: 4px 0;
          position: relative;
          ${isCustomAmountButton && !isRussianInterface ? 'padding-left: 0;' : ''}
      `;
      
      if (isCustomAmountButton) {
        // Для русского языка НЕ применяем сдвиг влево
        if (!isRussianInterface) {
          wrapper.style.transform = 'translateX(-115px)';
          wrapper.style.marginLeft = '0';
          wrapper.style.paddingLeft = '0';
        } else {
          // Для русского языка центрируем элементы
          wrapper.style.transform = 'translateX(0)';
          wrapper.style.marginLeft = 'auto';
          wrapper.style.marginRight = 'auto';
          wrapper.style.paddingLeft = '0';
        }
      }
      
      // Заменяем кнопку на wrapper, перемещая кнопку внутрь
      buttonParentNode.replaceChild(wrapper, twitchButton);
      wrapper.appendChild(twitchButton);
    }
    
    // Удаляем ТОЛЬКО дубликаты с ТОЧНО таким же option-index, которые НЕ защищены
    const duplicates = wrapper.querySelectorAll(`.twitch-bets-pol-option[data-option-index="${index}"]`);
    duplicates.forEach(el => {
      if (el !== polDiv && !trackedElements.has(el) && el.parentNode) {
        try {
          el.remove();
        } catch (e) {
          // Игнорируем ошибки
        }
      }
    });
    
    // Добавляем polDiv в wrapper СРАЗУ после кнопки Twitch
    // Это гарантирует правильное размещение без переноса
    if (!wrapper.contains(polDiv)) {
      try {
        const twitchButtonInWrapper = wrapper.querySelector('button');
        if (twitchButtonInWrapper) {
          // Добавляем сразу после кнопки Twitch
          if (twitchButtonInWrapper.nextSibling) {
            wrapper.insertBefore(polDiv, twitchButtonInWrapper.nextSibling);
          } else {
            wrapper.appendChild(polDiv);
          }
        } else {
          wrapper.appendChild(polDiv);
        }
      } catch (e) {
        return null;
      }
    }
    
    return polDiv;
  }

  async handlePlacePolBet(polDiv, optionIndex, walletData) {
    const input = polDiv.querySelector('.twitch-bets-pol-amount');
    const placeBetBtn = polDiv.querySelector('.twitch-bets-place-pol-bet');
    
    const amount = parseFloat(input.value);
    if (!amount || isNaN(amount) || amount < this.config.MIN_BET_AMOUNT) {
      this.showNotification(`Minimum position is ${this.config.MIN_BET_AMOUNT} POL`, 'error');
      return;
    }
    
    // Проверяем подключение кошелька
    if (!this.isConnected || !this.walletAddress) {
      this.showNotification('Please connect MetaMask first', 'error');
      // Пробуем автоматически подключиться
      const connectResult = await this.connectMetaMask();
      if (!connectResult || !connectResult.success) {
        return;
      }
    }
    
    // Используем РЕАЛЬНЫЙ баланс
    const currentBalance = walletData.balance;
    
    if (amount > currentBalance) {
      this.showNotification('Insufficient balance', 'error');
      return;
    }
    
    const originalText = placeBetBtn.innerHTML;
    placeBetBtn.innerHTML = '<span style="font-size: 8px;">⏳</span>';
    placeBetBtn.disabled = true;
    
    try {
      // Получаем информацию о предикте
      const prediction = this.activePredictions.get(this.currentPredictionId);
      if (!prediction) {
        throw new Error('Prediction not found');
      }
      
      // Ставим через реальный контракт
      const result = await this.placeBetOnContractReal(
        prediction.channel,
        prediction.question,
        prediction.options,
        optionIndex,
        amount,
        prediction.startTime || 0
      );
      
      if (result.success) {
        this.showNotification(`✅ Position added: ${amount.toFixed(2)} POL on option ${optionIndex + 1}`, 'success');
        input.value = '';
        
        // Обновляем баланс
        await this.updateWalletBalance();
        await this.updateUsdtConversion();
        
        // Сохраняем contractId для этого предикта
        if (result.contractId) {
          prediction.contractId = result.contractId;
          this.activePredictions.set(this.currentPredictionId, prediction);
          
          // Добавляем в список активных контрактов для автоматической отправки отчетов
          this.activeContractPredictions.set(result.contractId, {
            channel: prediction.channel,
            question: prediction.question,
            options: prediction.options,
            optionIndex: optionIndex,
            amount: amount,
            startTime: Date.now(),
            status: 'active'
          });
        }
        
        // Сохраняем ставку локально
        const bet = {
          id: 'bet_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
          contractId: result.contractId,
          predictionId: this.currentPredictionId,
          optionIndex: optionIndex,
          amount: amount,
          txHash: result.txHash,
          walletAddress: walletData.address,
          timestamp: Date.now(),
          status: 'pending',
          channel: prediction.channel,
          channelUrl: `https://www.twitch.tv/${prediction.channel}`
        };
        
        this.userBets.push(bet);
        await this.saveUserBets();
        
        // Обновляем UI
        this.safeUpdateUI();
      } else {
        this.showNotification('Participation failed: ' + result.error, 'error');
      }
      
    } catch (error) {
      this.showNotification('Participation failed: ' + error.message, 'error');
    } finally {
      placeBetBtn.innerHTML = originalText;
      placeBetBtn.disabled = false;
    }
  }

  // НОВАЯ ФУНКЦИЯ: Размещение ставки через реальный контракт
  async placeBetOnContractReal(channel, question, options, optionIndex, amount, referenceStartTime = 0) {
    try {
      if (!this.isConnected || !this.walletAddress) {
        return { success: false, error: 'Wallet not connected' };
      }
      
      // Проверяем доступность MetaMask через callWeb3
      try {
        const hasMetaMask = await this.callWeb3('checkMetaMaskInstalled');
        if (!hasMetaMask) {
          return { success: false, error: 'MetaMask not available. Please make sure MetaMask is installed and unlocked.' };
        }
      } catch (error) {
        return { success: false, error: 'MetaMask not available. Please make sure MetaMask is installed and unlocked.' };
      }
      
      // Проверяем сеть
      if (this.chainId !== this.config.POLYGON_CHAIN_ID) {
        const switchResult = await this.switchToPolygon();
        if (!switchResult.success) {
          return { success: false, error: 'Please switch to Polygon' };
        }
      }
      
      // Конвертируем POL в wei (1 POL = 10^18 wei)
      const amountWei = ethers.parseEther(amount.toString());
      
      
      try {
        // Новый метод (минимальная транзакция): placeBet(channel, optionIndex, {value})
        const result = await this.sendBetTransaction(channel, optionIndex, amountWei);
        
        if (result && result.txHash) {
          // Используем predictionId из события, если доступен
          // Если нет, пытаемся получить из транзакции или генерируем локально
          let contractId = result.predictionId;
          
          if (!contractId) {
            // Пытаемся получить из события BetPlaced в receipt
            if (result.receipt && result.receipt.logs) {
              const iface = new ethers.Interface(this.config.CONTRACT_ABI);
              const betPlacedFragment = iface.getEvent('BetPlaced');
              const betPlacedTopic = iface.getEventTopic('BetPlaced');
              
              for (const log of result.receipt.logs) {
                try {
                  // Проверяем, что это событие BetPlaced по topic[0]
                  if (log.topics && log.topics[0] === betPlacedTopic) {
                    const decoded = iface.decodeEventLog(betPlacedFragment, log.data, log.topics);
                    if (decoded && decoded.id) {
                      contractId = decoded.id;
                      break;
                    }
                  }
                } catch (e) {
                  // Игнорируем ошибки парсинга
                }
              }
            }
          }
          
          // contractId должен приходить из события BetPlaced.
          // Если по какой-то причине не смогли распарсить — оставим null, UI покажет "ID: pending".
          
          return { 
            success: true, 
            txHash: result.txHash,
            contractId: contractId,
            receipt: result.receipt
          };
        } else {
          return { success: false, error: 'Transaction failed' };
        }
        
      } catch (txError) {
        
        // Обработка различных типов ошибок
        let errorMessage = txError.message || 'Transaction failed';
        
        // Обработка ошибок от MetaMask
        if (txError.code === 'ACTION_REJECTED' || txError.code === 4001) {
          errorMessage = 'Transaction rejected by user';
        } else if (txError.code === 'UNPREDICTABLE_GAS_LIMIT' || (txError.message && txError.message.includes('gas'))) {
          errorMessage = 'Gas estimation failed. The transaction may fail. Please check your balance and try again.';
        } else if (txError.reason) {
          // Ошибка от контракта (revert reason)
          errorMessage = txError.reason;
        } else if (txError.data && txError.data.message) {
          errorMessage = txError.data.message;
        } else if (txError.error && txError.error.message) {
          errorMessage = txError.error.message;
        } else if (typeof txError === 'string') {
          errorMessage = txError;
        }
        
        // Улучшаем сообщения об ошибках
        if (errorMessage.includes('insufficient funds') || errorMessage.includes('insufficient balance')) {
          errorMessage = 'Insufficient POL balance. Please add more POL to your wallet.';
        } else if (errorMessage.includes('user rejected')) {
          errorMessage = 'Transaction rejected by user';
        } else if (errorMessage.includes('Bet too small')) {
          errorMessage = `Minimum position is ${this.config.MIN_BET_AMOUNT} POL`;
        } else if (errorMessage.includes('Invalid option')) {
          errorMessage = 'Invalid option selected';
        } else if (errorMessage.includes('Not accepting bets')) {
          errorMessage = 'This market is no longer accepting positions';
        }
        
        return { success: false, error: errorMessage };
      }
      
    } catch (error) {
      return { 
        success: false, 
        error: error.message || 'Contract interaction failed' 
      };
    }
  }

  // ИСПРАВЛЕННАЯ ФУНКЦИЯ: Генерация contractId (predictionId) используя ethers.js
  // ВАЖНО: Эта функция используется только для локального отслеживания
  // Реальный predictionId генерируется в контракте при первой ставке
  generateContractId(channel, question, options, startTime) {
    try {
      // Пытаемся воспроизвести точную логику контракта для детерминированного predictionId.
      // Контракт использует: keccak256(abi.encode(_channel, _question, _options, roundedTime))
      if (typeof ethers !== 'undefined') {
        const ts = startTime || Math.floor(Date.now() / 1000);
        const roundedTime = Math.floor(ts / 300) * 300; // как в контракте

        const coder = ethers.AbiCoder.defaultAbiCoder();
        const encoded = coder.encode(
          ['string', 'string', 'string[]', 'uint256'],
          [channel || '', question || '', options || [], BigInt(roundedTime)]
        );
        return ethers.keccak256(encoded); // bytes32 (0x + 64 hex)
      } else {
        // Fallback если ethers.js не загружен
        const seed = channel + question + (startTime || Date.now()).toString();
        let hash = 0;
        for (let i = 0; i < seed.length; i++) {
          const char = seed.charCodeAt(i);
          hash = ((hash << 5) - hash) + char;
          hash = hash & hash;
        }
        return '0x' + Math.abs(hash).toString(16).padStart(64, '0');
      }
    } catch (error) {
      // Fallback
      const seed = channel + question + Date.now().toString();
      return '0x' + seed.split('').reduce((acc, char) => {
        const hash = ((acc << 5) - acc) + char.charCodeAt(0);
        return hash & hash;
      }, 0).toString(16).padStart(64, '0');
    }
  }
  
  // lockPrediction() удален в новом контракте (ставки закрываются при первом FINISHED_*).
  async lockPrediction() {
    return { success: false, error: 'lockPrediction removed in new contract' };
  }
  
  // Финализация предикта по консенсусу (новый контракт: finalize(channel))
  async finalizePrediction(channel) {
    try {
      if (!this.isConnected || !this.walletAddress) {
        return { success: false, error: 'Wallet not connected' };
      }
      
      // Проверяем сеть
      if (this.chainId !== this.config.POLYGON_CHAIN_ID) {
        const switchResult = await this.switchToPolygon();
        if (!switchResult.success) {
          return { success: false, error: 'Please switch to Polygon' };
        }
      }
      
      
      // Получаем контракт
      const contract = await this.getContract();
      
      // Вызываем finalize(channel)
      const tx = await contract.finalize(channel);
      const receipt = await tx.wait();
      
      return {
        success: true,
        txHash: tx.hash,
        receipt: receipt
      };
      
    } catch (error) {
      
      let errorMessage = error.message || 'Finalization failed';
      if (error.code === 'ACTION_REJECTED' || error.code === 4001) {
        errorMessage = 'Transaction rejected by user';
      } else if (error.reason) {
        errorMessage = error.reason;
      }
      
      return { success: false, error: errorMessage };
    }
  }
  
  async timeoutPrediction(channel) {
    try {
      if (!this.isConnected || !this.walletAddress) return { success: false, error: 'Wallet not connected' };
      if (this.chainId !== this.config.POLYGON_CHAIN_ID) {
        const sw = await this.switchToPolygon();
        if (!sw.success) return { success: false, error: 'Switch to Polygon' };
      }
      const contract = await this.getContract();
      const tx = await contract.timeout(channel);
      await tx.wait();
      return { success: true, txHash: tx.hash };
    } catch (e) {
      return { success: false, error: e.reason || e.message };
    }
  }
  
  // DEPRECATED: Новый контракт обрабатывает возвраты автоматически в claim()
  async processRefundBatch(contractId) {
    return { success: true };
  }

  // Claim (refund/winnings) for the current user
  async claimPayout(contractId) {
    try {
      if (!this.isConnected || !this.walletAddress) return { success: false, error: 'Wallet not connected' };
      if (this.chainId !== this.config.POLYGON_CHAIN_ID) {
        const sw = await this.switchToPolygon();
        if (!sw.success) return { success: false, error: 'Switch to Polygon' };
      }
      const contract = await this.getContract();
      
      let tx;
      if (!contractId) {
        // Новый контракт: claimAll() для забора всех выигрышей
        tx = await contract.claimAll();
      } else {
        // Новый контракт: claim(bytes32) для конкретного предикта
        const pid = this.toBytes32(contractId);
        tx = await contract.claim(pid);
      }
      await tx.wait();
      return { success: true, txHash: tx.hash };
    } catch (e) {
      return { success: false, error: e?.reason || e?.message || String(e) };
    }
  }

  // Вывод комиссии для владельца контракта
  async withdrawFees() {
    try {
      if (!this.isConnected || !this.walletAddress) return { success: false, error: 'Wallet not connected' };
      if (this.chainId !== this.config.POLYGON_CHAIN_ID) {
        const sw = await this.switchToPolygon();
        if (!sw.success) return { success: false, error: 'Switch to Polygon' };
      }
      const contract = await this.getContract();
      const tx = await contract.withdrawFees();
      await tx.wait();
      return { success: true, txHash: tx.hash };
    } catch (e) {
      return { success: false, error: e?.reason || e?.message || String(e) };
    }
  }

  // Update local bet history based on on-chain outcome (CANCELLED/RESOLVED)
  async syncLocalBetStatusFromContract(contractId) {
    try {
      const pid = this.toBytes32(contractId);
      
      // Проверяем кэш
      const cacheKey = pid;
      let info;
      const cached = this.predictionInfoCache.get(cacheKey);
      if (cached && (Date.now() - cached.timestamp) < this.predictionInfoCacheTTL) {
        info = cached.info;
      } else {
        const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
        const provider = new ethers.JsonRpcProvider(rpcUrl);
        const c = new ethers.Contract(this.config.PREDICTION_CONTRACT_ADDRESS, this.config.CONTRACT_ABI, provider);
        
        info = await this.queueRpcRequest(async () => {
          return await c.getPredictionInfo(pid);
        });
        
        // Сохраняем в кэш в POL (делим на 1e18), чтобы все читатели кэша видели один формат
        const pool0Pol = Number(info.pool0 ?? info[2] ?? 0) / 1e18;
        const pool1Pol = Number(info.pool1 ?? info[3] ?? 0) / 1e18;
        this.predictionInfoCache.set(cacheKey, {
          info: { ...info, pool0: pool0Pol, pool1: pool1Pol },
          timestamp: Date.now()
        });
        info = { ...info, pool0: pool0Pol, pool1: pool1Pol };
      }
      
      const statusNum = Number(info.status);
      const winningOption = Number(info.winningOption);
      
      const now = Date.now();
      
      if (statusNum === 2) {
        // RESOLVED (новый контракт: 2 = RESOLVED)
        this.userBets = this.userBets.map((bet) => {
          if (bet.contractId !== contractId) return bet;
          const isWin = bet.optionIndex === winningOption;
          return {
            ...bet,
            status: isWin ? 'won' : 'lost',
            resolveTime: now
          };
        });
      } else if (statusNum === 3) {
        // CANCELLED (новый контракт: 3 = CANCELLED)
        this.userBets = this.userBets.map((bet) => {
          if (bet.contractId !== contractId) return bet;
          return {
            ...bet,
            status: 'refunded',
            refundTime: now
          };
        });
      } else {
        // not final
        return;
      }
      
      await this.saveUserBets();
      // Используем debounced версию для предотвращения множественных обновлений
      this.safeUpdateUI();
    } catch (e) {
    }
  }
  
  // DEPRECATED: Новый контракт обрабатывает распределение автоматически
  async continueDistribution(contractId) {
    return { success: true };
  }
  
  toBytes32(contractId) {
    if (typeof contractId !== 'string') return contractId;
    if (contractId.startsWith('0x') && contractId.length === 66) return contractId;
    return ethers.id(contractId).slice(0, 66);
  }
  
  async checkTimeout(contractId) {
    try {
      if (!this.provider) this.provider = new ethers.BrowserProvider(window.ethereum);
      const c = new ethers.Contract(this.config.PREDICTION_CONTRACT_ADDRESS, this.config.CONTRACT_ABI, this.provider);
      // Новый контракт: isExpired(predictionId)
      return await c.isExpired(this.toBytes32(contractId));
    } catch (_) { return false; }
  }
  
  // DEPRECATED: Новый контракт не имеет отдельного статуса распределения
  async getDistributionStatus(contractId) {
    return null;
  }
  
  // ИСПРАВЛЕННАЯ ФУНКЦИЯ: Отправка транзакции ставки через ethers.js
  // Новый метод: placeBet(channel, optionIndex, {value})
  async sendBetTransaction(channel, optionIndex, amountWei) {
    try {
      // Получаем контракт
      const contract = await this.getContract();
      
      // Проверяем, что все параметры корректны
      if (!channel) {
        throw new Error('Invalid prediction parameters');
      }
      
      if (optionIndex < 0 || optionIndex >= 2) {
        throw new Error('Invalid option index');
      }
      
      if (!amountWei || amountWei <= 0n) {
        throw new Error('Invalid bet amount');
      }
      
      // Вызываем функцию placeBet через ethers.js
      const tx = await contract.placeBet(channel, optionIndex, { value: amountWei });
      
      
      // Ждем подтверждения транзакции
      const receipt = await tx.wait();
      
      // Получаем predictionId из события BetPlaced
      let predictionId = null;
      
      // В ethers.js v6 используем правильный способ парсинга событий
      try {
        const iface = contract.interface;
        
        // Способ 1: Используем фильтр событий контракта (самый надежный способ)
        try {
          const filter = contract.filters.BetPlaced();
          const events = await contract.queryFilter(filter, receipt.blockNumber, receipt.blockNumber);
          if (events && events.length > 0) {
            // Находим событие с нашим txHash
            const event = events.find(e => e.transactionHash === receipt.hash);
            if (event && event.args) {
              // В ethers.js v6 args это объект с именованными полями
              if (event.args.id) {
                predictionId = event.args.id;
              }
            }
          }
        } catch (e) {
        }
        
        // Способ 2: Прямой парсинг логов через parseEventLog
        if (!predictionId && receipt.logs && receipt.logs.length > 0) {
          const betPlacedFragment = iface.getEvent('BetPlaced');
          const betPlacedTopic = iface.getEventTopic('BetPlaced');
          
          for (const log of receipt.logs) {
            try {
              // Проверяем, что это событие BetPlaced по topic[0]
              if (log.topics && log.topics[0] === betPlacedTopic) {
                // Парсим событие
                const decoded = iface.decodeEventLog(betPlacedFragment, log.data, log.topics);
                if (decoded && decoded.id) {
                  predictionId = decoded.id;
                  break;
                }
              }
            } catch (e) {
              // Игнорируем ошибки парсинга других событий
            }
          }
        }
        
        // Способ 3: Альтернативный способ через parseLog (для совместимости)
        if (!predictionId && receipt.logs && receipt.logs.length > 0) {
          for (const log of receipt.logs) {
            try {
              const parsed = iface.parseLog({
                topics: log.topics || [],
                data: log.data || '0x'
              });
              if (parsed && parsed.name === 'BetPlaced') {
                if (parsed.args && parsed.args.id) {
                  predictionId = parsed.args.id;
                  break;
                } else if (parsed.args && Array.isArray(parsed.args) && parsed.args.length > 0) {
                  predictionId = parsed.args[0];
                  break;
                }
              }
            } catch (e) {
              // Игнорируем ошибки парсинга других событий
            }
          }
        }
      } catch (error) {
      }
      
      return {
        txHash: tx.hash,
        receipt: receipt,
        predictionId: predictionId
      };
      
    } catch (error) {
      throw error;
    }
  }

  async saveUserBets() {
    try {
      await chrome.runtime.sendMessage({
        action: 'saveUserBets',
        bets: this.userBets
      });
    } catch (error) {
    }
  }

  async loadUserBets() {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'getUserBets' });
      if (response && response.success && response.userBets) {
        this.userBets = response.userBets;
      }
      this.restoreActiveContractPredictionsFromBets();
    } catch (error) {
    }
  }

  // Восстанавливаем activeContractPredictions из local storage (чтобы Active Bets не "пропадали" после перезагрузки)
  restoreActiveContractPredictionsFromBets() {
    try {
      this.activeContractPredictions = new Map();
      for (const bet of this.userBets || []) {
        if (!bet?.contractId) continue;
        if (bet.status !== 'pending' && bet.status !== 'active') continue;
        
        const existing = this.activeContractPredictions.get(bet.contractId);
        if (!existing) {
          this.activeContractPredictions.set(bet.contractId, {
            channel: bet.channel,
            question: bet.question || '',
            options: bet.options || ['Option 1', 'Option 2'],
            amount: bet.amount || 0,
            optionIndex: bet.optionIndex,
            startTime: bet.timestamp || Date.now(),
            status: 'active'
          });
        } else {
          // агрегируем сумму
          existing.amount = (existing.amount || 0) + (bet.amount || 0);
          this.activeContractPredictions.set(bet.contractId, existing);
        }
      }
    } catch (e) {
    }
  }

  checkPredictionResults() {
    // Удаляем старые завершенные предикты
    const currentTime = Date.now();
    const completedPredictions = [];
    
    this.activePredictions.forEach((prediction, predictionId) => {
      // Если предикт завершен более 30 секунд назад, удаляем его
      if (prediction.status === 'completed' && prediction.endTime && (currentTime - prediction.endTime) > 30000) {
        completedPredictions.push(predictionId);
      }
    });
    
    completedPredictions.forEach(id => {
      this.activePredictions.delete(id);
    });
  }

  getWinningOptionFromEndedPrediction(predictionElement) {
    try {
      if (!predictionElement || !predictionElement.textContent) {
        return null;
      }
      
      // Часто сюда прилетает не весь диалог, а один из внутренних блоков (левая/правая колонка),
      // что ломает определение "левый/правый". Поэтому сначала поднимаемся до диалога, если он есть.
      const container = predictionElement.closest?.('[role="dialog"]') || predictionElement;
      if (!container || !container.textContent) return null;
      
      // Получаем весь текст элемента и HTML для более точного анализа
      const elementText = container.textContent || '';
      const elementHTML = container.innerHTML || '';
      
      // МЕТОД 1: Ищем элемент с текстом "Winner" и определяем его позицию относительно вариантов
      // Это самый надежный способ для Twitch
      const predictionRect = container.getBoundingClientRect();
      const allElements = container.querySelectorAll('*');
      let winnerElement = null;
      let winnerScore = -Infinity;
      
      // Сначала ищем именно текст "Winner" (а не любые чекмарки), чтобы не цеплять чужие иконки - многоязычно
      for (const elem of allElements) {
        const rawText = (elem.textContent || '').trim();
        if (!rawText) continue;
        const elemText = rawText.toLowerCase();
        if (!this.hasKeyword(elemText, 'winner')) continue;
        
        try {
          const style = window.getComputedStyle(elem);
          if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') continue;
          const r = elem.getBoundingClientRect();
          if (r.width <= 0 || r.height <= 0) continue;
          const inside =
            r.right >= predictionRect.left &&
            r.left <= predictionRect.right &&
            r.bottom >= predictionRect.top &&
            r.top <= predictionRect.bottom;
          if (!inside) continue;
          
          let score = 0;
          // Проверяем точное совпадение с любым из переводов "winner"
          const winnerExact = ['winner', 'ganador', 'ganadora', 'ganador/a', 'gagnant', 'gewinner', 'победитель', '승자', '勝者', 'vincitore', 'vincitrice', 'исход'];
          if (winnerExact.some(w => elemText === w.toLowerCase())) score += 10;
          if (elemText.length <= 12) score += 3;
          if (r.width < predictionRect.width * 0.8) score += 2;
          if (r.height >= 10 && r.height <= 60) score += 2;
          const relY = (r.top - predictionRect.top) / Math.max(1, predictionRect.height);
          if (relY >= 0.1 && relY <= 0.7) score += 2;
          
          if (score > winnerScore) {
            winnerScore = score;
            winnerElement = elem;
          }
        } catch (_) {}
      }
      
      // Фолбэк: если "Winner" не нашли, пытаемся по классу/атрибуту/чекмарку
      if (!winnerElement) {
        for (const elem of allElements) {
          const elemHTML = (elem.innerHTML || '').toLowerCase();
          const elemClassName = typeof elem.className === 'string'
            ? elem.className
            : (elem.className?.baseVal || elem.className?.toString() || '');
          const hasWinnerClass = elemClassName.toLowerCase().includes('winner');
          const looksLikeWinner =
            hasWinnerClass ||
            elem.getAttribute?.('data-winner') === 'true' ||
            elemHTML.includes('checkmark') ||
            elemHTML.includes('✓') ||
            elemHTML.includes('✅');
          if (!looksLikeWinner) continue;
          
          try {
            const style = window.getComputedStyle(elem);
            if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') continue;
            const r = elem.getBoundingClientRect();
            if (r.width <= 0 || r.height <= 0) continue;
            winnerElement = elem;
            break;
          } catch (_) {}
        }
      }
      
      if (winnerElement) {
        // Бейдж "Winner" в Twitch может быть визуально "между" колонками.
        // Поэтому НЕ сравниваем его с центром окна.
        // Вместо этого: ищем два текста-лейбла опций сразу под Winner и выбираем,
        // к какой из них бейдж ближе по X (левый -> 0, правый -> 1).
        try {
          const badgeRect = winnerElement.getBoundingClientRect();
          const badgeCenterX = (badgeRect.left + badgeRect.right) / 2;
          
          const labelCandidates = [];
          for (const el of allElements) {
            const txt = (el.textContent || '').trim();
            if (!txt) continue;
            const lower = txt.toLowerCase();
            const winnerExact = ['winner', 'ganador', 'ganadora', 'ganador/a', 'gagnant', 'gewinner', 'победитель', '승자', '勝者', 'vincitore', 'vincitrice', 'исход'];
            if (winnerExact.some(w => lower === w.toLowerCase()) || this.hasKeyword(lower, 'winner')) continue;
            if (lower.includes('prediction') || lower.includes('ended') || lower.includes('ago')) continue;
            if (lower.includes('go to')) continue;
            // отсекаем проценты/время/статы
            if (/^\d+%$/.test(txt)) continue;
            if (/^\d+:\d+/.test(txt)) continue;
            if (/^\d+([.,]\d+)?[km]?$/i.test(txt)) continue;
            if (txt.length > 60) continue;
            
            const style = window.getComputedStyle(el);
            if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') continue;
            // подписи опций обычно цветные (а не белые/серые)
            const color = (style.color || '').replace(/\s+/g, '');
            if (!color) continue;
            if (color.includes('rgb(239,239,241)') || color.includes('rgb(255,255,255)')) continue;
            
            const r = el.getBoundingClientRect();
            if (r.width <= 0 || r.height <= 0) continue;
            
            // ищем текст строго под бейджем (узкая вертикальная зона)
            if (r.top < badgeRect.bottom - 6) continue;
            if (r.top > badgeRect.bottom + 120) continue;
            if (r.height > 70) continue;
            
            labelCandidates.push({ el, txt, rect: r });
          }
          
          if (labelCandidates.length >= 2) {
            // группируем по строкам (по Y), чтобы выбрать именно пару YES/NO под Winner
            const groups = [];
            for (const c of labelCandidates) {
              const cy = (c.rect.top + c.rect.bottom) / 2;
              let placed = false;
              for (const g of groups) {
                if (Math.abs(cy - g.centerY) < 16) {
                  g.items.push(c);
                  g.centerY = (g.centerY * (g.items.length - 1) + cy) / g.items.length;
                  placed = true;
                  break;
                }
              }
              if (!placed) groups.push({ centerY: cy, items: [c] });
            }
            
            const targetY = badgeRect.bottom + 25;
            let best = null;
            let bestScore = -Infinity;
            for (const g of groups) {
              if (g.items.length < 2) continue;
              g.items.sort((a, b) => a.rect.left - b.rect.left);
              const left = g.items[0];
              const right = g.items[g.items.length - 1];
              const separation = right.rect.left - left.rect.left;
              if (separation < predictionRect.width * 0.12) continue;
              const vDist = Math.abs(g.centerY - targetY);
              const score = separation - vDist * 2;
              if (score > bestScore) {
                bestScore = score;
                best = { left, right };
              }
            }
            
            if (best) {
              const leftCenterX = (best.left.rect.left + best.left.rect.right) / 2;
              const rightCenterX = (best.right.rect.left + best.right.rect.right) / 2;
              const midX = (leftCenterX + rightCenterX) / 2;
              const deadZone = Math.max(6, Math.abs(rightCenterX - leftCenterX) * 0.05);
              let idx;
              if (badgeCenterX > midX + deadZone) idx = 1;
              else if (badgeCenterX < midX - deadZone) idx = 0;
              else {
                const dLeft = Math.abs(badgeCenterX - leftCenterX);
                const dRight = Math.abs(badgeCenterX - rightCenterX);
                idx = dRight < dLeft ? 1 : 0;
              }
              
              return idx;
            }
          }
        } catch (_) {
          // ignore and continue with fallbacks below
        }
        
        // Убираем избыточное логирование
        
        // Ищем все варианты в предикте
        // Варианты обычно расположены горизонтально или вертикально
        const allOptions = container.querySelectorAll('div, section, article');
        const optionElements = [];
        
        for (const elem of allOptions) {
          const elemText = (elem.textContent || '').toLowerCase();
          const elemRect = elem.getBoundingClientRect();
          
          // Вариант должен содержать проценты, текст варианта и быть видимым
          if (elemRect.width > 50 && elemRect.height > 50 && // Достаточный размер
              elemText.length > 5 && elemText.length < 2000 &&
              (elemText.includes('%') || 
               elemText.includes('option') || 
               elemText.includes('да') || 
               elemText.includes('yes') || 
               elemText.includes('нет') ||
               elemText.includes('no') ||
               elemText.match(/\d+[km]?/i))) { // числа с возможными K/M
            
            // Проверяем, что это не весь предикт, а отдельный вариант
            const parentText = (elem.parentElement?.textContent || '').toLowerCase();
            if (elemText.length < parentText.length * 0.8) { // Вариант меньше чем родитель
              optionElements.push({
                element: elem,
                text: elemText,
                rect: elemRect,
                index: optionElements.length
              });
            }
          }
        }
        
        // Сортируем варианты по позиции (слева направо или сверху вниз)
        optionElements.sort((a, b) => {
          // Сначала по горизонтали (слева направо)
          const horizontalDiff = a.rect.left - b.rect.left;
          if (Math.abs(horizontalDiff) > 50) {
            return horizontalDiff;
          }
          // Затем по вертикали (сверху вниз)
          return a.rect.top - b.rect.top;
        });
        
        // Убираем избыточное логирование
        
        if (optionElements.length >= 2) {
          // Определяем, в каком варианте находится winnerElement
          for (let i = 0; i < optionElements.length; i++) {
            const optionElem = optionElements[i].element;
            
            // Проверяем, содержит ли вариант winnerElement
            if (optionElem.contains(winnerElement) || 
                optionElem === winnerElement ||
                winnerElement.closest('div') === optionElem) {
              // Важно: возвращаем строго 0 или 1 (левый/правый исход),
              // т.к. optionElements может содержать больше 2 кандидатов.
              const optionRect = optionElements[i].rect;
              const predictionRect = container.getBoundingClientRect();
              const optionCenterX = (optionRect.left + optionRect.right) / 2;
              const predictionCenterX = predictionRect.left + predictionRect.width / 2;
              const idx = optionCenterX > predictionCenterX ? 1 : 0;
              return idx;
            }
            
            // Проверяем, есть ли "Winner" в тексте или дочерних элементах варианта
            const optionText = optionElements[i].text;
            
            // Проверяем текст варианта (многоязычно)
            if (this.hasKeyword(optionText, 'winner')) {
              const optionRect = optionElements[i].rect;
              const predictionRect = container.getBoundingClientRect();
              const optionCenterX = (optionRect.left + optionRect.right) / 2;
              const predictionCenterX = predictionRect.left + predictionRect.width / 2;
              const idx = optionCenterX > predictionCenterX ? 1 : 0;
              return idx;
            }
            
            // Проверяем классы и атрибуты
            if (optionElem.querySelector('[class*="winner"]') ||
                optionElem.querySelector('[data-winner="true"]')) {
              const optionRect = optionElements[i].rect;
              const predictionRect = container.getBoundingClientRect();
              const optionCenterX = (optionRect.left + optionRect.right) / 2;
              const predictionCenterX = predictionRect.left + predictionRect.width / 2;
              const idx = optionCenterX > predictionCenterX ? 1 : 0;
              return idx;
            }
            
            // Проверяем все дочерние элементы на наличие текста "Winner"
            const allChildren = optionElem.querySelectorAll('*');
            for (const child of allChildren) {
              const childText = (child.textContent || '').toLowerCase();
              if (this.hasKeyword(childText, 'winner') && childText.length < 30) {
                const optionRect = optionElements[i].rect;
                const predictionRect = container.getBoundingClientRect();
                const optionCenterX = (optionRect.left + optionRect.right) / 2;
                const predictionCenterX = predictionRect.left + predictionRect.width / 2;
                const idx = optionCenterX > predictionCenterX ? 1 : 0;
                return idx;
              }
            }
          }
          
          // Альтернативный метод: ищем ближайший вариант к winnerElement
          const winnerRect = winnerElement.getBoundingClientRect();
          let closestOptionIndex = 0;
          let minDistance = Infinity;
          
          for (let i = 0; i < optionElements.length; i++) {
            const optionRect = optionElements[i].rect;
            // Вычисляем расстояние между центрами
            const centerX = (winnerRect.left + winnerRect.right) / 2;
            const centerY = (winnerRect.top + winnerRect.bottom) / 2;
            const optionCenterX = (optionRect.left + optionRect.right) / 2;
            const optionCenterY = (optionRect.top + optionRect.bottom) / 2;
            
            const distance = Math.sqrt(
              Math.pow(centerX - optionCenterX, 2) + 
              Math.pow(centerY - optionCenterY, 2)
            );
            
            if (distance < minDistance) {
              minDistance = distance;
              closestOptionIndex = i;
            }
          }
          
          // Маппим найденный "ближайший кандидат" на левый/правый исход.
          const closestRect = optionElements[closestOptionIndex]?.rect;
          if (closestRect) {
            const predictionRect = container.getBoundingClientRect();
            const optionCenterX = (closestRect.left + closestRect.right) / 2;
            const predictionCenterX = predictionRect.left + predictionRect.width / 2;
            const idx = optionCenterX > predictionCenterX ? 1 : 0;
            return idx;
          }
          return 0;
        }
      }
      
      // МЕТОД 2: Ищем явные указания на результат в тексте
      const text = elementText.toLowerCase();
      
      // Проверяем явные указания на Option 1 (первый вариант = индекс 0)
      if (text.includes('option 1 won') || 
          text.includes('option 1 is the winner') ||
          text.includes('winner: option 1') ||
          text.includes('option 1 wins') ||
          text.includes('option 1 победил') ||
          text.includes('option 1 выиграл') ||
          (text.includes('prediction result') && text.includes('option 1') && !text.includes('option 2')) ||
          (text.includes('prediction result is') && text.includes('option 1'))) {
        return 0;
      }
      
      // Проверяем явные указания на Option 2 (второй вариант = индекс 1)
      if (text.includes('option 2 won') || 
          text.includes('option 2 is the winner') ||
          text.includes('winner: option 2') ||
          text.includes('option 2 wins') ||
          text.includes('option 2 победил') ||
          text.includes('option 2 выиграл') ||
          (text.includes('prediction result') && text.includes('option 2') && !text.includes('option 1')) ||
          (text.includes('prediction result is') && text.includes('option 2'))) {
        return 1;
      }
      
      // Метод 2: Ищем в HTML атрибутах и классах
      const htmlLower = elementHTML.toLowerCase();
      if (htmlLower.includes('data-option="0"') || htmlLower.includes('data-option="1"') || 
          htmlLower.includes('data-winner="0"') || htmlLower.includes('data-winner="1"')) {
        const option0Match = htmlLower.match(/data-(?:option|winner)="0"/);
        const option1Match = htmlLower.match(/data-(?:option|winner)="1"/);
        if (option0Match && !option1Match) return 0;
        if (option1Match && !option0Match) return 1;
      }
      
      // МЕТОД 3: Ищем слово "Winner" и определяем позицию по порядку в тексте
      const lines = elementText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
      
      for (let i = 0; i < Math.min(lines.length, 50); i++) {
        const line = lines[i].toLowerCase();
        
        const hasWinnerKeyword = this.hasKeyword(line, 'winner');
        if (hasWinnerKeyword || line.includes('🏆')) {
          // Проверяем текущую строку
          if (line.includes('option 1') || (line.match(/\b1\b/) && !line.match(/\b2\b/))) {
            return 0;
          } else if (line.includes('option 2') || (line.match(/\b2\b/) && !line.match(/\b1\b/))) {
            return 1;
          }
          
          // Определяем позицию по порядку строк
          // Если "winner" находится во второй половине текста, это скорее всего второй вариант
          const winnerLineIndex = i;
          const totalLines = lines.length;
          
          if (totalLines > 10) {
            if (winnerLineIndex > totalLines / 2) {
              return 1;
            } else {
              return 0;
            }
          }
          
          // Проверяем следующую строку
          if (i + 1 < lines.length) {
            const nextLine = lines[i + 1].toLowerCase();
            if (nextLine.includes('option 1') || (nextLine.match(/\b1\b/) && !nextLine.match(/\b2\b/))) {
              return 0;
            } else if (nextLine.includes('option 2') || (nextLine.match(/\b2\b/) && !nextLine.match(/\b1\b/))) {
              return 1;
            }
          }
          
          // Проверяем предыдущую строку
          if (i > 0) {
            const prevLine = lines[i - 1].toLowerCase();
            if (prevLine.includes('option 1') || (prevLine.match(/\b1\b/) && !prevLine.match(/\b2\b/))) {
              return 0;
            } else if (prevLine.includes('option 2') || (prevLine.match(/\b2\b/) && !prevLine.match(/\b1\b/))) {
              return 1;
            }
          }
        }
      }
      
      // МЕТОД 4: Ищем проценты и определяем победителя
      // ВАЖНО: В Twitch победитель НЕ всегда имеет больший процент!
      // Победитель определяется модератором, а не процентом ставок
      // Поэтому этот метод не используется для определения победителя
      
      // Вместо этого ищем элемент с "Winner" и определяем его позицию (многоязычно)
      const winnerTextElements = container.querySelectorAll('*');
      for (const elem of winnerTextElements) {
        const elemText = (elem.textContent || '').toLowerCase();
        if (this.hasKeyword(elemText, 'winner') && elemText.length < 30) {
          // Нашли элемент с "Winner", определяем его позицию
          const elemRect = elem.getBoundingClientRect();
          
          // Ищем все варианты и их позиции
          const allDivs = container.querySelectorAll('div');
          const optionRects = [];
          
          for (const div of allDivs) {
            const divText = (div.textContent || '').toLowerCase();
            const divRect = div.getBoundingClientRect();
            
            if (divRect.width > 100 && divRect.height > 50 &&
                (divText.includes('%') || divText.includes('да') || divText.includes('yes') || 
                 divText.includes('нет') || divText.includes('no'))) {
              optionRects.push({
                rect: divRect,
                text: divText
              });
            }
          }
          
          // Сортируем по позиции
          optionRects.sort((a, b) => {
            const horizontalDiff = a.rect.left - b.rect.left;
            if (Math.abs(horizontalDiff) > 50) return horizontalDiff;
            return a.rect.top - b.rect.top;
          });
          
          if (optionRects.length >= 2) {
            // Определяем, к какому варианту ближе элемент "Winner"
            let closestIndex = 0;
            let minDist = Infinity;
            
            for (let i = 0; i < optionRects.length; i++) {
              const dist = Math.sqrt(
                Math.pow(elemRect.left - optionRects[i].rect.left, 2) +
                Math.pow(elemRect.top - optionRects[i].rect.top, 2)
              );
              if (dist < minDist) {
                minDist = dist;
                closestIndex = i;
              }
            }
            
            return closestIndex;
          }
        }
      }
      
      // Метод 5: Ищем визуальные индикаторы победителя (зеленые кнопки, выделенные элементы)
      const buttons = container.querySelectorAll('button, [role="button"], div[class*="option"]');
      
      for (let i = 0; i < buttons.length; i++) {
        const button = buttons[i];
        const buttonText = button.textContent?.toLowerCase() || '';
        
        // Пропускаем кнопку See Results
        if (buttonText.includes('see results') || buttonText.includes('results') || 
            buttonText.includes('view results') || buttonText.includes('посмотреть')) {
          continue;
        }
        
        const style = window.getComputedStyle(button);
        
        // Проверяем зеленый цвет (цвет победителя в Twitch) - более широкий диапазон
        const bgColor = style.backgroundColor;
        const isGreen = bgColor.includes('rgb(0, 128') || 
                       bgColor.includes('rgb(46, 204') ||
                       bgColor.includes('rgb(0, 186') ||
                       bgColor.includes('rgb(56, 139') ||
                       bgColor.includes('rgb(76, 175') ||
                       bgColor.includes('#008') ||
                       bgColor.includes('#00b') ||
                       bgColor.includes('#4ca');
        
        // Проверяем границу
        const borderColor = style.borderColor;
        const hasGreenBorder = borderColor.includes('rgb(0, 128') || 
                              borderColor.includes('rgb(46, 204') ||
                              borderColor.includes('#008');
        
        // Проверяем текст и классы
        const hasWinnerText = this.hasKeyword(buttonText, 'winner') || 
                             buttonText.includes('won') ||
                             buttonText.includes('победил') ||
                             buttonText.includes('выиграл');
        
        // Проверяем className (может быть строкой или DOMTokenList)
        const buttonClassName = typeof button.className === 'string' 
          ? button.className 
          : (button.className?.baseVal || button.className?.toString() || '');
        const hasWinnerClass = buttonClassName.toLowerCase().includes('winner') ||
                              buttonClassName.toLowerCase().includes('win') ||
                              button.getAttribute('data-winner') === 'true';
        
        if (isGreen || hasGreenBorder || hasWinnerText || hasWinnerClass) {
          // Определяем, какой это вариант по тексту
          if (buttonText.includes('option 1') || buttonText.includes('вариант 1') || 
              (buttonText.match(/\b1\b/) && !buttonText.match(/\b2\b/))) {
            return 0;
          } else if (buttonText.includes('option 2') || buttonText.includes('вариант 2') ||
                    (buttonText.match(/\b2\b/) && !buttonText.match(/\b1\b/))) {
            return 1;
          }
          
          // Если не нашли в тексте, используем позицию кнопок
          const betButtons = Array.from(buttons).filter(btn => {
            const txt = btn.textContent?.toLowerCase() || '';
            return !txt.includes('see results') && !txt.includes('results') && 
                   !txt.includes('view results') && txt.length > 0;
          });
          
          const buttonIndex = betButtons.indexOf(button);
          if (buttonIndex === 0) {
            return 0;
          } else if (buttonIndex === 1) {
            return 1;
          }
        }
      }
      
      // Метод 6: Ищем элементы с классом "winner" или атрибутом data-winner
      const winnerElements = container.querySelectorAll('[class*="winner"], [data-winner="true"], [data-winner="1"], [data-winner="0"]');
      for (const elem of winnerElements) {
        const elemText = elem.textContent?.toLowerCase() || '';
        const dataWinner = elem.getAttribute('data-winner');
        
        if (dataWinner === '0' || elemText.includes('option 1') || (elemText.match(/\b1\b/) && !elemText.match(/\b2\b/))) {
          return 0;
        } else if (dataWinner === '1' || elemText.includes('option 2') || (elemText.match(/\b2\b/) && !elemText.match(/\b1\b/))) {
          return 1;
        }
      }
      
      return null;
    } catch (error) {
      return null;
    }
  }

  processPredictionResult(predictionId, winningOption) {
    
    // Обновляем локальный статус
    this.updateUserBetsStatus(predictionId, 'resolved', winningOption);
    
    // Показываем уведомление
    this.showNotification(`Winner: Option ${winningOption + 1}`, 'success');
    
    // Удаляем кнопки POL ставок
    this.removePolButtonsForPrediction(predictionId);
  }

  removePolButtonsForPrediction(predictionId) {
    const keysToRemove = [];
    for (const [key, buttonData] of this.polButtons) {
      if (buttonData.element && document.body.contains(buttonData.element)) {
        buttonData.element.remove();
      }
      keysToRemove.push(key);
    }
    
    keysToRemove.forEach(key => {
      this.polButtons.delete(key);
    });
    
  }

  // Группируем ставки по каналу и варианту
  getGroupedActiveBets() {
    const activeBets = (this.userBets || []).filter(
      bet => bet && (bet.status === 'pending' || bet.status === 'active') && bet.contractId
    );
    const groups = {};
    
    activeBets.forEach(bet => {
      const baseId = bet.contractId || bet.predictionId || `${bet.channel}_${bet.timestamp}`;
      const key = `${baseId}_${bet.optionIndex}`;
      if (!groups[key]) {
        groups[key] = {
          contractId: bet.contractId || null,
          predictionId: bet.predictionId || null,
          channel: bet.channel,
          channelUrl: bet.channelUrl,
          optionIndex: bet.optionIndex,
          totalAmount: 0,
          betCount: 0,
          bets: []
        };
      }
      const amount = Number(bet.amount) || 0;
      groups[key].totalAmount += amount;
      groups[key].betCount++;
      groups[key].bets.push(bet);
    });
    
    return Object.values(groups).filter(g => g.bets.length > 0 && g.totalAmount > 0);
  }

  // Получаем историю ставок - ГРУППИРУЕМ ПО ПРЕДИКТУ И ВАРИАНТУ
  getBetsHistory() {
    const historyBets = this.userBets.filter(bet => bet.status === 'won' || bet.status === 'lost' || bet.status === 'refunded');
    
    // Группируем ставки по predictionId и optionIndex
    const groupedBets = {};
    
    historyBets.forEach(bet => {
      const key = `${bet.predictionId}_${bet.optionIndex}`;
      if (!groupedBets[key]) {
        groupedBets[key] = {
          predictionId: bet.predictionId,
          optionIndex: bet.optionIndex,
          status: bet.status,
          totalAmount: 0,
          betCount: 0,
          channel: bet.channel,
          channelUrl: bet.channelUrl,
          timestamp: bet.timestamp,
          resolveTime: bet.resolveTime,
          refundTime: bet.refundTime,
          bets: []
        };
      }
      groupedBets[key].totalAmount += bet.amount;
      groupedBets[key].betCount += 1;
      groupedBets[key].bets.push(bet);
      
      // Используем самое позднее время для группы
      const betTime = bet.resolveTime || bet.refundTime || bet.timestamp;
      const groupTime = groupedBets[key].resolveTime || groupedBets[key].refundTime || groupedBets[key].timestamp;
      if (betTime > groupTime) {
        groupedBets[key].timestamp = betTime;
      }
    });
    
    // Преобразуем объект в массив и сортируем
    const result = Object.values(groupedBets).sort((a, b) => {
      const timeA = a.resolveTime || a.refundTime || a.timestamp;
      const timeB = b.resolveTime || b.refundTime || b.timestamp;
      return timeB - timeA;
    });
    
    return result;
  }

  // НОВАЯ ФУНКЦИЯ: Обновление статуса ставок
  async updateUserBetsStatus(predictionId, status, winningOption = null) {
    const prediction = this.activePredictions.get(predictionId);
    if (!prediction) return;
    
    // Обновляем статус предикта
    prediction.status = status === 'resolved' ? 'completed' : status;
    if (winningOption !== null) {
      prediction.winningOption = winningOption;
    }
    prediction.endTime = Date.now();
    
    // Обновляем ставки пользователя
    this.userBets = this.userBets.map(bet => {
      if (bet.predictionId === predictionId) {
        if (status === 'resolved') {
          bet.status = (bet.optionIndex === winningOption) ? 'won' : 'lost';
          bet.resolveTime = Date.now();
        } else if (status === 'timeout') {
          bet.status = 'refunded';
          bet.refundTime = Date.now();
        }
      }
      return bet;
    });
    
    await this.saveUserBets();
    this.safeUpdateUI();
  }

  createIndicator() {
    const oldIndicator = document.getElementById('twitch-bets-indicator');
    if (oldIndicator) oldIndicator.remove();

    this.predictionIndicator = document.createElement('button');
    this.predictionIndicator.id = 'twitch-bets-indicator';
    this.predictionIndicator.innerHTML = '🎯';
    this.predictionIndicator.title = 'Stream Market - Web3 Predictions';
    this.predictionIndicator.type = 'button';
    this.predictionIndicator.setAttribute('aria-label', 'Stream Market');

    this.predictionIndicator.style.cssText = `
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      width: 40px !important;
      height: 40px !important;
      background: linear-gradient(135deg, #9146FF, #6A35FF) !important;
      color: white !important;
      font-size: 20px !important;
      border-radius: 8px !important;
      border: 2px solid rgba(255, 255, 255, 0.3) !important;
      cursor: pointer !important;
      margin: 0 4px !important;
      padding: 0 !important;
      box-shadow: 0 3px 10px rgba(145, 70, 255, 0.4) !important;
      z-index: 999999 !important;
      transition: all 0.2s ease !important;
      flex-shrink: 0 !important;
      position: relative !important;
    `;

    this.predictionIndicator.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.toggleBettingUI();
    });

    this.predictionIndicator.addEventListener('mouseenter', () => {
      this.predictionIndicator.style.transform = 'scale(1.1)';
    });

    this.predictionIndicator.addEventListener('mouseleave', () => {
      this.predictionIndicator.style.transform = 'scale(1)';
    });

  }

  toggleBettingUI() {
    if (this.bettingUI && document.body.contains(this.bettingUI)) {
      this.bettingUI.remove();
      this.bettingUI = null;
    } else {
      this.showBettingUI();
    }
  }

  // Обновление процентов для всех POL элементов
  async updateAllPolPercentages() {
    const allPolElements = document.querySelectorAll('.twitch-bets-pol-option[data-channel][data-option-index]');
    
    if (allPolElements.length === 0) return;
    
    // Группируем по каналам для оптимизации запросов
    const channelGroups = new Map();
    allPolElements.forEach(el => {
      const channel = el.getAttribute('data-channel');
      const optionIndex = parseInt(el.getAttribute('data-option-index'));
      
      if (!channel) return;
      
      if (!channelGroups.has(channel)) {
        channelGroups.set(channel, []);
      }
      channelGroups.get(channel).push({ element: el, optionIndex });
    });
    
    // Обновляем проценты для каждого канала
    for (const [channel, elements] of channelGroups) {
      try {
        const openPredictionId = await this.getOpenPredictionIdForChannel(channel);
        if (!openPredictionId) {
          // Если нет открытого предикта, показываем 0% для всех
          elements.forEach(({ element }) => {
            const percentageDisplay = element.querySelector('.twitch-bets-percentage-display');
            if (percentageDisplay) {
              percentageDisplay.textContent = '0.0%';
            }
          });
          continue;
        }
        
        // Получаем информацию о предикте
        if (!this.provider) {
          const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
          this.provider = new ethers.JsonRpcProvider(rpcUrl);
        }
        
        const contract = new ethers.Contract(
          this.config.PREDICTION_CONTRACT_ADDRESS,
          this.config.CONTRACT_ABI,
          this.provider
        );
        
        const predictionInfo = await this.queueRpcRequest(async () => {
          return await contract.getPredictionInfo(openPredictionId);
        });
        
        if (predictionInfo && predictionInfo.totalPool > 0n) {
          const totalPool = Number(predictionInfo.totalPool) / 1e18;
          // Новый контракт: pool0/pool1
          const option0Amount = Number(predictionInfo.pool0 || predictionInfo[2] || 0n) / 1e18;
          const option1Amount = Number(predictionInfo.pool1 || predictionInfo[3] || 0n) / 1e18;
          
          // Рассчитываем проценты для обоих вариантов
          const percentage0 = totalPool > 0 ? (option0Amount / totalPool) * 100 : 0;
          const percentage1 = totalPool > 0 ? (option1Amount / totalPool) * 100 : 0;
          
          // Обновляем проценты для каждого элемента
          elements.forEach(({ element, optionIndex }) => {
            const percentage = optionIndex === 0 ? percentage0 : percentage1;
            const percentageDisplay = element.querySelector('.twitch-bets-percentage-display');
            if (percentageDisplay) {
              percentageDisplay.textContent = `${percentage.toFixed(1)}%`;
            }
          });
        } else {
          // Если пул пустой, показываем 0% для всех
          elements.forEach(({ element }) => {
            const percentageDisplay = element.querySelector('.twitch-bets-percentage-display');
            if (percentageDisplay) {
              percentageDisplay.textContent = '0.0%';
            }
          });
        }
      } catch (error) {
        // Игнорируем ошибки при обновлении (rate limit и т.д.)
      }
    }
  }


  // Частичное обновление UI (только таймеры и изменяющиеся элементы)
  updateUITimers() {
    if (!this.bettingUI || !document.body.contains(this.bettingUI)) return;
    
    // Обновляем только таймеры claim кнопок
    if (this.currentTab === 'active') {
      const claimButtons = this.bettingUI.querySelectorAll('.twitch-bets-claim-btn');
      claimButtons.forEach(btn => {
        const contractId = btn.getAttribute('data-contract-id');
        if (!contractId) return;
        
        // Находим соответствующую группу ставок
        const groupedBets = this.getGroupedActiveBets();
        const group = groupedBets.find(g => g.contractId === contractId);
        if (!group) return;
        
        const claimUnlockAt = this._getClaimUnlockAtForGroup(group);
        const nowMs = Date.now();
        const waitingMs = claimUnlockAt ? (claimUnlockAt - nowMs) : null;
        const canClaimByTime = claimUnlockAt ? (waitingMs <= 0) : false;
        const claimEnabled = Boolean(this.isConnected && group.contractId && canClaimByTime);
        const claimLabel = claimUnlockAt && waitingMs > 0
          ? `Claim in ${this._formatCountdownMs(waitingMs)}`
          : 'Claim';
        
        // Обновляем только текст и состояние кнопки, если изменилось
        if (btn.textContent !== claimLabel) {
          btn.textContent = claimLabel;
        }
        if (btn.disabled !== !claimEnabled) {
          btn.disabled = !claimEnabled;
          btn.style.opacity = claimEnabled ? '1' : '0.5';
          btn.style.cursor = claimEnabled ? 'pointer' : 'not-allowed';
        }
      });
    }
  }

  async safeUpdateUI() {
    // Debounce для предотвращения множественных обновлений при быстром переключении вкладок
    if (this._uiUpdateDebounceTimer) {
      clearTimeout(this._uiUpdateDebounceTimer);
    }
    
    return new Promise((resolve) => {
      this._uiUpdateDebounceTimer = setTimeout(async () => {
        this._uiUpdateDebounceTimer = null;
        
        if (this._uiUpdateInProgress) {
          resolve();
          return;
        }
        
        this._uiUpdateInProgress = true;
        
        try {
          if (this.bettingUI && document.body.contains(this.bettingUI)) {
            // НОВАЯ ЛОГИКА: Создаем новый элемент ВНЕ DOM, применяем все стили, только потом заменяем
            
            // 1. ЖЕСТКО фиксируем размеры и позицию СУЩЕСТВУЮЩЕГО элемента
            const oldUI = this.bettingUI;
            const computedStyle = window.getComputedStyle(oldUI);
            const fixedStyles = {
              position: 'fixed',
              top: computedStyle.top || '50%',
              right: computedStyle.right || '5px',
              transform: 'translateY(-50%)',
              zIndex: '10000000',
              maxHeight: '85vh',
              maxWidth: '360px',
              width: '360px',
              minWidth: '360px',
              boxSizing: 'border-box',
              overflow: 'hidden'
            };
            
            // 2. Скрываем старый элемент
            oldUI.style.opacity = '0';
            oldUI.style.pointerEvents = 'none';
            
            // 3. Применяем фиксированные размеры к старому элементу
            Object.assign(oldUI.style, {
              position: 'fixed',
              top: fixedStyles.top,
              right: fixedStyles.right,
              transform: fixedStyles.transform,
              zIndex: fixedStyles.zIndex,
              maxHeight: fixedStyles.maxHeight,
              maxWidth: fixedStyles.maxWidth,
              width: fixedStyles.width,
              minWidth: fixedStyles.minWidth,
              boxSizing: fixedStyles.boxSizing,
              overflow: fixedStyles.overflow
            });
            
            // 4. Принудительно применяем стили
            void oldUI.offsetHeight;
            
            // 5. Создаем НОВЫЙ элемент ВНЕ DOM
            const newUI = await this.createBettingUI();
            if (!newUI) {
              oldUI.style.opacity = '1';
              oldUI.style.pointerEvents = 'auto';
              this._uiUpdateInProgress = false;
              resolve();
              return;
            }
            
            // 6. ЖЕСТКО фиксируем размеры нового элемента ДО добавления в DOM
            Object.assign(newUI.style, fixedStyles);
            newUI.style.opacity = '0';
            newUI.style.pointerEvents = 'none';
            
            // 7. Фиксируем размеры внутреннего контейнера нового элемента
            const newInnerContainer = newUI.querySelector('div[style*="background: linear-gradient(180deg"]');
            if (newInnerContainer) {
              newInnerContainer.style.width = '320px';
              newInnerContainer.style.minWidth = '320px';
              newInnerContainer.style.maxWidth = '320px';
              newInnerContainer.style.boxSizing = 'border-box';
            }
            
            // 8. Принудительно применяем стили к новому элементу (он еще не в DOM)
            void newUI.offsetHeight;
            if (newInnerContainer) void newInnerContainer.offsetHeight;
            
            // 9. Заменяем старый элемент новым (оба имеют одинаковые размеры)
            if (oldUI.parentNode) {
              oldUI.parentNode.replaceChild(newUI, oldUI);
            }
            
            // 10. Сохраняем ссылку
            this.bettingUI = newUI;
            
            // 11. Принудительно применяем стили еще раз после замены
            void newUI.offsetHeight;
            
            // 12. Показываем новый элемент
            requestAnimationFrame(() => {
              newUI.style.opacity = '1';
              newUI.style.pointerEvents = 'auto';
              
              // Удаляем индикатор загрузки если есть
              const loadingIndicator = newUI.querySelector('.twitch-bets-loading');
              if (loadingIndicator) {
                loadingIndicator.remove();
              }
              
              // Настраиваем обработчики
              this.setupUIEventListeners();
              
              // Обновляем конвертацию USDT (один раз, без повторных вызовов)
              this.updateUsdtConversion();
            });
          }
        } finally {
          this._uiUpdateInProgress = false;
          resolve();
        }
      }, 50); // Уменьшил debounce до 50ms для более быстрой реакции
    });
  }

  tryInsertIndicator() {
    // Улучшенный поиск чата - используем несколько селекторов
    const chatInputSelectors = [
      'textarea[data-a-target="chat-input"]',
      '.chat-input',
      '[data-test-selector="chat-input"]',
      '[data-a-target="tw-input-textarea"]',
      '[role="textbox"]',
      'div[contenteditable="true"]'
    ];
    
    let chatInput = null;
    
    for (const selector of chatInputSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        chatInput = element;
        break;
      }
    }
    
    if (!chatInput) {
      // Дополнительный поиск в глубину DOM
      const potentialInputs = document.querySelectorAll('textarea, input, [contenteditable="true"]');
      for (const input of potentialInputs) {
        const placeholder = input.getAttribute('placeholder') || '';
        const ariaLabel = input.getAttribute('aria-label') || '';
        if (placeholder.toLowerCase().includes('chat') || 
            ariaLabel.toLowerCase().includes('chat') ||
            (typeof input.className === 'string' && input.className.includes('chat')) ||
            (input.className && input.className.baseVal && input.className.baseVal.includes('chat'))) {
          chatInput = input;
          break;
        }
      }
    }
    
    if (chatInput && chatInput.parentElement) {
      if (!this.predictionIndicator) {
        this.createIndicator();
      }
      
      let buttonsContainer = chatInput.parentElement.querySelector('[data-a-target="chat-input-buttons"], .chat-input__buttons-container');
      if (!buttonsContainer) {
        // Ищем контейнер для кнопок рядом с чатом
        const parent = chatInput.parentElement;
        const grandParent = parent.parentElement;
        
        // Проверяем несколько уровней вверх
        const potentialContainers = [
          parent.querySelector('.buttons-container'),
          parent.querySelector('.chat-input__buttons'),
          grandParent.querySelector('.chat-input__buttons-container'),
          grandParent.querySelector('[data-a-target="chat-input-buttons"]')
        ];
        
        for (const container of potentialContainers) {
          if (container) {
            buttonsContainer = container;
            break;
          }
        }
        
        if (!buttonsContainer) {
          buttonsContainer = document.createElement('div');
          buttonsContainer.style.cssText = `
            display: flex !important;
            align-items: center !important;
            gap: 4px !important;
            margin-left: auto !important;
          `;
          chatInput.parentElement.appendChild(buttonsContainer);
        }
      }

      // Проверяем, не добавлена ли уже кнопка
      const existingIndicator = buttonsContainer.querySelector('#twitch-bets-indicator');
      if (!existingIndicator) {
        // Убеждаемся, что кнопка существует
        if (!this.predictionIndicator) {
          this.createIndicator();
        }
        
        // Проверяем, что кнопка не находится в другом месте DOM
        if (document.body.contains(this.predictionIndicator)) {
          this.predictionIndicator.remove();
        }
        
        buttonsContainer.appendChild(this.predictionIndicator);
        return true;
      } else {
        // Кнопка уже есть, но проверяем, что она видима
        existingIndicator.style.display = 'flex';
        return true;
      }
    }
    
    return false;
  }

  setupChatMonitoring() {
    
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Быстрая проверка на наличие чата
              if (node.querySelector && (
                node.querySelector('textarea[data-a-target="chat-input"]') ||
                node.querySelector('.chat-input') ||
                node.querySelector('[data-a-target="tw-input-textarea"]')
              )) {
                setTimeout(() => this.tryInsertIndicator(), 50);
              }
              
              // Также проверяем сам элемент
              if (node.tagName === 'TEXTAREA' || 
                  node.getAttribute('data-a-target') === 'chat-input' ||
                  (typeof node.className === 'string' && node.className.includes('chat-input')) ||
                  (node.className && node.className.baseVal && node.className.baseVal.includes('chat-input'))) {
                setTimeout(() => this.tryInsertIndicator(), 50);
              }
            }
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // УСКОРЕННАЯ ПРОВЕРКА - УЛУЧШЕННАЯ ВЕРСИЯ
    // Проверяем каждые 100мс первые 3 секунды, затем реже
    const fastCheckInterval = setInterval(() => {
      if (this.chatCheckCounter < this.maxChatChecks) {
        this.chatCheckCounter++;
        const inserted = this.tryInsertIndicator();
        
        // Если кнопка вставлена, можно остановить быстрые проверки
        if (inserted) {
          clearInterval(fastCheckInterval);
        }
      } else {
        clearInterval(fastCheckInterval);
        // Переходим на обычную проверку каждые 1 секунду
        setInterval(() => {
          this.tryInsertIndicator();
        }, 1000);
      }
    }, 100); // Проверяем каждые 100мс

    // Дополнительные быстрые проверки
    const quickChecks = [100, 200, 300, 400, 500, 700, 900, 1200, 1500, 2000, 2500, 3000];
    quickChecks.forEach(timeout => {
      setTimeout(() => {
        this.tryInsertIndicator();
      }, timeout);
    });

    // Также запускаем проверку сразу
    setTimeout(() => this.tryInsertIndicator(), 0);
    
  }

  setupEventListeners() {
    window.addEventListener('message', (event) => {
      if (event.data.type === 'TWITCH_BETS_WEB3_RESPONSE') {
        const { requestId, success, result, error } = event.data;
        const resolver = this.pendingRequests.get(requestId);
        if (resolver) {
          this.pendingRequests.delete(requestId);
          if (success) {
            resolver.resolve(result);
          } else {
            resolver.reject(new Error(error));
          }
        }
      }

      if (event.data.type === 'TWITCH_BETS_METAMASK_EVENT') {
        this.handleMetaMaskEvent(event.data);
      }
    });

    chrome.runtime.onMessage.addListener(this.handleRuntimeMessage.bind(this));
  }

  async callWeb3(method, params = null) {
    return new Promise((resolve, reject) => {
      const requestId = ++this.requestCounter;
      this.pendingRequests.set(requestId, { resolve, reject });

      window.postMessage({
        type: 'TWITCH_BETS_WEB3_REQUEST',
        requestId,
        method,
        params
      }, '*');

      setTimeout(() => {
        if (this.pendingRequests.has(requestId)) {
          this.pendingRequests.delete(requestId);
          reject(new Error('Web3 request timeout'));
        }
      }, 30000);
    });
  }

  async checkExistingConnection() {
    try {
      // Ждем появления window.ethereum
      let ethereum = null;
      for (let i = 0; i < 5; i++) {
        if (typeof window !== 'undefined' && window.ethereum) {
          ethereum = window.ethereum;
          if (ethereum.isMetaMask || ethereum._metamask) {
            break;
          }
        }
        if (i < 4) {
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }
      
      // Проверяем напрямую через window.ethereum
      if (ethereum) {
        try {
          const accounts = await ethereum.request({ 
            method: 'eth_accounts' 
          });
          
          if (accounts && accounts.length > 0) {
            this.walletAddress = accounts[0];
            this.isConnected = true;
            
            const chainId = await ethereum.request({ 
              method: 'eth_chainId' 
            });
            this.chainId = chainId;

            // Обновляем реальный баланс
            await this.updateWalletBalance();
            
            return;
          }
        } catch (error) {
        }
      }
      
      // Fallback через callWeb3
      try {
        const hasMetaMask = await this.callWeb3('checkMetaMaskInstalled');
        if (!hasMetaMask) {
          return;
        }

        const accounts = await this.callWeb3('getAccounts');
        if (accounts && accounts.length > 0) {
          this.walletAddress = accounts[0];
          this.isConnected = true;
          this.chainId = await this.callWeb3('getChainId');

          // Обновляем реальный баланс
          await this.updateWalletBalance();
          
        }
      } catch (error) {
      }
    } catch (error) {
    }
  }

  handleMetaMaskEvent(event) {
    switch (event.event) {
      case 'accountsChanged':
        if (event.data && event.data.length > 0) {
          this.walletAddress = event.data[0];
          this.isConnected = true;
          this.updateWalletBalance();
          this.safeUpdateUI();
          this.processedPredictions.clear();
          this.polButtons.clear();
          this.scanDocumentForPredictions();
        } else {
          this.disconnectWallet();
        }
        break;
      case 'chainChanged':
        this.chainId = event.data;
        this.updateWalletBalance();
        this.safeUpdateUI();
        this.processedPredictions.clear();
        this.polButtons.clear();
        this.scanDocumentForPredictions();
        break;
      case 'disconnect':
        this.disconnectWallet();
        break;
    }
  }

  async connectMetaMask() {
    try {
      
      // Ждем появления window.ethereum (MetaMask может загружаться асинхронно)
      let ethereum = null;
      
      for (let i = 0; i < 10; i++) {
        if (typeof window !== 'undefined' && window.ethereum) {
          // Если есть массив провайдеров, ищем MetaMask
          if (Array.isArray(window.ethereum.providers)) {
            ethereum = window.ethereum.providers.find(p => p.isMetaMask) || window.ethereum.providers[0];
          } else {
            ethereum = window.ethereum;
          }
          
          
          // Принимаем любой провайдер с методом request
          if (ethereum && typeof ethereum.request === 'function') {
            break;
          }
        }
        if (i < 9) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
      
      // Если не нашли, пробуем через callWeb3
      if (!ethereum) {
        try {
          const hasMetaMask = await this.callWeb3('checkMetaMaskInstalled');
          if (!hasMetaMask) {
            this.showNotification('Please install MetaMask extension first', 'warning');
            return { success: false, error: 'MetaMask not installed' };
          }
          
          // Если callWeb3 говорит что MetaMask есть, но window.ethereum нет - используем callWeb3
          const accounts = await this.callWeb3('requestAccounts');
          if (!accounts || accounts.length === 0) {
            throw new Error('No accounts returned');
          }

          this.walletAddress = accounts[0];
          this.isConnected = true;
          this.chainId = await this.callWeb3('getChainId');

          await this.updateWalletBalance();
          await this.saveWalletData();
          this.showNotification('MetaMask connected successfully!', 'success');
          
          this.safeUpdateUI();
          this.processedPredictions.clear();
          this.polButtons.clear();
          setTimeout(() => this.scanDocumentForPredictions(), 100);

          return { success: true, address: this.walletAddress, chainId: this.chainId };
        } catch (callError) {
          this.showNotification('Please install MetaMask extension first', 'warning');
          return { success: false, error: 'MetaMask not installed' };
        }
      }

      // Используем прямой доступ к window.ethereum
      try {
        const accounts = await ethereum.request({ 
          method: 'eth_requestAccounts' 
        });
        
        if (!accounts || accounts.length === 0) {
          throw new Error('No accounts returned');
        }

        this.walletAddress = accounts[0];
        this.isConnected = true;
        
        // Получаем chainId
        const chainId = await ethereum.request({ 
          method: 'eth_chainId' 
        });
        this.chainId = chainId;

        // Обновляем реальный баланс
        await this.updateWalletBalance();
        
        await this.saveWalletData();
        this.showNotification('MetaMask connected successfully!', 'success');
        
        this.safeUpdateUI();
        
        this.processedPredictions.clear();
        this.polButtons.clear();
        setTimeout(() => this.scanDocumentForPredictions(), 100);

        return { success: true, address: this.walletAddress, chainId: this.chainId };
      } catch (ethError) {
        // Если прямой доступ не работает, пробуем через callWeb3
        
        // Если это ошибка отклонения пользователем, не пробуем callWeb3
        if (ethError.code === 4001 || ethError.message?.includes('User rejected')) {
          this.showNotification('Connection rejected. Please approve in MetaMask.', 'error');
          return { success: false, error: 'Connection rejected' };
        }
        
        try {
          const hasMetaMask = await this.callWeb3('checkMetaMaskInstalled');
          if (!hasMetaMask) {
            this.showNotification('Please install MetaMask extension first', 'warning');
            return { success: false, error: 'MetaMask not installed' };
          }

          const accounts = await this.callWeb3('requestAccounts');
          if (!accounts || accounts.length === 0) {
            throw new Error('No accounts returned');
          }

          this.walletAddress = accounts[0];
          this.isConnected = true;
          this.chainId = await this.callWeb3('getChainId');

          await this.updateWalletBalance();
          await this.saveWalletData();
          this.showNotification('MetaMask connected successfully!', 'success');
          
          this.safeUpdateUI();
          this.processedPredictions.clear();
          this.polButtons.clear();
          setTimeout(() => this.scanDocumentForPredictions(), 100);

          return { success: true, address: this.walletAddress, chainId: this.chainId };
        } catch (callError) {
          throw ethError; // Пробрасываем оригинальную ошибку
        }
      }
    } catch (error) {
      let errorMessage = error.message;
      if (error.message && (error.message.includes('User rejected') || error.code === 4001)) {
        errorMessage = 'Connection rejected. Please approve in MetaMask.';
      } else if (error.message && error.message.includes('already pending')) {
        errorMessage = 'Request already pending. Please check MetaMask.';
      }
      this.showNotification(`MetaMask Error: ${errorMessage}`, 'error');
      return { success: false, error: errorMessage };
    }
  }

  async disconnectWallet() {
    try {
      this.walletAddress = null;
      this.isConnected = false;
      this.chainId = null;
      this.userBalance = { pol: 0, usdt: 0 };

      await chrome.storage.local.set({
        walletConnected: false,
        walletAddress: null,
        walletBalance: 0,
        chainId: null
      });

      this.showNotification('MetaMask disconnected', 'info');
      
      this.safeUpdateUI();
      
      this.processedPredictions.clear();
      this.polButtons.clear();
      setTimeout(() => this.scanDocumentForPredictions(), 100);

      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // ИСПРАВЛЕННАЯ ФУНКЦИЯ: Получение реального баланса из MetaMask
  async getRealBalance() {
    try {
      if (!this.walletAddress || !this.isConnected) {
        return 0;
      }

      // Проверяем, что мы в правильной сети
      if (this.chainId !== this.config.POLYGON_CHAIN_ID) {
        return 0;
      }

      // Используем прямой доступ к window.ethereum с fallback на callWeb3
      let balanceWei;
      if (typeof window !== 'undefined' && window.ethereum) {
        try {
          balanceWei = await window.ethereum.request({
            method: 'eth_getBalance',
            params: [this.walletAddress, 'latest']
          });
        } catch (error) {
          balanceWei = await this.callWeb3('getBalance', [this.walletAddress]);
        }
      } else {
        balanceWei = await this.callWeb3('getBalance', [this.walletAddress]);
      }
      
      if (!balanceWei) {
        return 0;
      }

      // Конвертируем из wei в POL используя ethers.js
      let balancePol;
      if (typeof ethers !== 'undefined') {
        balancePol = parseFloat(ethers.formatEther(balanceWei));
      } else {
        // Fallback если ethers.js не загружен
        const wei = parseInt(balanceWei, 16);
        balancePol = wei / 1e18;
      }
      
      return balancePol;
      
    } catch (error) {
      return 0;
    }
  }

  // ИСПРАВЛЕННАЯ ФУНКЦИЯ: Обновление баланса кошелька
  async updateWalletBalance() {
    try {
      if (!this.walletAddress || !this.isConnected) {
        this.userBalance = { pol: 0, usdt: 0 };
        // Сохраняем в хранилище
        await chrome.runtime.sendMessage({
          action: 'updateWalletBalance',
          balance: 0
        });
        // Обновляем конвертацию USDT
        await this.updateUsdtConversion();
        return this.userBalance;
      }

      // Получаем реальный баланс
      const balancePol = await this.getRealBalance();
      
      this.userBalance.pol = balancePol;

      // Сохраняем в хранилище
      await chrome.runtime.sendMessage({
        action: 'updateWalletBalance',
        balance: balancePol
      });

      // Обновляем конвертацию USDT после обновления баланса
      await this.updateUsdtConversion();

      // НЕ обновляем UI при каждом обновлении баланса, чтобы избежать мигания
      // UI обновится только при открытии/закрытии или при явном вызове
      // this.safeUpdateUI();

      return this.userBalance;
    } catch (error) {
      this.userBalance = { pol: 0, usdt: 0 };
      await this.updateUsdtConversion();
      return this.userBalance;
    }
  }

  async switchToPolygon() {
    try {
      await this.callWeb3('switchToPolygon');
      this.chainId = '0x89'; // Polygon
      await this.updateWalletBalance();
      this.showNotification('Switched to Polygon network', 'success');
      return { success: true };
    } catch (error) {
      this.showNotification(`Failed to switch network: ${error.message}`, 'error');
      return { success: false, error: error.message };
    }
  }

  async saveWalletData() {
    try {
      await chrome.storage.local.set({
        walletConnected: true,
        walletAddress: this.walletAddress,
        walletBalance: this.userBalance.pol,
        chainId: this.chainId,
        lastConnection: new Date().toISOString()
      });

    } catch (error) {
    }
  }

  async getPolUsdtRate() {
    // Проверяем кэш - кэшируем курс на 10 минут
    const CACHE_TTL = 10 * 60 * 1000; // 10 минут в миллисекундах
    const cacheKey = 'polUsdtRate';
    const cached = this.polUsdtRateCache;
    
    if (cached && cached.rate && cached.timestamp && (Date.now() - cached.timestamp) < CACHE_TTL) {
      return cached.rate;
    }
    
    try {
      // Используем CoinGecko API для получения курса POL к USDT
      const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=polygon-ecosystem-token&vs_currencies=usd', {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        // Если запрос не удался, используем кэшированное значение если есть
        if (cached && cached.rate) {
          return cached.rate;
        }
        return null;
      }
      
      const data = await response.json();
      // API возвращает: {"polygon-ecosystem-token":{"usd":0.118861}}
      if (data && data['polygon-ecosystem-token'] && data['polygon-ecosystem-token'].usd) {
        const rate = data['polygon-ecosystem-token'].usd;
        // Сохраняем в кэш
        this.polUsdtRateCache = {
          rate: rate,
          timestamp: Date.now()
        };
        return rate;
      }
    } catch (error) {
      // Если ошибка, используем кэшированное значение если есть
      if (cached && cached.rate) {
        return cached.rate;
      }
    }
    // Fallback: используем примерный курс если API недоступен
    return null;
  }

  async updateUsdtConversion() {
    if (!this.bettingUI) {
      // Если UI еще не создан, не делаем запрос - подождем следующего интервала
      return;
    }
    
    const usdtElement = this.bettingUI.querySelector('#usdt-value');
    if (!usdtElement) {
      // Если элемент не найден, не делаем запрос - подождем следующего интервала
      return;
    }
    
    const polBalance = this.userBalance.pol || 0;
    if (polBalance === 0) {
      usdtElement.textContent = '≈ $0.00 USDT';
      return;
    }
    
    try {
      const rate = await this.getPolUsdtRate();
      if (rate && rate > 0) {
        const usdtValue = polBalance * rate;
        usdtElement.textContent = `≈ $${usdtValue.toFixed(2)} USDT`;
      } else {
        usdtElement.textContent = '—';
      }
    } catch (error) {
      usdtElement.textContent = '—';
    }
  }

  async createBettingUI() {
    const walletDisplayRaw = this.walletAddress
      ? `${this.walletAddress.substring(0, 6)}...${this.walletAddress.substring(this.walletAddress.length - 4)}`
      : 'Not connected';
    const walletDisplay = escapeHtml(walletDisplayRaw);
    const networkStatusRaw = this.chainId === this.config.POLYGON_CHAIN_ID ? `✓ Polygon` : `⚠ Switch to Polygon`;
    const networkStatus = escapeHtml(networkStatusRaw);
    
    // Используем реальный баланс POL
    const polBalance = this.userBalance.pol || 0;
    let polDisplay;
    if (polBalance === 0) {
      polDisplay = '0.00';
    } else if (polBalance < 0.0001) {
      polDisplay = polBalance.toFixed(8);
    } else if (polBalance < 0.01) {
      polDisplay = polBalance.toFixed(6);
    } else if (polBalance < 1) {
      polDisplay = polBalance.toFixed(4);
    } else if (polBalance < 100) {
      polDisplay = polBalance.toFixed(2);
    } else {
      polDisplay = polBalance.toFixed(0);
    }
    polDisplay = escapeHtml(polDisplay);

    // Получаем сгруппированные активные ставки
    const groupedBets = this.getGroupedActiveBets();
    const historyBets = this.getBetsHistory();
    
    // Создаем HTML для активных ставок
    let activeBetsHTML = '';
    if (groupedBets.length > 0) {
      // Получаем информацию о предиктах для расчета процентов (с кэшированием)
      const predictionInfoPromises = groupedBets.map(group => {
        if (!group.contractId) return Promise.resolve(null);
        
        return (async () => {
          try {
            let predictionId = group.contractId;
            if (typeof predictionId === 'string' && !predictionId.startsWith('0x')) {
              predictionId = ethers.id(predictionId).slice(0, 66);
            }
            
            // Проверяем кэш
            const cacheKey = predictionId;
            const cached = this.predictionInfoCache.get(cacheKey);
            if (cached && (Date.now() - cached.timestamp) < this.predictionInfoCacheTTL) {
              return cached.info;
            }
            
            if (!this.provider) {
              const rpcUrl = this.config.POLYGON_RPC_URL || 'https://polygon-rpc.com';
              this.provider = new ethers.JsonRpcProvider(rpcUrl);
            }
            
            const contract = new ethers.Contract(
              this.config.PREDICTION_CONTRACT_ADDRESS,
              this.config.CONTRACT_ABI,
              this.provider
            );
            
            const info = await this.queueRpcRequest(async () => {
              return await contract.getPredictionInfo(predictionId);
            });
            
            // Сохраняем в кэш в POL (1 POL = 1e18 wei), чтобы Browse не показывал сырые wei
            const pool0Pol = Number(info.pool0 ?? info[2] ?? 0) / 1e18;
            const pool1Pol = Number(info.pool1 ?? info[3] ?? 0) / 1e18;
            const infoNormalized = { ...info, pool0: pool0Pol, pool1: pool1Pol };
            this.predictionInfoCache.set(cacheKey, {
              info: infoNormalized,
              timestamp: Date.now()
            });
            
            return infoNormalized;
          } catch (e) {
            return null;
          }
        })();
      });
      
      // Ждем получения всей информации
      const allPredictionInfo = await Promise.all(predictionInfoPromises);
      
      groupedBets.forEach((group, index) => {
        const optionColor = group.optionIndex === 0 ? '#FF6B6B' : '#4D96FF';
        const channelUrl = group.channelUrl || `https://www.twitch.tv/${group.channel || 'unknown'}`;
        const claimUnlockAt = this._getClaimUnlockAtForGroup(group);
        const nowMs = Date.now();
        const waitingMs = claimUnlockAt ? (claimUnlockAt - nowMs) : null;
        const canClaimByTime = claimUnlockAt ? (waitingMs <= 0) : false;
        const claimEnabled = Boolean(this.isConnected && group.contractId && canClaimByTime);
        const claimLabel = escapeHtml(claimUnlockAt && waitingMs > 0
          ? `Claim in ${this._formatCountdownMs(waitingMs)}`
          : 'Claim');
        
        // Рассчитываем проценты для этого предикта
        let percentageDisplay = '—';
        const predictionInfo = allPredictionInfo[index];
        if (predictionInfo && predictionInfo.totalPool > 0n) {
          const totalPool = Number(predictionInfo.totalPool) / 1e18;
          // Новый контракт: pool0/pool1
          const option0Amount = Number(predictionInfo.pool0 || predictionInfo[2] || 0n) / 1e18;
          const option1Amount = Number(predictionInfo.pool1 || predictionInfo[3] || 0n) / 1e18;
          
          if (totalPool > 0) {
            const currentOptionAmount = group.optionIndex === 0 ? option0Amount : option1Amount;
            const percentage = (currentOptionAmount / totalPool) * 100;
            percentageDisplay = percentage > 0 ? `${percentage.toFixed(1)}%` : '—';
          }
        }
        percentageDisplay = escapeHtml(percentageDisplay);
        const channelUrlEsc = escapeHtml(channelUrl);
        const channelEsc = escapeHtml(group.channel || 'Unknown Channel');
        const contractIdDisplay = group.contractId
          ? escapeHtml(`ID: ${group.contractId.slice(0, 10)}...${group.contractId.slice(-6)}`)
          : 'ID: pending';
        const contractIdAttr = escapeHtml(group.contractId || '');
        
        activeBetsHTML += `
          <div style="
            background: linear-gradient(135deg, rgba(16, 16, 24, 0.8), rgba(30, 30, 46, 0.8));
            border-radius: 12px;
            padding: 14px;
            margin-bottom: 12px;
            font-size: 12px;
            border: 1px solid rgba(145, 70, 255, 0.2);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
          ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <div style="
                  width: 32px;
                  height: 32px;
                  background: ${optionColor};
                  border-radius: 8px;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: bold;
                  color: white;
                  font-size: 14px;
                ">
                  ${group.optionIndex + 1}
                </div>
                <div>
                  <div style="font-weight: 700; font-size: 13px; color: white;">Option ${group.optionIndex + 1}</div>
                  <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6);">${group.betCount} position${group.betCount !== 1 ? 's' : ''}</div>
                </div>
              </div>
              <div style="text-align: right;">
                <div style="font-weight: 700; font-size: 16px; color: #FFD700;">${group.totalAmount.toFixed(2)} POL</div>
                <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6);">Staked</div>
              </div>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; padding: 6px 0; border-top: 1px solid rgba(255, 255, 255, 0.1); border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
              <div style="font-size: 11px; color: rgba(255, 255, 255, 0.7);">Pool Share:</div>
              <div style="font-weight: 700; font-size: 14px; color: #4CAF50;">${percentageDisplay}</div>
            </div>
            
            <div style="display: flex; justify-content: center;">
              <a href="${channelUrlEsc}" target="_blank" style="
                color: #9146FF;
                font-weight: 600;
                font-size: 11px;
                padding: 6px 14px;
                background: rgba(145, 70, 255, 0.15);
                border-radius: 20px;
                border: 1px solid rgba(145, 70, 255, 0.3);
                text-decoration: none;
                display: inline-block;
                cursor: pointer;
                transition: all 0.2s;
              " onmouseover="this.style.opacity='0.8'; this.style.transform='translateY(-1px)';" 
                 onmouseout="this.style.opacity='1'; this.style.transform='translateY(0)';">
                ${channelEsc}
              </a>
            </div>

            <div style="
              display: flex;
              justify-content: space-between;
              align-items: center;
              gap: 10px;
              margin-top: 12px;
            ">
              <div style="
                font-size: 10px;
                color: rgba(255, 255, 255, 0.55);
                font-family: monospace;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                max-width: 190px;
              ">
                ${contractIdDisplay}
              </div>
              <button class="twitch-bets-claim-btn" data-contract-id="${contractIdAttr}" style="
                padding: 7px 10px;
                background: rgba(145, 70, 255, 0.18);
                border: 1px solid rgba(145, 70, 255, 0.5);
                border-radius: 10px;
                color: white;
                font-weight: 800;
                cursor: ${claimEnabled ? 'pointer' : 'not-allowed'};
                font-size: 11px;
                transition: all 0.2s;
                opacity: ${claimEnabled ? '1' : '0.5'};
                white-space: nowrap;
              " ${!claimEnabled ? 'disabled' : ''}>${claimLabel}</button>
            </div>
          </div>
        `;
      });
      
      // Убираем обертку для скролла - скролл теперь на уровне mainContent
      // activeBetsHTML остается как есть
    } else {
      activeBetsHTML = `
        <div style="
          text-align: center; 
          padding: 40px 20px; 
          color: rgba(255, 255, 255, 0.5); 
          font-size: 13px;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 12px;
          border: 2px dashed rgba(255, 255, 255, 0.1);
        ">
          <div style="font-size: 36px; margin-bottom: 16px; opacity: 0.5;">🎯</div>
          <div style="font-weight: 600; margin-bottom: 8px; color: rgba(255, 255, 255, 0.7);">No active predictions</div>
          <div style="font-size: 11px;">Participate in a prediction on any Twitch stream to see it here</div>
        </div>
      `;
    }

    // Создаем HTML для истории ставок
    let historyBetsHTML = '';
    
    if (historyBets.length > 0) {
      historyBets.forEach((group, index) => {
        const isWin = group.status === 'won';
        const isRefunded = group.status === 'refunded';
        // При выигрыше: выплата = ставка * коэффициент, но -10% комиссии
        // Примерно: profit = amount * 0.9 (если 50/50), показываем нетто профит
        // Реальный профит после комиссии ≈ amount * 0.8 при 50/50
        const winProfit = group.totalAmount * 0.9; // Примерный профит с учетом 10% комиссии
        const resultText = isWin ? `+${winProfit.toFixed(2)} POL` : 
                          isRefunded ? `-${(group.totalAmount * 0.1).toFixed(2)} POL (refund)` : 
                          `-${group.totalAmount.toFixed(2)} POL`;
        const resultColor = isWin ? '#4CAF50' : isRefunded ? '#FF9800' : '#FF4757';
        const optionColor = group.optionIndex === 0 ? '#FF6B6B' : '#4D96FF';
        const time = new Date(group.resolveTime || group.refundTime || group.timestamp);
        const timeString = escapeHtml(time.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}));
        const dateString = escapeHtml(time.toLocaleDateString([], {month: 'short', day: 'numeric'}));
        const channelUrl = group.channelUrl || `https://www.twitch.tv/${group.channel || 'unknown'}`;
        const channelUrlEsc = escapeHtml(channelUrl);
        const channelNameEsc = escapeHtml(group.channel || 'Unknown');
        const resultTextEsc = escapeHtml(resultText);
        
        historyBetsHTML += `
          <div style="
            background: linear-gradient(135deg, ${isWin ? 'rgba(16, 24, 16, 0.8)' : 'rgba(24, 16, 16, 0.8)'}, rgba(30, 30, 46, 0.8));
            border-radius: 12px;
            padding: 14px;
            margin-bottom: 12px;
            font-size: 12px;
            border-left: 4px solid ${resultColor};
          ">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <div style="
                  width: 28px;
                  height: 28px;
                  background: ${optionColor};
                  border-radius: 6px;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: bold;
                  color: white;
                  font-size: 12px;
                ">
                  ${group.optionIndex + 1}
                </div>
                <div>
                  <div style="font-weight: 700; font-size: 12px; color: white;">${isWin ? 'WIN' : isRefunded ? 'REFUND' : 'LOSS'} #${index + 1}</div>
                  <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6);">${dateString} ${timeString}</div>
                </div>
              </div>
              <div style="text-align: right;">
                <div style="font-weight: 800; font-size: 16px; color: ${resultColor};">${resultTextEsc}</div>
                <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6);">${group.betCount} position${group.betCount !== 1 ? 's' : ''}</div>
              </div>
            </div>
            
            <div style="
              background: rgba(255, 255, 255, 0.05);
              border-radius: 8px;
              padding: 8px;
              margin-top: 8px;
            ">
              <div style="display: flex; justify-content: space-between; font-size: 11px;">
                <div style="color: rgba(255, 255, 255, 0.7);">Total staked:</div>
                <div style="color: white; font-weight: 600;">${escapeHtml(group.totalAmount.toFixed(2))} POL</div>
              </div>
              <div style="display: flex; justify-content: space-between; font-size: 11px; margin-top: 4px;">
                <div style="color: rgba(255, 255, 255, 0.7);">Channel:</div>
                <a href="${channelUrlEsc}" target="_blank" style="
                  color: #9146FF; 
                  font-weight: 600;
                  text-decoration: none;
                  cursor: pointer;
                  transition: all 0.2s;
                " onmouseover="this.style.opacity='0.8';" onmouseout="this.style.opacity='1';">
                  ${channelNameEsc}
                </a>
              </div>
            </div>
          </div>
        `;
      });
      
      // Добавляем статистику
      const totalWins = historyBets.filter(b => b.status === 'won').length;
      const totalLosses = historyBets.filter(b => b.status === 'lost').length;
      const totalRefunds = historyBets.filter(b => b.status === 'refunded').length;
      const winRate = totalWins + totalLosses > 0 ? Math.round((totalWins / (totalWins + totalLosses)) * 100) : 0;
      
      // Рассчитываем общий профит с учетом 10% комиссии
      const totalProfit = historyBets.reduce((sum, group) => {
        if (group.status === 'won') {
          // Профит при выигрыше ≈ 90% от ставки (при 50/50)
          return sum + (group.totalAmount * 0.9);
        } else if (group.status === 'lost') {
          return sum - group.totalAmount;
        } else if (group.status === 'refunded') {
          // При возврате снимается 10% комиссии
          return sum - (group.totalAmount * 0.1);
        }
        return sum;
      }, 0);
      
      historyBetsHTML = `
        <div style="
          background: linear-gradient(135deg, rgba(145, 70, 255, 0.1), rgba(106, 53, 255, 0.1));
          border-radius: 12px;
          padding: 12px;
          margin-bottom: 16px;
          border: 1px solid rgba(145, 70, 255, 0.2);
        ">
          <div style="display: flex; justify-content: space-around; text-align: center;">
            <div>
              <div style="font-size: 12px; color: rgba(255, 255, 255, 0.7);">Total Positions</div>
              <div style="font-size: 18px; font-weight: 700; color: white;">${historyBets.length}</div>
            </div>
            <div>
              <div style="font-size: 12px; color: rgba(255, 255, 255, 0.7);">Win Rate</div>
              <div style="font-size: 18px; font-weight: 700; color: #4CAF50;">${winRate}%</div>
            </div>
            <div>
              <div style="font-size: 12px; color: rgba(255, 255, 255, 0.7);">Total Profit</div>
              <div style="font-size: 18px; font-weight: 700; color: ${totalProfit >= 0 ? '#4CAF50' : '#FF4757'};">${totalProfit >= 0 ? '+' : ''}${totalProfit.toFixed(2)} POL</div>
            </div>
          </div>
        </div>
        <div style="max-height: 400px; overflow-y: auto; padding-right: 4px;">
          ${historyBetsHTML}
        </div>
      `;
    } else {
      historyBetsHTML = `
        <div style="
          text-align: center; 
          padding: 40px 20px; 
          color: rgba(255, 255, 255, 0.5); 
          font-size: 13px;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 12px;
          border: 2px dashed rgba(255, 255, 255, 0.1);
        ">
          <div style="font-size: 36px; margin-bottom: 16px; opacity: 0.5;">📊</div>
          <div style="font-weight: 600; margin-bottom: 8px; color: rgba(255, 255, 255, 0.7);">No History yet</div>
          <div style="font-size: 11px;">Complete some predictions to see your predictions history here</div>
        </div>
      `;
    }

    // Получаем список активных предиктов для вкладки "Browse"
    let allActivePredictionsHTML = '';
    if (this.currentTab === 'browse') {
      try {
        let activePredictionsData;
        let loadError = false;
        try {
          activePredictionsData = await this.getActivePredictionsList(0, 50);
          loadError = !!activePredictionsData?.error;
        } catch (e) {
          loadError = true;
          activePredictionsData = { predictions: [], totalCount: 0, error: true };
        }
        const allActivePredictions = activePredictionsData?.predictions || [];
        
        // Ошибка загрузки (сеть/таймаут) — показываем сообщение и кнопку "Повторить"
        if (loadError) {
          allActivePredictionsHTML = `
            <div style="
              text-align: center;
              padding: 40px 20px;
              color: rgba(255, 255, 255, 0.6);
              font-size: 13px;
              background: rgba(255, 255, 255, 0.05);
              border-radius: 12px;
              border: 2px dashed rgba(255, 255, 255, 0.1);
            ">
              <div style="font-size: 36px; margin-bottom: 16px; opacity: 0.5;">⚠️</div>
              <div style="font-weight: 600; margin-bottom: 8px; color: rgba(255, 255, 255, 0.8);">Error loading predictions</div>
              <div style="font-size: 11px; margin-bottom: 16px;">Check your network and RPC. Try again.</div>
              <button id="twitch-bets-browse-retry" type="button" style="
                padding: 10px 20px;
                background: rgba(145, 70, 255, 0.3);
                border: 1px solid rgba(145, 70, 255, 0.5);
                border-radius: 8px;
                color: #fff;
                font-weight: 600;
                cursor: pointer;
                font-size: 12px;
              ">Retry</button>
            </div>
          `;
        } else {
        
        // Status.OPEN = 0 - открыт, можно ставить POL
        // Status.ACTIVE = 1 - активен, ставить нельзя, решения о победителе еще нет
        // Status.RESOLVED = 2 - закрыт, победитель определен
        // Status.CANCELLED = 3 - отменен
        
        // Фильтруем предикты - показываем те, которые имеют статус OPEN (0) или ACTIVE (1)
        const TIMEOUT_DURATION = 24 * 60 * 60 + 5 * 60; // 24 часа 5 минут в секундах
        const nowSec = Math.floor(Date.now() / 1000);
        const filteredPredictions = allActivePredictions.filter(pred => {
          if (!pred) return false;
          // Преобразуем статус в число для надежного сравнения (обрабатываем BigInt и обычные числа)
          let status = pred.status;
          if (typeof status === 'bigint') {
            status = Number(status);
          } else if (typeof status === 'string') {
            status = parseInt(status, 10);
          } else {
            status = Number(status);
          }
          // Неизвестный/NaN считаем OPEN (0)
          if (isNaN(status) || status === undefined) status = 0;
          // Показываем только OPEN (0); ACTIVE (1), RESOLVED (2), CANCELLED (3) — скрываем
          if (status !== 0) {
            return false;
          }
          
          // Проверяем, не истек ли предикт (если startTime есть)
          if (pred.startTime) {
            let startTime = pred.startTime;
            if (typeof startTime === 'bigint') {
              startTime = Number(startTime);
            } else if (typeof startTime === 'string') {
              startTime = parseInt(startTime, 10);
            } else {
              startTime = Number(startTime);
            }
            
            if (!isNaN(startTime) && startTime > 0) {
              const age = nowSec - startTime;
              if (age > TIMEOUT_DURATION) return false;
            }
          }
          return true;
        });
        
        if (filteredPredictions.length > 0) {
          filteredPredictions.forEach((pred, idx) => {
            const channel = (pred && pred.channel != null) ? String(pred.channel) : 'unknown';
            const channelUrl = `https://www.twitch.tv/${channel}`;
            const channelUrlEsc = escapeHtml(channelUrl);
            const channelEsc = escapeHtml(channel);
            const statusText = escapeHtml(pred.status === 0 ? 'OPEN' : 'ACTIVE');
            const statusColor = pred.status === 0 ? '#4CAF50' : '#FF9800';
            const totalPool = Number(pred.totalPool) || 0;
            const option0Amount = Number(pred.option0Amount) || 0;
            const option1Amount = Number(pred.option1Amount) || 0;
            let percentage0Display = '0.0%';
            let percentage1Display = '0.0%';
            if (totalPool > 0) {
              percentage0Display = `${((option0Amount / totalPool) * 100).toFixed(1)}%`;
              percentage1Display = `${((option1Amount / totalPool) * 100).toFixed(1)}%`;
            }
            percentage0Display = escapeHtml(percentage0Display);
            percentage1Display = escapeHtml(percentage1Display);
            const totalPoolEsc = escapeHtml(totalPool.toFixed(2));
            const option0Esc = escapeHtml(option0Amount.toFixed(2));
            const option1Esc = escapeHtml(option1Amount.toFixed(2));
            
            allActivePredictionsHTML += `
              <div style="
                background: linear-gradient(135deg, rgba(16, 16, 24, 0.8), rgba(30, 30, 46, 0.8));
                border-radius: 12px;
                padding: 14px;
                margin-bottom: 12px;
                font-size: 12px;
                border: 1px solid rgba(145, 70, 255, 0.2);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
              ">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                  <a href="${channelUrlEsc}" target="_blank" style="
                    color: #9146FF;
                    font-weight: 700;
                    font-size: 13px;
                    text-decoration: none;
                    transition: all 0.2s;
                  " onmouseover="this.style.opacity='0.8';" onmouseout="this.style.opacity='1';">
                    ${channelEsc}
                  </a>
                  <div style="
                    padding: 4px 8px;
                    background: rgba(0, 0, 0, 0.3);
                    border-radius: 8px;
                    font-size: 9px;
                    color: ${statusColor};
                    font-weight: 600;
                    border: 1px solid ${statusColor}40;
                  ">
                    ${statusText}
                  </div>
                </div>
                
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; padding: 6px 0; border-top: 1px solid rgba(255, 255, 255, 0.1); border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
                  <div style="flex: 1;">
                    <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6); margin-bottom: 2px;">Option 1</div>
                    <div style="font-weight: 700; font-size: 12px; color: #FF6B6B;">${option0Esc} POL</div>
                    <div style="font-size: 9px; color: #4CAF50; margin-top: 2px;">${percentage0Display}</div>
                  </div>
                  <div style="flex: 1; text-align: right;">
                    <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6); margin-bottom: 2px;">Option 2</div>
                    <div style="font-weight: 700; font-size: 12px; color: #4D96FF;">${option1Esc} POL</div>
                    <div style="font-size: 9px; color: #4CAF50; margin-top: 2px;">${percentage1Display}</div>
                  </div>
                </div>
                
                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px;">
                  <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6);">
                    Total Pool: <span style="color: #FFD700; font-weight: 600;">${totalPoolEsc} POL</span>
                  </div>
                  <a href="${channelUrlEsc}" target="_blank" style="
                    padding: 6px 12px;
                    background: rgba(145, 70, 255, 0.15);
                    border: 1px solid rgba(145, 70, 255, 0.3);
                    border-radius: 8px;
                    color: #9146FF;
                    font-weight: 600;
                    font-size: 10px;
                    text-decoration: none;
                    transition: all 0.2s;
                  " onmouseover="this.style.opacity='0.8'; this.style.transform='translateY(-1px)';" 
                     onmouseout="this.style.opacity='1'; this.style.transform='translateY(0)';">
                    Go to Channel →
                  </a>
                </div>
              </div>
            `;
          });
          
          // Контейнер с overflow уже добавлен в mainContent, поэтому здесь просто оставляем HTML
          // allActivePredictionsHTML уже содержит нужный контент
        } else {
          allActivePredictionsHTML = `
            <div style="
              text-align: center; 
              padding: 40px 20px; 
              color: rgba(255, 255, 255, 0.5); 
              font-size: 13px;
              background: rgba(255, 255, 255, 0.05);
              border-radius: 12px;
              border: 2px dashed rgba(255, 255, 255, 0.1);
            ">
              <div style="font-size: 36px; margin-bottom: 16px; opacity: 0.5;">🔍</div>
              <div style="font-weight: 600; margin-bottom: 8px; color: rgba(255, 255, 255, 0.7);">No active predictions</div>
              <div style="font-size: 11px;">There are no active predictions on any channel right now</div>
            </div>
          `;
        }
        } // конец else (не loadError)
      } catch (error) {
        allActivePredictionsHTML = `
          <div style="
            text-align: center;
            padding: 40px 20px;
            color: rgba(255, 255, 255, 0.6);
            font-size: 13px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            border: 2px dashed rgba(255, 255, 255, 0.1);
          ">
            <div style="font-size: 36px; margin-bottom: 16px; opacity: 0.5;">⚠️</div>
            <div style="font-weight: 600; margin-bottom: 8px; color: rgba(255, 255, 255, 0.8);">Error loading predictions</div>
            <div style="font-size: 11px; margin-bottom: 16px;">Check your network and try again.</div>
            <button id="twitch-bets-browse-retry" type="button" style="
              padding: 10px 20px;
              background: rgba(145, 70, 255, 0.3);
              border: 1px solid rgba(145, 70, 255, 0.5);
              border-radius: 8px;
              color: #fff;
              font-weight: 600;
              cursor: pointer;
              font-size: 12px;
            ">Retry</button>
          </div>
        `;
      }
    }

    // Основной контент в зависимости от текущей вкладки
    let mainContent = '';
    
    if (this.currentTab === 'main') {
      mainContent = `
        <div style="margin-top: 24px; padding-top: 20px; border-top: 1px solid rgba(255, 255, 255, 0.1);">
          <div style="
            display: flex;
            flex-direction: column;
            gap: 12px;
            align-items: center;
          ">
            <button id="twitch-bets-show-active" style="
              width: 100%;
              padding: 16px;
              background: rgba(145, 70, 255, 0.15);
              border: 1px solid rgba(145, 70, 255, 0.4);
              border-radius: 12px;
              color: white;
              font-weight: 700;
              cursor: pointer;
              font-size: 14px;
              transition: all 0.2s;
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 10px;
              position: relative;
              z-index: 10000001;
              pointer-events: auto;
            ">
              <span style="font-size: 18px;">🎯</span>
              <span>My Predictions ${groupedBets.length > 0 ? `(${groupedBets.length})` : ''}</span>
            </button>
            
            <button id="twitch-bets-show-browse" style="
              width: 100%;
              padding: 16px;
              background: rgba(145, 70, 255, 0.15);
              border: 1px solid rgba(145, 70, 255, 0.4);
              border-radius: 12px;
              color: white;
              font-weight: 700;
              cursor: pointer;
              font-size: 14px;
              transition: all 0.2s;
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 10px;
              position: relative;
              z-index: 10000001;
              pointer-events: auto;
            ">
              <span style="font-size: 18px;">🔍</span>
              <span>Browse Predictions</span>
            </button>
            
            <button id="twitch-bets-show-history" style="
              width: 100%;
              padding: 16px;
              background: rgba(145, 70, 255, 0.15);
              border: 1px solid rgba(145, 70, 255, 0.4);
              border-radius: 12px;
              color: white;
              font-weight: 700;
              cursor: pointer;
              font-size: 14px;
              transition: all 0.2s;
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 10px;
              position: relative;
              z-index: 10000001;
              pointer-events: auto;
            ">
              <span style="font-size: 18px;">📊</span>
              <span>My History ${historyBets.length > 0 ? `(${historyBets.length})` : ''}</span>
            </button>
          </div>
        </div>
      `;
    } else if (this.currentTab === 'active') {
      mainContent = `
        <div style="margin-top: 24px; padding-top: 20px; border-top: 1px solid rgba(255, 255, 255, 0.1); display: flex; flex-direction: column; height: 100%; min-height: 0;">
          <div style="display: flex; align-items: center; margin-bottom: 20px; flex-shrink: 0;">
            <button id="twitch-bets-back" style="
              background: rgba(255, 255, 255, 0.1);
              border: 1px solid rgba(255, 255, 255, 0.2);
              border-radius: 8px;
              color: white;
              cursor: pointer;
              font-size: 16px;
              padding: 0;
              width: 32px;
              height: 32px;
              display: flex;
              align-items: center;
              justify-content: center;
              transition: all 0.2s;
              margin-right: 12px;
              position: relative;
              z-index: 10000001;
              pointer-events: auto;
            ">←</button>
            <div style="display: flex; align-items: center; justify-content: space-between; width: 100%; gap: 12px;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: white;">My Predictions</h3>
              <button id="twitch-bets-claim-all" style="
                padding: 8px 12px;
                background: rgba(145, 70, 255, 0.18);
                border: 1px solid rgba(145, 70, 255, 0.55);
                border-radius: 10px;
                color: white;
                font-weight: 800;
                cursor: ${this.isConnected ? 'pointer' : 'not-allowed'};
                font-size: 11px;
                transition: all 0.2s;
                opacity: ${this.isConnected ? '1' : '0.5'};
                white-space: nowrap;
              " ${!this.isConnected ? 'disabled' : ''}>Claim All</button>
            </div>
          </div>
          <div style="flex: 1; min-height: 0; overflow-y: auto; overflow-x: hidden; padding-right: 4px;">
            ${activeBetsHTML}
          </div>
        </div>
      `;
    } else if (this.currentTab === 'browse') {
      mainContent = `
        <div style="
          margin-top: 24px; 
          padding-top: 20px; 
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          flex-direction: column;
          height: 100%;
          max-height: 400px !important;
          min-height: 0;
          overflow: hidden !important;
          width: 100%;
          max-width: 100%;
          box-sizing: border-box;
        ">
          <div style="
            display: flex; 
            align-items: center; 
            margin-bottom: 16px;
            flex-shrink: 0;
          ">
            <button id="twitch-bets-back" style="
              background: rgba(255, 255, 255, 0.1);
              border: 1px solid rgba(255, 255, 255, 0.2);
              border-radius: 8px;
              color: white;
              cursor: pointer;
              font-size: 16px;
              padding: 0;
              width: 32px;
              height: 32px;
              display: flex;
              align-items: center;
              justify-content: center;
              transition: all 0.2s;
              margin-right: 12px;
              position: relative;
              z-index: 10000001;
              pointer-events: auto;
            ">←</button>
            <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: white;">Browse Predictions</h3>
          </div>
          <div style="
            flex: 1;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            padding-right: 4px;
            min-height: 0 !important;
            max-height: 100% !important;
            width: 100% !important;
            max-width: 100% !important;
            box-sizing: border-box !important;
          ">
            ${allActivePredictionsHTML}
          </div>
        </div>
      `;
    } else if (this.currentTab === 'history') {
      mainContent = `
        <div style="margin-top: 24px; padding-top: 20px; border-top: 1px solid rgba(255, 255, 255, 0.1); display: flex; flex-direction: column; height: 100%; min-height: 0;">
          <div style="display: flex; align-items: center; margin-bottom: 20px; flex-shrink: 0;">
            <button id="twitch-bets-back" style="
              background: rgba(255, 255, 255, 0.1);
              border: 1px solid rgba(255, 255, 255, 0.2);
              border-radius: 8px;
              color: white;
              cursor: pointer;
              font-size: 16px;
              padding: 0;
              width: 32px;
              height: 32px;
              display: flex;
              align-items: center;
              justify-content: center;
              transition: all 0.2s;
              margin-right: 12px;
              position: relative;
              z-index: 10000001;
              pointer-events: auto;
            ">←</button>
            <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: white;">My History</h3>
          </div>
          <div style="flex: 1; min-height: 0; overflow-y: auto; overflow-x: hidden; padding-right: 4px;">
            ${historyBetsHTML}
          </div>
        </div>
      `;
    }

    const bettingUI = document.createElement('div');
    bettingUI.id = 'twitch-bets-ui';
    bettingUI.style.cssText = `
      position: fixed !important;
      top: 50% !important;
      right: 5px !important;
      transform: translateY(-50%) !important;
      z-index: 10000000 !important;
      max-height: 85vh !important;
      max-width: 360px !important;
      width: auto !important;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    `;
    bettingUI.innerHTML = `
      <div style="
        background: linear-gradient(180deg, #1a1a2a, #0f0f1a);
        border: 2px solid rgba(145, 70, 255, 0.3);
        border-radius: 16px;
        padding: 20px;
        color: white;
        width: 320px !important;
        min-width: 320px !important;
        max-width: 320px !important;
        max-height: 85vh !important;
        box-shadow: 0 12px 40px rgba(145, 70, 255, 0.25);
        backdrop-filter: blur(10px);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-sizing: border-box;
      ">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="
              width: 36px;
              height: 36px;
              background: linear-gradient(135deg, #9146FF, #6A35FF);
              border-radius: 10px;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 18px;
              box-shadow: 0 4px 12px rgba(145, 70, 255, 0.4);
            ">
              🎯
            </div>
            <div>
              <h3 style="margin: 0; font-size: 16px; font-weight: 700; background: linear-gradient(135deg, #9146FF, #6A35FF); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Stream Market</h3>
              <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6);">Web3 Predictions</div>
            </div>
          </div>
          <button id="twitch-bets-close" style="
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: white;
            cursor: pointer;
            font-size: 18px;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
          ">×</button>
        </div>

        <div style="
          background: linear-gradient(135deg, rgba(145, 70, 255, 0.15), rgba(106, 53, 255, 0.1));
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 20px;
          border: 1px solid rgba(145, 70, 255, 0.2);
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
        ">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <div style="font-size: 12px; color: rgba(255, 255, 255, 0.8); margin-bottom: 4px;">Your Balance</div>
            <div style="
              padding: 4px 8px;
              background: rgba(0, 0, 0, 0.3);
              border-radius: 20px;
              font-size: 9px;
              color: ${this.chainId === this.config.POLYGON_CHAIN_ID ? '#4CAF50' : '#FF9800'};
              font-weight: 600;
              border: 1px solid ${this.chainId === this.config.POLYGON_CHAIN_ID ? 'rgba(76, 175, 80, 0.3)' : 'rgba(255, 152, 0, 0.3)'};
            ">
              ${networkStatus}
            </div>
          </div>
          <div style="font-size: 24px; font-weight: 800; color: white; margin-bottom: 4px;">${polDisplay} POL</div>
          <div id="pol-usdt-conversion" style="font-size: 12px; color: rgba(255, 255, 255, 0.7); margin-top: 4px; min-height: 16px;">
            <span id="usdt-value">—</span>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="font-size: 10px; color: rgba(255, 255, 255, 0.6); font-style: italic;">
              ${this.isConnected ? `Connected: ${walletDisplay}` : 'Wallet not connected'}
            </div>
          </div>
        </div>

        <div style="flex: 1; min-height: 0; max-height: 100%; overflow: hidden; display: flex; flex-direction: column; width: 100%; max-width: 100%; box-sizing: border-box;">
          ${mainContent}
        </div>

        <div style="margin-top: 24px; display: flex; gap: 12px; flex-shrink: 0;">
          <button id="twitch-bets-connect-btn" style="
            flex: 2;
            padding: 12px;
            background: ${this.isConnected ? 'linear-gradient(135deg, #FF4757, #FF6B6B)' : 'linear-gradient(135deg, #9146FF, #6A35FF)'};
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 6px 20px ${this.isConnected ? 'rgba(244, 67, 54, 0.3)' : 'rgba(145, 70, 255, 0.3)'};
          ">
            <span>${this.isConnected ? '🔌' : '🦊'}</span>
            <span>${this.isConnected ? 'Disconnect' : 'Connect MetaMask'}</span>
          </button>

          <button id="twitch-bets-deposit-btn" style="
            flex: 1;
            padding: 12px;
            background: rgba(145, 70, 255, 0.15);
            color: white;
            border: 1px solid rgba(145, 70, 255, 0.4);
            border-radius: 10px;
            font-weight: 700;
            cursor: ${this.isConnected ? 'pointer' : 'not-allowed'};
            font-size: 12px;
            transition: all 0.2s;
            opacity: ${this.isConnected ? '1' : '0.5'};
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
          " ${!this.isConnected ? 'disabled' : ''}>
            <span>💎</span>
            <span>Deposit</span>
          </button>
        </div>
      </div>
    `;

    return bettingUI;
  }

  async showBettingUI() {
    const oldUI = document.getElementById('twitch-bets-ui');
    if (oldUI) oldUI.remove();

    this.bettingUI = await this.createBettingUI();
    
    // ВАЖНО: Применяем стили и принудительно применяем их ДО добавления в DOM
    // Это предотвращает мигание при первом открытии
    this.bettingUI.style.cssText = `
      position: fixed !important;
      top: 50% !important;
      right: 5px !important;
      transform: translateY(-50%) !important;
      z-index: 10000000 !important;
      max-height: 85vh !important;
      max-width: 360px !important;
      width: 360px !important;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    `;
    
    // Добавляем в DOM (пока скрыт)
    document.body.appendChild(this.bettingUI);
    
    // Принудительно применяем стили через пересчет layout
    void this.bettingUI.offsetHeight;
    
    // Фиксируем размеры внутреннего контейнера
    requestAnimationFrame(() => {
      const innerContainer = this.bettingUI.querySelector('div[style*="background: linear-gradient(180deg"]');
      if (innerContainer) {
        innerContainer.style.width = '320px';
        innerContainer.style.minWidth = '320px';
        innerContainer.style.maxWidth = '320px';
      }
      
      // Показываем элемент
      this.bettingUI.style.opacity = '1';
      this.bettingUI.style.pointerEvents = 'auto';
    });
    
    this.setupUIEventListeners();
    // Обновляем конвертацию USDT один раз при открытии
    await this.updateUsdtConversion();
    // Обновляем каждые 10 минут (вместо 30 секунд), чтобы не делать слишком много запросов к API
    if (this._usdtUpdateInterval) clearInterval(this._usdtUpdateInterval);
    this._usdtUpdateInterval = setInterval(() => this.updateUsdtConversion(), 10 * 60 * 1000); // 10 минут
  }

  setupUIEventListeners() {
    if (!this.bettingUI) return;
    
    // Удаляем старые обработчики если они есть (чтобы избежать дублирования)
    const oldHandler = this._bettingUIClickHandler;
    if (oldHandler) {
      this.bettingUI.removeEventListener('click', oldHandler);
    }
    
    // Используем делегирование событий на уровне bettingUI для надежности
    // Это работает даже если кнопки пересоздаются
    this._bettingUIClickHandler = (e) => {
      // Обработка кнопок навигации
      const navTarget = e.target.closest('#twitch-bets-show-active, #twitch-bets-show-browse, #twitch-bets-show-history, #twitch-bets-back');
      if (navTarget) {
        e.preventDefault();
        e.stopPropagation();
        
        if (navTarget.id === 'twitch-bets-show-active') {
          this.currentTab = 'active';
          this.safeUpdateUI();
        } else if (navTarget.id === 'twitch-bets-show-browse') {
          // Просто переключаем вкладку - safeUpdateUI сам зафиксирует размеры
          this.currentTab = 'browse';
          this.safeUpdateUI();
        } else if (navTarget.id === 'twitch-bets-show-history') {
          this.currentTab = 'history';
          this.safeUpdateUI();
        } else if (navTarget.id === 'twitch-bets-back') {
          this.currentTab = 'main';
          this.safeUpdateUI();
        }
        return;
      }
    };
    
    this.bettingUI.addEventListener('click', this._bettingUIClickHandler);
    
    setTimeout(() => {
      const closeBtn = this.bettingUI.querySelector('#twitch-bets-close');
      if (closeBtn) {
        closeBtn.onclick = () => {
          if (this.bettingUI) {
            this.bettingUI.remove();
            this.bettingUI = null;
            this.currentTab = 'main'; // Сбрасываем на главную вкладку
          }
        };
      }

      const browseRetryBtn = this.bettingUI.querySelector('#twitch-bets-browse-retry');
      if (browseRetryBtn) {
        browseRetryBtn.onclick = () => this.safeUpdateUI();
      }

      const connectBtn = this.bettingUI.querySelector('#twitch-bets-connect-btn');
      if (connectBtn) {
        connectBtn.onclick = async () => {
          if (this.isConnected) {
            await this.disconnectWallet();
          } else {
            await this.connectMetaMask();
          }
        };
      }

      const depositBtn = this.bettingUI.querySelector('#twitch-bets-deposit-btn');
      if (depositBtn) {
        depositBtn.onclick = () => {
          if (this.isConnected) {
            this.showDepositModal();
          }
        };
      }
      
      // Обработчик для кнопки "назад" уже установлен через делегирование выше

      // Claim кнопки в Active Bets
      const claimAllBtn = this.bettingUI.querySelector('#twitch-bets-claim-all');
      if (claimAllBtn) {
        claimAllBtn.replaceWith(claimAllBtn.cloneNode(true));
        const newClaimAllBtn = this.bettingUI.querySelector('#twitch-bets-claim-all');
        newClaimAllBtn.addEventListener('click', async (e) => {
          e.preventDefault();
          e.stopPropagation();
          
          if (!this.isConnected) {
            this.showNotification('Please connect MetaMask first', 'error');
            return;
          }
          
          const originalText = newClaimAllBtn.textContent;
          newClaimAllBtn.textContent = '⏳';
          newClaimAllBtn.disabled = true;
          newClaimAllBtn.style.opacity = '0.6';
          
          try {
            const res = await this.claimPayout(null);
            if (res && res.success) {
              this.showNotification('✅ Claim All sent', 'success');
              await this.updateWalletBalance();
              
              const ids = new Set();
              for (const bet of this.userBets || []) {
                if (bet?.contractId && (bet.status === 'pending' || bet.status === 'active')) {
                  ids.add(bet.contractId);
                }
              }
              for (const id of ids) {
                await this.syncLocalBetStatusFromContract(id);
              }
              // В History попадают только ставки, чей предикт на контракте RESOLVED/CANCELLED (sync обновляет статус по контракту).
              // Ставки с предиктом ещё OPEN/ACTIVE остаются в My Predictions.
              await this.saveUserBets();
              this.currentTab = 'history';
              this.safeUpdateUI();
              
              try {
                const feesRes = await this.withdrawFees();
                if (feesRes && feesRes.success) {
                  this.showNotification('✅ Fees also withdrawn!', 'success');
                  await this.updateWalletBalance();
                }
              } catch (feesErr) {
              }
            } else {
              this.showNotification(`Claim All failed: ${res?.error || 'Unknown error'}`, 'error');
            }
          } catch (err) {
            this.showNotification(`Claim All failed: ${err?.message || err}`, 'error');
          } finally {
            newClaimAllBtn.textContent = originalText;
            newClaimAllBtn.disabled = false;
            newClaimAllBtn.style.opacity = '1';
          }
        });
      }
      
      if (this.currentTab === 'active') {
        
        const claimButtons = this.bettingUI.querySelectorAll('.twitch-bets-claim-btn');
        claimButtons.forEach((btn) => {
          // Удаляем старые обработчики
          const newBtn = btn.cloneNode(true);
          btn.replaceWith(newBtn);
          
          newBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            const contractId = newBtn.getAttribute('data-contract-id');
            if (!contractId) return;
            
            if (!this.isConnected) {
              this.showNotification('Please connect MetaMask first', 'error');
              return;
            }
            
            const originalText = newBtn.textContent;
            newBtn.textContent = '⏳';
            newBtn.disabled = true;
            newBtn.style.opacity = '0.6';
            
            try {
              const res = await this.claimPayout(contractId);
              if (res && res.success) {
                this.showNotification('✅ Claim sent', 'success');
                await this.updateWalletBalance();
                await this.syncLocalBetStatusFromContract(contractId);
              } else {
                this.showNotification(`Claim failed: ${res?.error || 'Unknown error'}`, 'error');
              }
            } catch (err) {
              this.showNotification(`Claim failed: ${err?.message || err}`, 'error');
            } finally {
              newBtn.textContent = originalText;
              newBtn.disabled = false;
              newBtn.style.opacity = '1';
            }
          });
        });
      }
    }, 100);
  }

  showDepositModal() {
    if (!this.walletAddress) {
      this.showNotification('Please connect MetaMask first', 'error');
      return;
    }
    
    const existingModal = document.getElementById('twitch-bets-deposit-modal');
    if (existingModal) {
      existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.id = 'twitch-bets-deposit-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.8);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000001;
      backdrop-filter: blur(5px);
    `;
    modal.innerHTML = `
      <div style="
        background: linear-gradient(180deg, #1a1a2a, #0f0f1a);
        border: 2px solid rgba(145, 70, 255, 0.5);
        border-radius: 20px;
        padding: 28px;
        max-width: 420px;
        width: 90%;
        color: white;
        font-family: 'Inter', sans-serif;
        box-shadow: 0 20px 60px rgba(145, 70, 255, 0.3);
      ">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
          <h3 style="margin: 0; font-size: 20px; font-weight: 700; background: linear-gradient(135deg, #9146FF, #6A35FF); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Get POL</h3>
          <button id="twitch-bets-modal-close" style="
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: white;
            cursor: pointer;
            font-size: 20px;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
          ">×</button>
        </div>
        
        <div style="
          background: linear-gradient(135deg, rgba(145, 70, 255, 0.15), rgba(106, 53, 255, 0.1));
          border-radius: 16px;
          padding: 20px;
          margin-bottom: 24px;
          border: 1px solid rgba(145, 70, 255, 0.2);
        ">
          <div style="font-size: 13px; color: rgba(255, 255, 255, 0.8); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 16px;">💼</span>
            <span>Your POL Wallet Address:</span>
          </div>
          <div style="
            background: rgba(0, 0, 0, 0.4);
            border-radius: 12px;
            padding: 12px;
            margin-bottom: 16px;
            border: 1px solid rgba(145, 70, 255, 0.3);
            display: flex;
            align-items: center;
            gap: 8px;
          ">
            <div style="
              flex: 1;
              font-family: 'Courier New', monospace;
              font-size: 12px;
              color: rgba(255, 255, 255, 0.9);
              word-break: break-all;
              padding-right: 8px;
            " id="wallet-address-display"></div>
            <button id="copy-wallet-address" style="
              padding: 8px 12px;
              background: rgba(145, 70, 255, 0.2);
              border: 1px solid rgba(145, 70, 255, 0.4);
              border-radius: 8px;
              color: #9146FF;
              font-weight: 600;
              font-size: 11px;
              cursor: pointer;
              white-space: nowrap;
              transition: all 0.2s;
            " onmouseover="this.style.background='rgba(145, 70, 255, 0.3)';" onmouseout="this.style.background='rgba(145, 70, 255, 0.2)';">
              📋 Copy
            </button>
          </div>
          
          <div style="font-size: 13px; color: rgba(255, 255, 255, 0.8); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 16px;">📥</span>
            <span>Get POL for Polygon:</span>
          </div>
          
          <div style="
            background: rgba(0, 0, 0, 0.4);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 16px;
            border: 1px solid rgba(145, 70, 255, 0.3);
          ">
            <div style="font-size: 12px; color: rgba(255, 255, 255, 0.7); margin-bottom: 12px; font-weight: 600;">
              Exchanges:
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px;">
              <a href="https://www.binance.com/en/trade/POL_USDT" target="_blank" style="
                flex: 1;
                min-width: 100px;
                padding: 10px 12px;
                background: rgba(245, 158, 11, 0.2);
                color: #F59E0B;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(245, 158, 11, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(245, 158, 11, 0.3)';" onmouseout="this.style.background='rgba(245, 158, 11, 0.2)';">
                Binance
              </a>
              <a href="https://www.bybit.com/trade/usdt/POLUSDT" target="_blank" style="
                flex: 1;
                min-width: 100px;
                padding: 10px 12px;
                background: rgba(245, 158, 11, 0.2);
                color: #F59E0B;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(245, 158, 11, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(245, 158, 11, 0.3)';" onmouseout="this.style.background='rgba(245, 158, 11, 0.2)';">
                Bybit
              </a>
              <a href="https://www.coinbase.com/price/polygon" target="_blank" style="
                flex: 1;
                min-width: 100px;
                padding: 10px 12px;
                background: rgba(245, 158, 11, 0.2);
                color: #F59E0B;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(245, 158, 11, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(245, 158, 11, 0.3)';" onmouseout="this.style.background='rgba(245, 158, 11, 0.2)';">
                Coinbase
              </a>
            </div>
            
            <div style="font-size: 12px; color: rgba(255, 255, 255, 0.7); margin-bottom: 12px; margin-top: 16px; font-weight: 600;">
              P2P Exchanges:
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px;">
              <a href="https://www.huobi.com/en-us/p2p" target="_blank" style="
                flex: 1;
                min-width: 100px;
                padding: 10px 12px;
                background: rgba(76, 175, 80, 0.2);
                color: #4CAF50;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(76, 175, 80, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(76, 175, 80, 0.3)';" onmouseout="this.style.background='rgba(76, 175, 80, 0.2)';">
                Huobi P2P
              </a>
              <a href="https://www.okx.com/ru/p2p-market" target="_blank" style="
                flex: 1;
                min-width: 100px;
                padding: 10px 12px;
                background: rgba(76, 175, 80, 0.2);
                color: #4CAF50;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(76, 175, 80, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(76, 175, 80, 0.3)';" onmouseout="this.style.background='rgba(76, 175, 80, 0.2)';">
                OKX P2P
              </a>
              <a href="https://www.gate.io/p2p" target="_blank" style="
                flex: 1;
                min-width: 100px;
                padding: 10px 12px;
                background: rgba(76, 175, 80, 0.2);
                color: #4CAF50;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(76, 175, 80, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(76, 175, 80, 0.3)';" onmouseout="this.style.background='rgba(76, 175, 80, 0.2)';">
                Gate.io P2P (RUB)
              </a>
            </div>
            
            <div style="font-size: 12px; color: rgba(255, 255, 255, 0.7); margin-bottom: 12px; margin-top: 16px; font-weight: 600;">
              Telegram Bots:
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 8px;">
              <a href="https://t.me/CryptoBot" target="_blank" style="
                flex: 1;
                min-width: 120px;
                padding: 10px 12px;
                background: rgba(0, 136, 204, 0.2);
                color: #0088CC;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(0, 136, 204, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(0, 136, 204, 0.3)';" onmouseout="this.style.background='rgba(0, 136, 204, 0.2)';">
                @CryptoBot
              </a>
              <a href="https://t.me/wallet" target="_blank" style="
                flex: 1;
                min-width: 120px;
                padding: 10px 12px;
                background: rgba(0, 136, 204, 0.2);
                color: #0088CC;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                font-size: 11px;
                text-align: center;
                border: 1px solid rgba(0, 136, 204, 0.3);
                transition: all 0.2s;
              " onmouseover="this.style.background='rgba(0, 136, 204, 0.3)';" onmouseout="this.style.background='rgba(0, 136, 204, 0.2)';">
                @wallet
              </a>
            </div>
          </div>
          
          <div style="
            margin-top: 16px;
            padding: 12px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            font-size: 11px;
            color: rgba(255, 255, 255, 0.6);
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
          ">
            <div style="display: flex; align-items: center; justify-content: center; gap: 6px; margin-bottom: 4px;">
              <span style="font-size: 12px;">⚠️</span>
              <span style="font-weight: 600;">Important</span>
            </div>
            Make sure your MetaMask is connected to Polygon network
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    const walletDisplayEl = modal.querySelector('#wallet-address-display');
    if (walletDisplayEl) walletDisplayEl.textContent = this.walletAddress || 'Not connected';

    const closeBtn = modal.querySelector('#twitch-bets-modal-close');
    if (closeBtn) {
      closeBtn.onclick = () => {
        modal.remove();
      };
    }
    
    // Обработчик кнопки копирования адреса
    const copyBtn = modal.querySelector('#copy-wallet-address');
    if (copyBtn) {
      copyBtn.onclick = async () => {
        try {
          await navigator.clipboard.writeText(this.walletAddress);
          const originalText = copyBtn.textContent;
          copyBtn.textContent = '✅ Copied!';
          copyBtn.style.background = 'rgba(76, 175, 80, 0.3)';
          copyBtn.style.borderColor = 'rgba(76, 175, 80, 0.5)';
          copyBtn.style.color = '#4CAF50';
          setTimeout(() => {
            copyBtn.textContent = originalText;
            copyBtn.style.background = 'rgba(145, 70, 255, 0.2)';
            copyBtn.style.borderColor = 'rgba(145, 70, 255, 0.4)';
            copyBtn.style.color = '#9146FF';
          }, 2000);
        } catch (error) {
          // Fallback для старых браузеров
          const textArea = document.createElement('textarea');
          textArea.value = this.walletAddress;
          textArea.style.position = 'fixed';
          textArea.style.opacity = '0';
          document.body.appendChild(textArea);
          textArea.select();
          try {
            document.execCommand('copy');
            const originalText = copyBtn.textContent;
            copyBtn.textContent = '✅ Copied!';
            setTimeout(() => {
              copyBtn.textContent = originalText;
            }, 2000);
          } catch (err) {
            this.showNotification('Failed to copy address', 'error');
          }
          document.body.removeChild(textArea);
        }
      };
    }
    
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.remove();
      }
    });
  }

  showNotification(message, type = 'info') {
    const existingNotification = document.querySelector('.twitch-bets-notification');
    if (existingNotification) {
      existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = 'twitch-bets-notification';

    const bgColor = {
      success: 'linear-gradient(135deg, #4CAF50, #388E3C)',
      error: 'linear-gradient(135deg, #FF4757, #FF6B6B)',
      warning: 'linear-gradient(135deg, #FF9800, #F57C00)',
      info: 'linear-gradient(135deg, #2196F3, #1976D2)'
    }[type] || 'linear-gradient(135deg, #2196F3, #1976D2)';

    notification.style.cssText = `
      position: fixed;
      top: 24px;
      right: 24px;
      background: ${bgColor};
      color: white;
      padding: 14px 20px;
      border-radius: 12px;
      max-width: 320px;
      z-index: 10000002;
      animation: slideInRight 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      font-size: 14px;
      font-weight: 600;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
    `;

    // Добавляем иконку в зависимости от типа
    const icon = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    }[type] || 'ℹ️';

    const messageEsc = escapeHtml(message);
    notification.innerHTML = `
      <div style="display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 18px;">${icon}</span>
        <span>${messageEsc}</span>
      </div>
    `;
    
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.animation = 'slideOutRight 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards';
      setTimeout(() => notification.remove(), 300);
    }, 4000);
  }

  handleRuntimeMessage(request, sender, sendResponse) {
    if (request.action === 'showBettingUI') {
      this.showBettingUI();
      sendResponse({ success: true });
    } else if (request.action === 'openDepositModal') {
      this.showDepositModal();
      sendResponse({ success: true });
    } else if (request.action === 'toggleWalletConnection') {
      if (this.isConnected) {
        this.disconnectWallet().then(result => {
          sendResponse({ success: true, connected: false });
        });
      } else {
        this.connectMetaMask().then(result => {
          sendResponse({ success: result.success, connected: result.success });
        });
      }
      return true;
    } else if (request.action === 'getUserBets') {
      sendResponse({ success: true, userBets: this.userBets });
      return true;
    } else if (request.action === 'saveUserBets') {
      this.userBets = request.bets || [];
      chrome.storage.local.set({ userBets: this.userBets }, () => {
        sendResponse({ success: true });
      });
      return true;
    }
  }
}

let extension = null;

function initializeExtension() {
  if (!extension) {
    extension = new TwitchBetsExtension();
    
    window.TwitchBetsExtension = {
      connectMetaMask: async function() {
        return await extension.connectMetaMask();
      },
      disconnectWallet: async function() {
        return await extension.disconnectWallet();
      },
      updateWalletBalance: async function() {
        return await extension.updateWalletBalance();
      },
      getWalletAddress: function() {
        return extension.walletAddress;
      },
      getWalletBalance: function() {
        return extension.userBalance.pol;
      },
      isConnected: function() {
        return extension.isConnected;
      },
      showBettingUI: function() {
        return extension.showBettingUI();
      },
      showNotification: function(message, type) {
        return extension.showNotification(message, type);
      },
      getUserBets: function() {
        return extension.userBets;
      },
      placeBetOnContractReal: async function(channel, question, options, optionIndex, amount) {
        return await extension.placeBetOnContractReal(channel, question, options, optionIndex, amount);
      },
      showDepositModal: function() {
        return extension.showDepositModal();
      }
    };
    
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeExtension);
} else {
  initializeExtension();
}

setTimeout(initializeExtension, 100);