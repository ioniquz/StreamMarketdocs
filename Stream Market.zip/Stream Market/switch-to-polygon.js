// switch-to-polygon.js - Utility for switching to Polygon network

class PolygonSwitcher {
    constructor() {
        this.POLYGON_CHAIN_ID = '0x89'; // Polygon
        this.init();
    }

    init() {
    }

    async switchToPolygon() {
        try {
            if (typeof window.ethereum === 'undefined') {
                throw new Error('MetaMask not installed');
            }

            try {
                // First try to switch to Polygon
                await window.ethereum.request({
                    method: 'wallet_switchEthereumChain',
                    params: [{ chainId: this.POLYGON_CHAIN_ID }]
                });
                
                return { success: true };
                
            } catch (switchError) {
                
                // If network not added, add it
                if (switchError.code === 4902) {
                    try {
                        await window.ethereum.request({
                            method: 'wallet_addEthereumChain',
                            params: [{
                                chainId: this.POLYGON_CHAIN_ID,
                                chainName: 'Polygon',
                                nativeCurrency: {
                                    name: 'POL',
                                    symbol: 'POL',
                                    decimals: 18
                                },
                                rpcUrls: ['https://polygon-rpc.com'],
                                blockExplorerUrls: ['https://polygonscan.com']
                            }]
                        });
                        
                        return { success: true };
                        
                    } catch (addError) {
                        return { 
                            success: false, 
                            error: 'Failed to add Polygon network: ' + addError.message 
                        };
                    }
                } else {
                    return { 
                        success: false, 
                        error: 'Failed to switch network: ' + switchError.message 
                    };
                }
            }
            
        } catch (error) {
            return { 
                success: false, 
                error: 'Unexpected error: ' + error.message 
            };
        }
    }

    async checkCurrentNetwork() {
        try {
            if (typeof window.ethereum === 'undefined') {
                return { isPolygon: false, error: 'MetaMask not installed' };
            }

            const chainId = await window.ethereum.request({ method: 'eth_chainId' });
            const isPolygon = chainId === this.POLYGON_CHAIN_ID;
            
            return {
                isPolygon,
                chainId,
                chainName: this.getChainName(chainId)
            };
            
        } catch (error) {
            return { isPolygon: false, error: error.message };
        }
    }

    getChainName(chainId) {
        const chains = {
            '0x1': 'Ethereum Mainnet',
            '0x89': 'Polygon',
            '0x13881': 'Polygon Mumbai',
            '0xa': 'Optimism',
            '0xa4b1': 'Arbitrum'
        };
        return chains[chainId] || `Unknown (${chainId})`;
    }

    async ensurePolygonNetwork() {
        const network = await this.checkCurrentNetwork();
        
        if (!network.isPolygon) {
            const result = await this.switchToPolygon();
            if (!result.success) {
                throw new Error(result.error);
            }
            return { switched: true };
        }
        
        return { switched: false, alreadyOnPolygon: true };
    }
}

// Create global instance
window.PolygonSwitcher = new PolygonSwitcher();

// Also add a simpler global function
window.switchToPolygon = async function() {
    return await window.PolygonSwitcher.switchToPolygon();
};
