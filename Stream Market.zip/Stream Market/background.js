// Handle messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    switch (request.action) {
        case 'getUserData':
            chrome.storage.local.get([
                'walletBalance', 
                'walletConnected', 
                'walletAddress', 
                'chainId',
                'userBets'
            ], (data) => {
                sendResponse({
                    success: true,
                    walletBalance: parseFloat(data.walletBalance) || 0,
                    walletConnected: data.walletConnected || false,
                    walletAddress: data.walletAddress || null,
                    chainId: data.chainId || null,
                    userBets: data.userBets || []
                });
            });
            return true;
            
        case 'updateWalletBalance':
            chrome.storage.local.set({ 
                walletBalance: parseFloat(request.balance) || 0,
                lastBalanceUpdate: new Date().toISOString()
            }, () => {
                sendResponse({ success: true });
            });
            return true;
            
        case 'saveWalletData':
            chrome.storage.local.set(request.data, () => {
                sendResponse({ success: true });
            });
            return true;
            
        case 'saveUserBets':
            chrome.storage.local.set({
                userBets: request.bets || [],
                lastBetUpdate: new Date().toISOString()
            }, () => {
                sendResponse({ success: true });
            });
            return true;
            
        case 'getUserBets':
            chrome.storage.local.get(['userBets'], (data) => {
                sendResponse({
                    success: true,
                    userBets: data.userBets || []
                });
            });
            return true;
            
        default:
            sendResponse({ success: false, error: 'Unknown action' });
    }
});

// On installation - устанавливаем начальные данные БЕЗ фейкового баланса
chrome.runtime.onInstalled.addListener(() => {
    
    chrome.storage.local.set({
        walletBalance: 0, // НАЧАЛЬНЫЙ БАЛАНС 0 (реальный)
        walletConnected: false,
        walletAddress: null,
        chainId: null,
        userBets: [],
        installedVersion: '2.0.0'
    });
});