// Stream Market Configuration - POLYGON
const CONFIG = {
    // Network configuration - Polygon
    POLYGON_CHAIN_ID: '0x89', // Polygon chain ID 137 in hex
    POLYGON_RPC_URL: 'https://polygon-rpc.com',
    POLYGON_SCAN_URL: 'https://polygonscan.com',
    
    // Contract address - Polygon
    PREDICTION_CONTRACT_ADDRESS: '0xe02FF561CF2B53A1C967982931f94B6a59b0753c',
    
    // POL - нативная валюта Polygon
    POL_TOKEN_ADDRESS: null,
    
    // ABI контракта - загружается из ABI.txt
    PREDICTION_CONTRACT_ABI: [
        {
            "inputs": [],
            "stateMutability": "nonpayable",
            "type": "constructor"
        },
        {
            "inputs": [
                {"internalType": "string", "name": "_channel", "type": "string"},
                {"internalType": "uint256", "name": "_option", "type": "uint256"}
            ],
            "name": "placeBet",
            "outputs": [{"internalType": "bytes32", "name": "", "type": "bytes32"}],
            "stateMutability": "payable",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "string", "name": "_channel", "type": "string"},
                {"internalType": "uint8", "name": "_result", "type": "uint8"}
            ],
            "name": "reportResult",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "string", "name": "_channel", "type": "string"}
            ],
            "name": "finalize",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "string", "name": "_channel", "type": "string"}
            ],
            "name": "timeout",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "bytes32", "name": "_id", "type": "bytes32"}
            ],
            "name": "claim",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "claimAll",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "withdrawFees",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "bytes32", "name": "_id", "type": "bytes32"}
            ],
            "name": "getPredictionInfo",
            "outputs": [
                {"internalType": "string", "name": "channel", "type": "string"},
                {"internalType": "uint256", "name": "totalPool", "type": "uint256"},
                {"internalType": "uint256", "name": "pool0", "type": "uint256"},
                {"internalType": "uint256", "name": "pool1", "type": "uint256"},
                {"internalType": "uint256", "name": "createdAt", "type": "uint256"},
                {"internalType": "uint256", "name": "lockedAt", "type": "uint256"},
                {"internalType": "uint8", "name": "status", "type": "uint8"},
                {"internalType": "uint256", "name": "winningOption", "type": "uint256"},
                {"internalType": "uint256", "name": "bettorsCount", "type": "uint256"},
                {"internalType": "uint256", "name": "reports0", "type": "uint256"},
                {"internalType": "uint256", "name": "reports1", "type": "uint256"}
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "bytes32", "name": "_id", "type": "bytes32"}
            ],
            "name": "getOdds",
            "outputs": [
                {"internalType": "uint256", "name": "odds0", "type": "uint256"},
                {"internalType": "uint256", "name": "odds1", "type": "uint256"}
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "bytes32", "name": "_id", "type": "bytes32"}
            ],
            "name": "getPercentages",
            "outputs": [
                {"internalType": "uint256", "name": "percent0", "type": "uint256"},
                {"internalType": "uint256", "name": "percent1", "type": "uint256"}
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "string", "name": "_channel", "type": "string"}
            ],
            "name": "getCurrentPrediction",
            "outputs": [{"internalType": "bytes32", "name": "", "type": "bytes32"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "bytes32", "name": "_id", "type": "bytes32"}
            ],
            "name": "isExpired",
            "outputs": [{"internalType": "bool", "name": "", "type": "bool"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "bytes32", "name": "_id", "type": "bytes32"}
            ],
            "name": "canFinalize",
            "outputs": [{"internalType": "bool", "name": "", "type": "bool"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "bytes32", "name": "_id", "type": "bytes32"},
                {"internalType": "address", "name": "_user", "type": "address"}
            ],
            "name": "getUserBet",
            "outputs": [
                {"internalType": "uint256", "name": "amount", "type": "uint256"},
                {"internalType": "uint256", "name": "option", "type": "uint256"},
                {"internalType": "bool", "name": "claimed", "type": "bool"}
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "uint256", "name": "_offset", "type": "uint256"},
                {"internalType": "uint256", "name": "_limit", "type": "uint256"}
            ],
            "name": "getActivePredictions",
            "outputs": [
                {"internalType": "bytes32[]", "name": "ids", "type": "bytes32[]"},
                {"internalType": "string[]", "name": "channels", "type": "string[]"},
                {"internalType": "uint256[]", "name": "totalPools", "type": "uint256[]"},
                {"internalType": "uint256[]", "name": "createdAts", "type": "uint256[]"},
                {"internalType": "uint256[]", "name": "statuses", "type": "uint256[]"},
                {"internalType": "uint256", "name": "totalCount", "type": "uint256"}
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "getActivePredictionsCount",
            "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {"internalType": "address", "name": "_user", "type": "address"}
            ],
            "name": "getUserPredictions",
            "outputs": [{"internalType": "bytes32[]", "name": "", "type": "bytes32[]"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "owner",
            "outputs": [{"internalType": "address", "name": "", "type": "address"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "collectedFees",
            "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "MIN_BET",
            "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "PLATFORM_FEE_PERCENT",
            "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function"
        }
    ],
    
    // App settings
    MIN_BET_AMOUNT: 20, // 20 POL
    PLATFORM_FEE: 10, // 10%
    
    // Report result enums
    REPORT_RESULTS: {
        FINISHED_0: 0,
        FINISHED_1: 1
    },
    
    // Status enums
    PREDICTION_STATUS: {
        OPEN: 0,
        ACTIVE: 1,
        RESOLVED: 2,
        CANCELLED: 3
    }
};

// Export
if (typeof window !== 'undefined') {
    window.CONFIG = CONFIG;
}
if (typeof module !== 'undefined') {
    module.exports = CONFIG;
}
