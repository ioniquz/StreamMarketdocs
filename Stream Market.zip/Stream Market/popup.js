// popup.js

document.addEventListener("DOMContentLoaded", async () => {
    const connectBtn = document.getElementById("connect-btn");
    const balanceEl = document.getElementById("pol-balance");
    const usdtEl = document.getElementById("usdt-balance");
    const depositBtn = document.getElementById("deposit-btn");

    let polUsdtRate = null;

    async function fetchPolUsdtRate() {
        try {
            const r = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=matic-network&vs_currencies=usdt");
            const j = await r.json();
            if (j && j["matic-network"] && typeof j["matic-network"].usdt === "number") {
                polUsdtRate = j["matic-network"].usdt;
                return polUsdtRate;
            }
        } catch (e) {}
        return polUsdtRate;
    }

    async function updateUsdtDisplay(balance) {
        if (!usdtEl) return;
        if (!balance || balance === 0) {
            usdtEl.textContent = "— USDT";
            return;
        }
        if (polUsdtRate == null) await fetchPolUsdtRate();
        if (polUsdtRate != null) {
            const usd = balance * polUsdtRate;
            usdtEl.textContent = "≈ " + (usd < 0.01 ? usd.toFixed(4) : usd < 1 ? usd.toFixed(2) : usd.toFixed(0)) + " USDT";
        } else {
            usdtEl.textContent = "— USDT";
        }
    }

    async function loadWalletData() {
        try {
            const data = await chrome.storage.local.get([
                "walletAddress",
                "walletBalance",
                "walletConnected",
                "chainId"
            ]);
            const balance = parseFloat(data.walletBalance) || 0;

            if (data.walletConnected && data.walletAddress) {
                connectBtn.textContent = data.walletAddress.slice(0, 6) + "..." + data.walletAddress.slice(-4);
                updateBalanceDisplay(balance);
                await updateUsdtDisplay(balance);
            } else {
                connectBtn.textContent = "Connect MetaMask";
                balanceEl.textContent = "0.0000 POL";
                if (usdtEl) usdtEl.textContent = "— USDT";
            }
        } catch (e) {}
    }

    function updateBalanceDisplay(balance) {
        if (balance === 0) {
            balanceEl.textContent = "0.0000 POL";
        } else if (balance < 0.0001) {
            balanceEl.textContent = balance.toFixed(8) + " POL";
        } else if (balance < 0.01) {
            balanceEl.textContent = balance.toFixed(6) + " POL";
        } else if (balance < 1) {
            balanceEl.textContent = balance.toFixed(4) + " POL";
        } else if (balance < 100) {
            balanceEl.textContent = balance.toFixed(2) + " POL";
        } else {
            balanceEl.textContent = balance.toFixed(0) + " POL";
        }
    }

    setInterval(async () => {
        const data = await chrome.storage.local.get(["walletBalance"]);
        const b = parseFloat(data.walletBalance);
        if (data.walletBalance !== undefined && !isNaN(b)) {
            updateBalanceDisplay(b);
            await updateUsdtDisplay(b);
        }
    }, 2000);

    // Подключение к MetaMask
    connectBtn.onclick = async () => {
        try {
            // Отправляем сообщение в content script для подключения
            const [tab] = await chrome.tabs.query({
                active: true,
                currentWindow: true
            });
            
            if (!tab || !tab.url || !tab.url.includes('twitch.tv')) {
                alert('Please open a Twitch page first');
                return;
            }

            // Инжектим скрипт для подключения
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: async () => {
                    if (window.TwitchBetsExtension) {
                        const result = await window.TwitchBetsExtension.connectMetaMask();
                        return result;
                    }
                    return { success: false, error: 'Extension not initialized' };
                }
            });
            
            // Ждем немного и обновляем данные
            setTimeout(async () => {
                await loadWalletData();
            }, 1000);
            
        } catch (e) {
            alert("Error: " + e.message);
        }
    };

    depositBtn.onclick = async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const onTwitch = tab && tab.url && tab.url.includes("twitch.tv");
            if (onTwitch) {
                await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: () => {
                        if (window.TwitchBetsExtension && typeof window.TwitchBetsExtension.showDepositModal === "function") {
                            window.TwitchBetsExtension.showDepositModal();
                        }
                    }
                });
            } else {
                window.open("https://polygonscan.com/", "_blank");
            }
        } catch (e) {
            // Если ошибка, пробуем открыть модальное окно на Twitch, иначе polygonscan
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                const onTwitch = tab && tab.url && tab.url.includes("twitch.tv");
                if (onTwitch) {
                    await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            if (window.TwitchBetsExtension && typeof window.TwitchBetsExtension.showDepositModal === "function") {
                                window.TwitchBetsExtension.showDepositModal();
                            }
                        }
                    });
                } else {
                    window.open("https://polygonscan.com/", "_blank");
                }
            } catch (e2) {
                window.open("https://polygonscan.com/", "_blank");
            }
        }
    };

    await loadWalletData();
});
